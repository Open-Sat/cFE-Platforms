/** \file
** 
** \brief  Define fixed framework gnc utility event message numbers.
**
** $Id: app_frame_gnc_events.h 1.1 2008/06/21 08:19:55EDT dcmccomas Exp  $
**
** \note
**   -# See app_frame_cfe_events.h notes.
**   -# Currently there aren't any fixed GNC event messages. When there are
**      some to be defined thsi note should eb removed and the numbering
**      should start with APP_FRAME_CFE_FIXED_EVENT_MAX.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:55EDT $
** $Revision: 1.1 $
** $Log: app_frame_gnc_events.h  $
** Revision 1.1 2008/06/21 08:19:55EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:45EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.2 2006/05/26 14:26:50EDT dcmccomas 
** 
** Revision 1.1 2006/05/01 09:28:39EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_gnc
** @{
*/

#ifndef _app_frame_gnc_events_
#define _app_frame_gnc_events_



/*
** Includes
*/

#include "app_frame_cfe_events.h"



/*
** Macro Definitions
*/


/*
** Allow a maximum of 25 fixed event message
** numbers for the cFE utilities. The IDs range
** from 0..24.
*/

#define APP_FRAME_GNC_FIXED_EVENT_MAX   (APP_FRAME_CFE_FIXED_EVENT_MAX + 25)


#endif /* _app_frame_gnc_events_ */
/** @} */
