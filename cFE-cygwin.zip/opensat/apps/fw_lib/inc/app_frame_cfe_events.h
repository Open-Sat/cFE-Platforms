/** \file
** 
** \brief  Define fixed framework cfe utility event message numbers.
**
** $Id: app_frame_cfe_events.h 1.1 2008/06/21 08:19:55EDT dcmccomas Exp  $
**
** \note
**   -# The framework defines several classes that can be instantiated by an
**      application. Instead of assigning a base event number during
**      construction, fixed event numbers are used. This simplifies event
**      message numbering management and reduces the number of event message
**      numbers used. The event message parameters uniquely identify the 
**      context in which the event was issued.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:55EDT $
** $Revision: 1.1 $
** $Log: app_frame_cfe_events.h  $
** Revision 1.1 2008/06/21 08:19:55EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:45EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.2 2006/10/23 13:50:32EDT dcmccomas 
** 
** Revision 1.1 2006/05/01 09:28:38EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_cfe
** @{
*/

#ifndef _app_frame_cfe_events_
#define _app_frame_cfe_events_


/*
** Macro Definitions
*/


/*
** app_msg
*/


#define APP_MSG_EVS_INVALID_LEN             0



/*
** app_cmdmsg
*/


#define APP_CMDMSG_EVS_INVALID_CHECKSUM     1
#define APP_CMDMSG_EVS_INVALID_LEN          2
#define APP_CMDMSG_EVS_INVALID_FUNC_CODE    3
#define APP_CMDMSG_EVS_NOOP_CMD             4
#define APP_CMDMSG_EVS_INVALID_FUNC_REG     5
#define APP_CMDMSG_EVS_MAX_CMD_REG          6
#define APP_CMDMSG_EVS_UNDEF_CMD            7


/*
** app_pipemgr
*/


#define APP_PIPEMGR_EVS_PIPE_CREATE_ERR    10
#define APP_PIPEMGR_EVS_PIPE_READ_ERR      11
#define APP_PIPEMGR_EVS_UNREG_MSG_RCVD     12
#define APP_PIPEMGR_EVS_MSG_SUBSCRIBE_ERR  13


/*
** Allow a maximum of 25 fixed event message
** numbers for the cFE utilities. The IDs range
** from 0..24.
*/

#define APP_FRAME_CFE_FIXED_EVENT_MAX      25


#endif /* _app_frame_cfe_events_ */
/** @} */
