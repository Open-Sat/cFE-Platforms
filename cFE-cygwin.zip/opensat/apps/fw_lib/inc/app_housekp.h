/** \file
** 
** \brief  Define a class to manage the C&DH housekeeping interface
**
** $Id: app_housekp.h 1.2 2009/11/17 10:49:52EST dmccomas Exp  $
**
** \note
**   -# The housekeeping reply message contains an application's command
**      valid/invalid counters and the FDC status indicators.
**   -# The applications command pipe is used to receive the HK request.
**   -# There aren't any public member functions since the framework
**      manages the app_housekp class.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2009/11/17 10:49:52EST $
** $Revision: 1.2 $
** $Log: app_housekp.h  $
** Revision 1.2 2009/11/17 10:49:52EST dmccomas 
** Updated OS_ function calls to CFE_PSP_ function calls
** Revision 1.1 2008/06/21 08:19:56EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:45EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.6 2006/06/13 11:34:31EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.5 2006/05/12 14:31:15EDT dcmccomas 
** 
** Revision 1.4 2006/05/01 09:23:33EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:40EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:57:24EST dcmccomas 
** 
**
*/

/** 
** @addtogroup framework_gnc
** @{
*/

#ifndef _app_housekp_
#define _app_housekp_

/*
** Includes
*/

#include "cfe_sb.h"
#include "app_pipemgr.h"
#include "app_cmdmsg.h"
#include "app_faultrep.h"
#include "app_tlmgen.h"

/*
** Macro Definitions
**
** - See file prologue for EVS note
*/

#define APP_HOUSEKP_EVS_MSG_CNT  0



#define APP_HOUSEKP_PIPE_DEPTH   1
#define APP_HOUSEKP_NAME         "HOUSEKP"


/*
** House Keeping Telemetry Packet
*/

typedef struct
{

   uint8              Hdr[CFE_SB_TLM_HDR_SIZE];

   uint16             CmdCntValid;
   uint16             CmdCntInvalid;

   uint16             FaultRepEnabledFlags[APP_FAULTREP_BITFIELD_WORDS];
   uint16             FaultRepLatchedFlags[APP_FAULTREP_BITFIELD_WORDS];

} App_HouseKp_ReplyMsg;


/**< House Keeping Class */

typedef struct
{

   uint16            EvsIdBase;  /**< Base event msg ID          */
   CFE_SB_MsgId_t    ReqMsgId;   /**< Msg ID of HK request       */
   CFE_SB_MsgId_t    ReplyMsgId; /**< Msg ID of GN&C App's reply */
   
   App_Msg_Class             ReqMsg;
   App_HouseKp_ReplyMsg      ReplyMsg;
   App_TlmMsg_Class          ReplyMsgObj;

   const App_CmdMsg_Class*   CmdMsg;
   const App_TlmGen_Class*   TlmGen;
   const App_FaultRep_Class* FaultRep;

} App_HouseKp_Class;


#endif /* _app_housekp_ */
/** @} */
