/** \file
** 
**  \brief  Define a class for processing cFE Sb messages. A message has a
**          callback function associated with it. 
**
** $Id: app_msg.h 1.1 2008/06/21 08:19:56EDT dcmccomas Exp  $
**
** \note
**   -# This is a base class with a virtual DispatchFunc() function. One known
**      subclass is a command message. A command message contains a command
**      code and multiple commands can be defined for the same message ID.
**   -# The cFE provides a functional interface to access cFE Message 
**      objects. Applications are unaware of the underlying message
**      format.
**   -# App_Msg_Constructor() must be called prior to any other App_Msg_ functions
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:56EDT $
** $Revision: 1.1 $
** $Log: app_msg.h  $
** Revision 1.1 2008/06/21 08:19:56EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:47EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.5 2006/06/13 11:34:33EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/01 09:23:32EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:42EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:57:25EST dcmccomas 
** 
** Revision 1.1 2006/03/23 15:18:05EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_cfe
** @{
*/

#ifndef _app_msg_
#define _app_msg_

/*
** Includes
*/

#include "cfe_sb.h"


/*
** Macro Definitions
*/

/* 
** String identifier length (in bytes including '\0') for message
** - Keep it short because it can be used in event messages
*/

#define APP_MSG_MAX_NAME_LEN  16        
                                      

/*
** Type Definitions
*/

/*
** Virtual Message Dispatch type definitions
** - Even though there's only one virtual function I stuck with the general
**   OO guidelines in The GN&C FSW Framework Programmer's Guide in case this
**   expands.
*/

struct App_Msg_Struct;  /* Forward reference */

typedef boolean (*App_Msg_DispatchFuncPtr)  (struct App_Msg_Struct*,const CFE_SB_MsgPtr_t);

typedef struct
{ 

   App_Msg_DispatchFuncPtr     Function;
   void*                       Data;

} App_Msg_DispatchVirtualTbl;

typedef struct
{

   App_Msg_DispatchVirtualTbl    Dispatch;

} App_Msg_VirtualTbl;


/*
** Message Processing Functions
**
** Clients that define message processing functions must conform to this
** prototype. The function parameters are 
**
** MsgProcObj   A reference to the object that processes the messages
** MsgData      A reference to the message data
**
** Both parameters must be of type "void*" because the types are message
** specific.
*/

typedef  boolean (*App_Msg_FuncPtr)  (void* MsgProcObj,const void* MsgData);

typedef struct
{

   App_Msg_FuncPtr  Ptr;       /* Message processing function pointer  */
   void*            ObjData;   /* Object instance data                 */

} App_Msg_FuncRec;


/*
** Message Class
**
** - Counters (Cnt) contain counts since App_Msg_Constructor() was called
** - A valid message is one that has been dispatched and the client's message
**   processing function returns a TRUE.
*/

struct App_Msg_Struct
{

   CFE_SB_MsgId_t  MsgId;
   uint16          UserDataLen;    /* User data length in bytes            */
   char            Name[APP_MSG_MAX_NAME_LEN];

   uint16          CurDataLen;     /* User data length of current message  */
   uint16          ValidCnt;       /* Number of valid messages received    */
   uint16          InvalidCnt;     /* Number of invalid messages received  */

   App_Msg_FuncRec     ProcFunc;
   App_Msg_VirtualTbl  Virtual;    

   struct App_Msg_Struct* NextMsgPtr;

};

typedef struct App_Msg_Struct App_Msg_Class;


/*
** Exported Functions
*/

/**
** \brief  Initialize a message processing object
**
** \note
**   -# This function (or another constructor) must be called prior to any other
**      App_Msg_ functions
**   -# This constructor should be used for non-command messages (i.e. one
**      message callback function defined per message).
**   -# MsgName length (including terminating null) must be less than or equal
**      to APP_MSGPROC_MAX_NAME_LEN.
**
** \param[in,out]  MsgObj       Pointer to an instance of a App_Msg class
** \param[in]      MsgName      Pointer to a string used to ID the msg
** \param[in]      MsgId        The cFE SB message ID for the msg
** \param[in]      UserDataLen  Length of the message data in bytes
** \param[in]      FuncPtr      Pointer to the caller's message function
** \param[in]      ObjPtr       Pointer to message function's data object
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_Msg_Constructor(App_Msg_Class*   MsgObj,
                         const char*      MsgName,
                         CFE_SB_MsgId_t   MsgId,
                         uint16           UserDataLen,
                         App_Msg_FuncPtr  FuncPtr,
                         void*            ObjPtr);


/**
** \brief  Return the cEF SB message identifier for a message object
**
** \param[in,out]  MsgObj  Pointer to an instance of a App_Msg class
**
** \returns
** \retcode CFE_SB_MsgId_t \retdesc cFE SB message ID \endcode
** \endreturns
*/

CFE_SB_MsgId_t App_Msg_GetId(App_Msg_Class*  MsgObj);


/**
** \brief Register a message processing function.
**
** \note
**   -# Allows user to register a function after App_Msg is constructed
**   -# Message data length is specified in the constructor
**
** \param[in,out]  MsgObj   Pointer to an instance of a App_Msg class
** \param[in]      FuncPtr  Pointer to the caller's message function
** \param[in]      ObjPtr   Pointer to message function's data object
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_Msg_RegisterFunc(App_Msg_Class*   MsgObj,
                          App_Msg_FuncPtr  FuncPtr,
                          void*            ObjPtr);


#endif /* _app_msg_ */
/** @} */
