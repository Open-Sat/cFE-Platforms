/** \file
** 
** \brief Define a class for generating a telemetry message.
**
** $Id: app_tlmmsg.h 1.1 2008/06/21 08:19:59EDT dcmccomas Exp  $
**
** \note
**   -# This class is not subclassed from app_msg because app_msg is designed
**      for incoming messages so some of the extra class data would be
**      confusing.
**   -# This class contains a reference to a cFE SB message and does not need to
**      know the structure of the message.
**   -# App_TlmMsg_Constructor() must be called prior to any other App_TlmMsg_
**      functions
**   -# This object's design is tightly coupled with App_TlmGen's needs
**       - The 'NextMsgPtr' class data allows a linked list to 
**         be used so App_TlmGen does need to know how at compilation how
**         many messages it will be holding
**       - App_TlmMsg_TimeToSend() allows the telemetry message to manage 
**         the information that determines when the message should be sent.
**       - See App_TlmGen.h's prologue notes for a typical usage scenario.
**   -# There are two methods of outputting a telemetry packet. 
**       - Continuous: Output the tlm msg every time Execute() is called 
**                     depending upon the filter counter
**       - Requested:  Output the tlm msg for a user specified 
**                     consecutive number of cycles.
**   -# The output filter is defined as follows
**       - 1 - Output message each time App_TlmMsg_TimeToSend() is called
**       - 2 - Output message every other time App_TlmMsg_TimeToSend() is called
**       - 3 - Output messaget each 3rd time App_TlmMsg_TimeToSend() is called
**       - etc.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:59EDT $
** $Revision: 1.1 $
** $Log: app_tlmmsg.h  $
** Revision 1.1 2008/06/21 08:19:59EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:50EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.4 2006/06/13 11:34:32EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.3 2006/05/01 09:23:34EDT dcmccomas 
** 
** Revision 1.2 2006/04/06 08:56:41EDT dcmccomas 
** 
** Revision 1.1 2006/03/29 12:58:34EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_cfe
** @{
*/

#ifndef _app_tlmmsg_
#define _app_tlmmsg_

/*
** Includes
*/

#include "cfe_sb.h"

/*
** Macro Definitions
*/

/**< String identifier length (in bytes including '\0') for telemetry messages
** - Keep it short because it can be used in event messages
*/

#define APP_TLMMSG_MAX_NAME_LEN  16        
                                      

/*
** Type Definitions
*/

/**
** \brief  Application specific function that loads data into a
**         telemetry message.
**
** \note
**   -# Separating the ObjPtr and MsgPtr supports cases when the object 
**      owns the telemetry message and cases when it doesn't.
**
** \param[in,out]  ObjPtr   Pointer to tlm owner's object data
** \param[in]      MsgPtr   Pointer to the telemetry message buffer
**
** \returns
** \retcode void \endcode
** \endreturns
*/
typedef void (*App_TlmMsg_FuncPtr) (void*            ObjPtr,
                                    CFE_SB_MsgPtr_t  MsgPtr);

typedef struct
{

   App_TlmMsg_FuncPtr  Ptr;       /* Message data packing function pointer  */
   void*               ObjData;   /* Object instance data                   */

} App_TlmMsg_FuncRec;

typedef enum
{

   APP_TLMGEN_OUTPUT_CONTINUOUS,
   APP_TLMGEN_OUTPUT_ON_REQUEST

} App_TlmMsg_OutputType;


/**< Telemetry Message Class */

struct App_TlmMsg_Struct
{

   CFE_SB_MsgId_t      Id;   /**< Message ID                       */
   uint16              Len;  /**< Total (hdr+data) byte len of msg */
   CFE_SB_MsgPtr_t     Ptr;  /**< Pointer to user's msg buffer     */

   char                Name[APP_TLMMSG_MAX_NAME_LEN];

   App_TlmMsg_FuncRec  GenFunc;

   uint16   FilterLmt;
   uint16   FilterCnt;
   
   App_TlmMsg_OutputType OutputType;

   struct App_TlmMsg_Struct*  NextMsgPtr;

};

typedef struct App_TlmMsg_Struct App_TlmMsg_Class;

/*
** Exported Functions
*/

/**
** \brief  Initialize a telemetry message object
**
** \note
**   -# This function must be called prior to any other App_TlmMsg_ functions
**   -# MsgName length (including terminating null) must be less than or equal
**      to APP_CMDMSG_MAX_NAME_LEN.
**
** \param[in,out]  MsgObj      Pointer to an instance of a App_Msg class
** \param[in]      MsgPtr      Pointer to the telemetry packet buffer
** \param[in]      MsgName     Pointer to a string used to ID the cmd msg
** \param[in]      MsgId       The cFE SB message ID for the command msg
** \param[in]      MsgLen      Length of the message data in bytes
** \param[in]      FuncPtr     Pointer to the caller's message function
** \param[in]      ObjDataPtr  Pointer to message function's data object
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_TlmMsg_Constructor(App_TlmMsg_Class*  MsgObj,
                            CFE_SB_MsgPtr_t    MsgPtr,
                            const char*        MsgName,
                            CFE_SB_MsgId_t     MsgId,
                            uint16             MsgLen,
                            App_TlmMsg_FuncPtr FuncPtr,
                            void*              ObjDataPtr);


/**
** \brief  Set a message's request count
**
** \param[in,out]  MsgObj      Pointer to an instance of a App_Msg class
** \param[in]      ReqCnt      Number of times packet should be output
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_TlmMsg_SetReqCnt(App_TlmMsg_Class*  MsgObj,
                          uint16             ReqCnt);


#endif /* _app_tlmmsg_ */
/** @} */
