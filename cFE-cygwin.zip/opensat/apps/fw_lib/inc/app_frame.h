/** \file
** 
** \brief Define a class to manage the framework components of a GN&C Application.
**
** $Id: app_frame.h 1.1 2008/06/21 08:19:54EDT dcmccomas Exp  $
**
** \note
**   -# Only one application frame can exist per Application
**   -# AppFrame_Constructor() must be called prior to any other AppFrame_ functions
**   -# A developer must choose whether command function codes are automatically
**      assigned by the framework or whether they want to explicitly define them. Only
**      one method can be used and the framework does NOT protect the user from
**      accidentally mixing methods.
**   -# The following steps summarize the application design steps. See references
**   -# for further details.
**      - Define the objects required by the application
**        - Determine each object�s responsibilities and functionality
**        - Determine what collaborations are required between the objects
**      - Define object manager information
**        - List object command functions to be registered with App_Frame�s command App_PipeMgr
**        - List object tables that need to be registered with the cFE
**      - Manage application identifiers
**        - Define DataBus object data identifiers
**        - Define fault detector identifiers
**        - Define command function codes if you don't want the framework to assign them
**      - Define application structure
**        - Define application�s telemetry packets
**          - Create one App_TlmMsg for each packet
**          - Packets may be declared and built at the application main�s level or at the object manager level
**        - Determine how and when the application will execute
**          - Drives whether the application needs to define additional App_PipeMgr objects
**          - Each application can define App_Msg and App_CmdMsg objects as needed
**            - Use App_PipeMgr to subscribe for the messages
**
** \par References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:54EDT $
** $Revision: 1.1 $
** $Log: app_frame.h  $
** Revision 1.1 2008/06/21 08:19:54EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:44EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision on laptop late for LRO and before FSBL
** Update doxygen. Add FaultCnt and functions to allocate ID resources
** Revision 1.15 2007/02/21 13:52:36EST dcmccomas 
** Changed CfeResetSubtype from int32 to a uint32
** Revision 1.14 2007/01/30 09:50:40EST dcmccomas 
** Change cFE ES call to CFE_ES_GetResetType and renamed variables accordingly
** Revision 1.13 2006/11/09 12:56:48EST dcmccomas 
** 
** Revision 1.12 2006/11/02 12:17:13EST dcmccomas 
** Added FcMethod to App_Frame_Class
** Revision 1.11 2006/11/01 09:13:03EST dcmccomas 
** Added changes for auto vs user defined cmd function code
** Revision 1.10 2006/10/23 15:32:54EDT dcmccomas 
** 
** Revision 1.9 2006/08/21 14:52:06EDT dcmccomas 
** Add support for new cFE ES performance monitoring API
** Revision 1.8 2006/07/27 14:32:12EDT dcmccomas 
** Modified App_Frame constructor to pass in maximum fault detector count.
** Revision 1.7 2006/06/13 11:34:34EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.6 2006/05/26 14:26:51EDT dcmccomas 
** 
** Revision 1.5 2006/05/10 13:33:50EDT dcmccomas 
** 
** Revision 1.4 2006/05/01 09:23:32EDT dcmccomas 
** 
** Revision 1.3 2006/03/28 14:57:25EST dcmccomas 
** 
** Revision 1.2 2006/03/24 14:12:38EST dcmccomas 
** Added "app_" prefix to cfe and gnc framework objects that are used by app_frame
** Revision 1.1 2006/03/23 15:18:04EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.5 2006/03/09 10:22:04EST jcwu 
** Added new-line at the end (DCR354).
** Revision 1.4 2006/01/31 10:26:10EST dcmccomas 
** Updated doxygen markup
** Revision 1.3 2005/11/10 07:28:22EST dcmccomas 
** Moved doxygen mainpage markup to separate file name mainpage.h in ut_tools\doc
** Revision 1.2 2005/11/09 07:53:17EST dcmccomas 
** Added doxygen markup
**
*/

/** 
** @addtogroup framework_gnc
** @{
*/

#ifndef _app_frame_
#define _app_frame_

/*
** Includes
*/

#include "app_timesvcs.h"
#include "app_pipemgr.h"
#include "app_cmdmsg.h"
#include "app_tlmgen.h"

#include "app_databus.h"
#include "app_faultrep.h"
#include "app_housekp.h"

#include "app_frame_gnc_events.h"

/*
** Macro Definitions
*/

#define APP_FRAME_EVS_MSG_CNT                    0

/*
** Macro Definitions
*/

#define APP_FRAME_FC_FAULTREP_CLEAR   APP_CMDMSG_FC_CLIENT_START
#define APP_FRAME_FC_FAULTREP_CONFIG  (APP_CMDMSG_FC_CLIENT_START+1)

#define APP_FRAME_FC_CLIENT_START     (APP_CMDMSG_FC_CLIENT_START+2)


/**< Maximum number of event messages in the framework. Padding for future growth */
#define APP_FRAME_EVS_ID_MAX  100

                              
#if (APP_FRAME_EVS_ID_MAX <= (APP_FRAME_GNC_FIXED_EVENT_MAX + APP_TLMGEN_EVS_MSG_CNT  + \
                              APP_FAULTREP_EVS_MSG_CNT      + APP_DATABUS_EVS_MSG_CNT + \
                              APP_HOUSEKP_EVS_MSG_CNT       + APP_FRAME_EVS_MSG_CNT   ))
   
   #error APP_FRAME_EVS_ID_MAX is too small

#endif

/*
** Type Definitions
*/

/**< Define methods for command function code assignment */
typedef enum
{

   APP_FRAME_CMD_FC_AUTO,   /**< The framework utilities automatically assigns FCs   */
   APP_FRAME_CMD_FC_USER    /**< The user supplies the FC to the framework utilities */

} App_Frame_CmdFcMethod;

/**< Application's command pipe definition */
typedef struct
{

   char*           PipeName;       /**< Name of command pipe (null terminated char string) */
   uint16          PipeDepth;      /**< Maximum number of messages on the cmd pipe         */
   
   char*           MsgName;        /**< Name of command msg (null terminated char string)  */
   CFE_SB_MsgId_t  MsgId;          /**< Command message ID                                 */
   uint16          MsgOnPipeMax;   /**< Maximum command messages on pipe at one time       */
   App_Frame_CmdFcMethod FcMethod; /**< Function Code assignment method                    */

   App_CmdMsg_FuncRec*  RegistrationBuf;
   uint16               RegistrationMax;

} App_Frame_Cmd;

/**< Application's fault reporter definition */
typedef struct
{

   uint16  MsgId;         /**< Fault report telemetry message ID */
   uint16  FaultIdCnt;    /**< Number of fault IDs (not an index, but a count). See app_faultrep.h for limit */

} App_Frame_FaultRep;

/**< Application's housekeeping interface definition */
typedef struct
{

   CFE_SB_MsgId_t   ReqMsgId;   /**< HK request message ID                          */
   uint16           ReqMsgLen;  /**< HK request message parameter length (in bytes) */
   CFE_SB_MsgId_t   ReplyMsgId; /**< HK reply message ID                            */

} App_Frame_HouseKp;


/**< Application's databus data source definition */
typedef struct
{

   App_DataBus_DataSrc*  RegistrationBuf;
   uint16                RegistrationMax;

}App_Frame_DataSrc;

/**< App_Frame constructor status */
typedef struct
{

   int32   CfeResetType ;    /**< See CFE_ES_GetResetType() API    */
   uint32  CfeResetSubtype;  /**< See CFE_ES_GetResetType() API    */
   int32   CfeAppRegStatus;  /**< See CFE_ES_RegisterApp() API     */
   int32   CmdPipeStatus;    /**< See CFE_SB_CreatePipe() API      */
   uint16  StartingEvsId;    /**< First event ID avail. to the app */

} App_Frame_Init;

/**< App_Frame class definition */
typedef struct
{

   uint16                EvsIdCnt;
   uint16                FaultIdCnt;
   App_Frame_CmdFcMethod FcMethod;

   App_TimeSvcs_Class TimeSvcs;

   App_PipeMgr_Class  CmdPipeMgr;
   App_CmdMsg_Class   CmdMsg;
   App_TlmGen_Class   TlmGen;

   App_DataBus_Class  DataBus;
   App_TlmMsg_Class   FaultRepTlmMsg;
   App_FaultRep_Class FaultRep;
   App_HouseKp_Class  HouseKp;
   
} App_Frame_Class;


/*
** Exported Functions
*/

/**
** \brief Initialize an Application Framework
**
** \note
**   -# This function must be called prior to any other AppFrame_ functions
**
** \param[out]  AppFrameObj   Pointer to an instance of a App_Frame_Class
** \param[in]   MissionEpoch  Mission Epoch time. May not be used by all apps
** \param[in]   CfePerfId     cFE performance monitor ID
** \param[in]   Cmd           Pointer to a structure containing the App's command info
** \param[in]   HouseKp       Pointer to a structure containing the App's HK info
** \param[in]   DataSrc       Pointer to a structure containing the App's SB info
** \param[in]   FaultRep      Pointer to a structure containing the App's FaultRep info
**
** \returns
** \retcode App_Frame_Init \retdesc Structure containing initialization status \endcode
** \endreturns
*/
App_Frame_Init App_Frame_Constructor(App_Frame_Class*          AppFrameObj,
                                     double                    MissionEpoch,
                                     uint32                    CfePerfId,
                                     const App_Frame_Cmd*      Cmd,
                                     const App_Frame_HouseKp*  HouseKp,
                                     const App_Frame_DataSrc*  DataSrc,
                                     const App_Frame_FaultRep* FaultRep);


/**
** \brief Allocate a block of event service IDs 
**
** \note
**   -# No ID overflow checks are made.
**
** \param[in,out]  AppFrameObj   Pointer to an instance of a App_Frame_Class
** \param[in]      EvsIdReqCnt   Number of IDs to reserve
**
** \returns
** \retcode uint16 \retdesc Starting event ID available to the caller \endcode
** \endreturns
*/
uint16 App_Frame_AllocateEvsIds(App_Frame_Class* AppFrameObj,
                                uint16           EvsIdReqCnt);



/**
** \brief Allocate a block of fault detector IDs 
**
** \note
**   -# No ID overflow checks are made.
**
** \param[in,out]  AppFrameObj    Pointer to an instance of a App_Frame_Class
** \param[in]      FaultIdReqCnt  Number of IDs to reserve
**
** \returns
** \retcode uint16 \retdesc Starting fault detector ID available to the caller \endcode
** \endreturns
*/
uint16 App_Frame_AllocateFaultIds(App_Frame_Class* AppFrameObj,
                                  uint16           FaultIdReqCnt);


#endif /* _app_frame_ */
/** @} */
