/** \file
** 
**  \brief  Provide default definitions for a mission
**
** $Id: mission_def.h 1.1 2008/06/21 08:19:59EDT dcmccomas Exp  $
**
** \note
**   -# This file can be modified by a mission. If a change is made then the
**      library must be rebuilt for the mission.
**   -# A single mission file is defined to allow a single mission gnc-fsw
**      framework shared library to be built. This was favored over individual
**      applications defining their own custom sizes and having multiple
**      libraries.
**   -# Framework maintenance engineers should strive to keep the options in
**      this file small. Idealy a mission should not have to do any
**      customization and an object file can be delivered. Customization 
**      requires additional unit testing.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:59EDT $
** $Revision: 1.1 $
** $Log: mission_def.h  $
** Revision 1.1 2008/06/21 08:19:59EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:50EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.1 2006/05/10 13:10:18EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_gnc
** @{
*/

#ifndef _mission_def_
#define _mission_def_


/*
** Macro Definitions
*/


/*
** Mission framework customizations
*/

/**< Max number fault detection points in each framework-based application's fault report */
#define MISSION_FAULTREP_ID_MAX 80

#endif /* _mission_def_ */
/** @} */
