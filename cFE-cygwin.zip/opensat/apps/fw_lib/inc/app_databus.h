/** \file
** 
** \brief Define a class that maps data producers to data consumers.
**
** $Id: app_databus.h 1.1 2008/06/21 08:19:53EDT dcmccomas Exp  $
**
** \note
**   -# The data bus manages intra-application data communication
**      between Object Managers. It does not provide control flow control.
**      The top level control objects are responsible for calling data
**      producers and consumers in the proper order.
**   -# App_DataBus_Constructor() must be called prior to any other App_DataBus_ 
**      functions
**   -# No dynamic memory is used. 
**   -# Only one App_DataBus can be defined for each Application.
**   -# A separate data object was considered that would include ancillary data
**      such as dimensions, units, etc. for a particular data item. This could
**      be useful for test systems and for a very generic (plug 'n play)
**      flight system. However, at this point in time it was not deemed
**      necessary. In many cases the data bus will reference objects and not
**      individual data points.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Developer's Guide
**
** $Date: 2008/06/21 08:19:53EDT $
** $Revision: 1.1 $
** $Log: app_databus.h  $
** Revision 1.1 2008/06/21 08:19:53EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:42EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.5 2006/06/13 11:34:33EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/10 13:33:50EDT dcmccomas 
** 
** Revision 1.3 2006/05/01 09:23:33EDT dcmccomas 
** 
** Revision 1.2 2006/04/06 08:56:42EDT dcmccomas 
** 
** Revision 1.1 2006/03/24 14:13:13EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.6 2006/03/09 10:24:53EST jcwu 
** Added new-line at the end (DCR354).
** Revision 1.5 2006/01/31 10:26:10EST dcmccomas 
** Updated doxygen markup
** Revision 1.4 2006/01/19 09:39:08EST dcmccomas 
** Completed unit test
** Revision 1.3 2005/11/29 06:50:51EST dcmccomas 
** Removed groups
** Revision 1.2 2005/11/09 07:53:19EST dcmccomas 
** Added doxygen markup
**
*/

/** 
** @addtogroup framework_gnc
** @{
*/

#ifndef _app_databus_
#define _app_databus_

/*
** Includes
*/



#include "common_types.h"
#include "cfe_time.h"

/*
** Macro Definitions
*/


#define APP_DATABUS_NULL_BUF  (NULL)

#define APP_DATABUS_DATA_SRC_NAME_LEN_MAX          8


#define APP_DATABUS_EVS_INVALID_DATA_SRC_ID        0
#define APP_DATABUS_EVS_UNREGISTERED_DATA_COMMIT   1

#define APP_DATABUS_EVS_MSG_CNT                    2

/*
** Type Definitions
*/

typedef uint16 App_DataType;

typedef enum
{

   APP_DATABUS_VALID,     /**< Producer updated the data with a valid value      */
   APP_DATABUS_INVALID,   /**< Producer declared the data is invalid this cycle  */
   APP_DATABUS_STALE,     /**< Producer didn't update the status this cycle      */
   APP_DATABUS_UNREG      /**< No producer has registered the data               */

} App_DataBus_DataStatus;


/*
** App_DataBus Class
*/

typedef struct 
{

   boolean              Registered;
   char                 Name[APP_DATABUS_DATA_SRC_NAME_LEN_MAX];

   double                  UpdateTime;
	App_DataBus_DataStatus  Status;
    
   void*                Buf;

} App_DataBus_DataSrc;


typedef struct
{

   double              CycleTime;
   CFE_TIME_SysTime_t  CfeCycleTime;

   uint16              EvsIdBase;

   uint16               DataSrcCnt;     /**< Count of registered data sources    */
   uint16               DataSrcCntMax;  /**< Length of user's data source buffer */
   App_DataBus_DataSrc* DataSrc;

} App_DataBus_Class;



/*
** Exported Functions
*/

/**
** \brief Allow data producer to indicate the data has been updated.
**
** \note
**   -# The current cycle time is used as the time stamp for when the
**      data was updated.
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void  App_DataBus_CommitData (App_DataBus_Class*  DataBusObj,
                              App_DataType        DataId);


/**
** \brief  Allow data producer to indicate the data has been updated and
**         provide the exact time the data was updated.
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
** \param[in]      Time       Time when data was updated
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void  App_DataBus_CommitDataWithTime (App_DataBus_Class*  DataBusObj,
                                      App_DataType        DataId,
                                      double              Time);


/**
** \brief  Return the current data bus cycle time in cFE time format
**
** \note
**   -# Uses global App_DataBus so no reference to an App_DataBus as the first parameter
**   -# If the cycle was initiated using App_DataBus_StartCycleWithTime() then
**      the cFE time is invalid and a time of zero will be returned.
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
**
** \returns
** \retcode CFE_TIME_SysTime_t \retdesc Current cycle time \endcode
** \endreturns
*/

CFE_TIME_SysTime_t App_DataBus_GetCfeCycleTime(App_DataBus_Class*  DataBusObj);



/**
** \brief Return the current data bus cycle time
**
** \note
**   -# Uses global App_DataBus so no reference to a DataBus as the first parameter
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
**
** \returns
** \retcode double \retdesc Current cycle time \endcode
** \endreturns
*/

double App_DataBus_GetCycleTime(App_DataBus_Class*  DataBusObj);


/**
** \brief Allow consumers to get a pointer to the desired data.
**
** \note
**   -# Uses global App_DataBus so no reference to a DataBus as the first parameter
**   -# This function will be successul even if the data has not been 
**      registered. This eliminates the need for a predetermined initialization
**      sequence. Use App_DataBus_GetDataRecord() if the data integrity needs to be
**      checked prior to using the data reference..
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
**
** \returns
** \retcode void** \retdesc Pointer to a pointer to the data buffer \endcode
** \endreturns
*/

void** App_DataBus_GetDataRef(App_DataBus_Class*  DataBusObj,
                              App_DataType        DataId);



/**
** \brief Allow a data consumer to get the current status of the data.
**
** \note
**   -# Uses global App_DataBus so no reference to a DataBus as the first parameter
**   -# This function will be successful even if the data has not been
**      registered.
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
** \param[in]      DataSrc    Pointer to buffer to receive data rec
**
** \returns
** \retcode TRUE  \retdesc DataSrc loaded with DataId's information \endcode
** \retcode FALSE \retdesc Invalid DataId supplied and memory referenced by DataSrc is unchanged \endcode
** \endreturns
*/

boolean  App_DataBus_GetDataRecord (App_DataBus_Class*    DataBusObj,
                                    App_DataType          DataId,
                                    App_DataBus_DataSrc*  DataSrc);


/**
** \brief Allow a data consumer to get the current status of the data.
**
** \note
**   -# Uses global App_DataBus so no reference to a DataBus as the first parameter
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
**
** \returns
** \retcode App_DataBus_DataStatus \endcode
** \endreturns
*/

App_DataBus_DataStatus  App_DataBus_GetDataStatus (App_DataBus_Class*  DataBusObj,
                                                   App_DataType        DataId);





/**
** \brief Register a data producer
**
** \note
**   -# Uses global App_DataBus so no reference to a DataBus as the first parameter
**   -# SrcName length must be under APP_DATABUS_DATA_SRC_NAME_LEN_MAX characters
**   -# It is not considered an error if the data source has already been registered.
**      It will be re-registered using the supplied data.
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
** \param[in]      SrcName    String containing name of data producer
** \param[in]      DataBuf    Pointer to data's buffer
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void App_DataBus_RegisterSrc(App_DataBus_Class*  DataBusObj,
                             App_DataType        DataId,
                             const char*         SrcName,
				                 void*               DataBuf);


/**
** \brief Allow a data producer to set the current status of the data.
**
** \note
**   -# Typically this would be used to set a data source to invalid.
**   -# There aren't any range checks performed on DataId
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
** \param[in]      DataId     Application unique data identifier
** \param[in]      Status     Data status value
**
** \returns
** \retcode App_DataBus_DataStatus \endcode
** \endreturns
*/

void  App_DataBus_SetDataStatus (App_DataBus_Class*     DataBusObj,
                                 App_DataType           DataId,
                                 App_DataBus_DataStatus Status);



/**
** \brief Start the beginning of an Application's execution cycle using
**          the cFE's current time.
**          
** \note
**   -# DataBus cycles should be managed by an Application's top level
**      of control logic.
**   -# Each data point's state is set to stale and the update time is 
**      unchanged (i.e. preserve when it was last updated).
**
** \param[in,out]  DataBusObj Pointer to a App_DataBus_Class object
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void App_DataBus_StartCycle(App_DataBus_Class*  DataBusObj);



/**
** \brief Start the beginning of an Application's execution cycle with
**          user supplied time.
**
** \note
**   -# DataBus cycles should be managed by an Application's top level
**      of control logic.
**   -# Each data point's state is set to stale and the updatetime is 
**      unchanged (i.e. preserve when it was last updated).
**
** \param[in,out]  DataBusObj  Pointer to a App_DataBus_Class object
** \param[in]      Time        Time at the start of an execution cycle
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void App_DataBus_StartCycleWithTime(App_DataBus_Class*  DataBusObj,
                                    double              Time);
                              

#endif /* _app_databus_ */
/** @} */
