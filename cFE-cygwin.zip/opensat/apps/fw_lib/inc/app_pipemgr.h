/** \file
** 
** \brief Define a class to manage messages received on a cFE pipe.
**
** $Id: app_pipemgr.h 1.1 2008/06/21 08:19:57EDT dcmccomas Exp  $
**
** \note
**   -# A single pipe manager can receive messages with different IDs. A user
**      must subscribe to each message individually. This is when an
**      application could have inputs from multiple sources but wants to
**      control its execution using a single pipe. The App_Msg class contains
**      the state information for each message so ground command counters will
**      not be affected by onboard message counters.
**   -# This object is coupled with App_Msg and depends on App_Msg to support
**      a linked list of messages.
**   -# This class does not prevent an application from subscribing to the same
**      message ID more than once. However, only the first occurance of the 
**      message object for the duplicate ID will be used.
**      be used
**   -# A typical usage of App_Msg, App_CmdMsg, and App_PipeMgr is
**       1. Call App_PipeMgr_Constructor() once during app initialization
**       2. Call App_Msg_Constructor() and/or App_CmdMsg_Constructor() for each
**          message you want to receive on the pipe
**       3. Call App_CmdMsg_RegCmdFunc() for each command callback function
**       3. Call App_PipeMgr_SubscribeToMsg() for each message to be received
**       4. Call App_PipeMgr_PendForMsg() and/or App_PipeMgr_PollForMsg()
**          as needed.
**   -# App_PipeMgr_Constructor() must be called prior to any other
**      App_PipeMgr_ functions
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:57EDT $
** $Revision: 1.1 $
** $Log: app_pipemgr.h  $
** Revision 1.1 2008/06/21 08:19:57EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:47EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.9 2006/11/15 09:55:12EST dcmccomas 
** 
** Revision 1.8 2006/11/14 08:45:21EST dcmccomas 
** 
** Revision 1.7 2006/08/22 09:01:29EDT dcmccomas 
** Added pipe flush and return count for poll and pend.
** Revision 1.6 2006/08/21 14:51:59EDT dcmccomas 
** Add support for new cFE ES performance monitoring API
** Revision 1.5 2006/06/13 11:34:32EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/01 09:23:34EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:40EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:57:24EST dcmccomas 
** 
** Revision 1.1 2006/03/23 15:18:06EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/
/** 
** @addtogroup framework_cfe
** @{
*/

#ifndef _app_pipemgr_
#define _app_pipemgr_

/*
** Includes
*/

#include "cfe_sb.h"
#include "app_msg.h"


/*
** Macro Definitions
*/

/* 
** String identifier length (in bytes including '\0') for command messages
** - Keep it short because it can be used in event messages
*/

#define APP_PIPEMGR_MAX_NAME_LEN  16        


/**< Default cFE SB quality of service used by App_PipeMgr_SubscribeToMsg() */
#define APP_PIPEMGR_DEF_SB_QOS_PARAM1 0
#define APP_PIPEMGR_DEF_SB_QOS_PARAM2 1

/*
** Pipe Manager class
**
** - Basically a container of Message (App_Msg) objects
*/

typedef struct
{

   CFE_SB_MsgPtr_t   SbPtr;
   CFE_SB_MsgId_t    CurId;
   uint16            RcvCount;

   App_Msg_Class*    First;
   App_Msg_Class*    Last;

} App_PipeMgr_Msg;


typedef struct
{

   uint32            CfePerfId;
   uint16            PipeDepth;
   CFE_SB_PipeId_t   PipeId;
   char              Name[APP_PIPEMGR_MAX_NAME_LEN];

   App_PipeMgr_Msg   Msg;

} App_PipeMgr_Class;


/*
** Exported Functions
*/


/**
** \brief Initialize an Application's command manager
**
** \note
**   -# This function must be called prior to any other App_PipeMgr_ functions
**   -# PipeName string length (including terminating null) must be less than or
**      equal to CFE_SB_PIPENAME_LENGTH. It will be truncated if it's not.
**
** \param[in,out]  PipeMgrObj   Pointer to an instance of a pipe manager class
** \param[in]      PipeName     Pointer to a string used to identify the pipe
** \param[in]      PipeDepth    The maximum # of msgs allowed on pipe at one time
** \param[in]      CfePerfId    cFE performance monitor ID
**
** \returns
** \retcode void \endcode
** \endreturns
*/
int32 App_PipeMgr_Constructor(App_PipeMgr_Class*  PipeMgrObj,
                              const char*         PipeName,
                              uint16              PipeDepth,
                              uint32              CfePerfId);


/**
** \brief  Flush a pipe manager's pipe.
**
** \note
**   -# The Application's execution will NOT be suspended
**   -# PipeDepth (defined by the constructor) is used as a limit for the
**      maximum number of pipe reads
**   -# No message callback functions are called
**   -# The class variable Msg.RcvCount is set to the number of times a
**      software bus read was performed. For non-error cases this is the 
**      same as the number of messages processed.
**
** \param[in,out]  PipeMgrObj   Pointer to an instance of a pipe manager class
**
** \returns
** \retcode int32 \retdesc Value returned by last call to CFE_SB_RcvMsg(). See cfe_sb.h for details. \endcode
** \endreturns
*/
int32 App_PipeMgr_Flush(App_PipeMgr_Class*  PipeMgrObj);



/**
** \brief  Pend for a message on a pipe manager's pipe and 
**           get remaining commands based on the MsgInputLimit.
**
** \note
**   -# The Application's execution may be suspended if no packets are on
**      the pipe.
**   -# The class variable Msg.RcvCount is set to the number of times a
**      software bus read was performed. For non-error cases this is the 
**      same as the number of messages processed.
**   -# The function return value is the value returned by last call to 
**      CFE_SB_RcvMsg() except if the SB return stataus is CFE_SUCCESS 
**      and the message processing function fails for any reason then the
**      return value is (CFE_SUCCESS | CFE_SEVERITY_ERROR) which is using
**      cFE's mission defined error code of zero. See cfe_sb.h and cfe_error.h
**      for details.
**
** \param[in,out]  PipeMgrObj     Pointer to an instance of a pipe manager class
** \param[in]      Timeout        Number of millseconds to pend (See cFE API)
** \param[in]      MsgInputLimit  The maximum # of msgs allowed on pipe at one time
**
** \returns
** \retcode int32 \retdesc Value returned by last call to CFE_SB_RcvMsg(). See function notes for exceptions. \endcode
** \endreturns
*/
int32 App_PipeMgr_PendForMsg(App_PipeMgr_Class*  PipeMgrObj,
                             int32               Timeout,
                             uint16              MsgInputLimit);



/**
** \brief  Poll a pipe manager's pipe.
**
** \note
**   -# The Application's execution will NOT be suspended
**   -# The class variable Msg.RcvCount is set to the number of times a
**      software bus read was performed. For non-error cases this is the 
**      same as the number of messages processed.
**   -# The function return value is the value returned by last call to 
**      CFE_SB_RcvMsg() except if the SB return stataus is CFE_SUCCESS 
**      and the message processing function fails for any reason then the
**      return value is (CFE_SUCCESS | CFE_SEVERITY_ERROR) which is using
**      cFE's mission defined error code of zero. See cfe_sb.h and cfe_error.h
**      for details.
**
** \param[in,out]  PipeMgrObj     Pointer to an instance of a pipe manager class
** \param[in]      MsgInputLimit  The maximum # of msgs allowed on pipe at one time
**
** \returns
** \retcode int32 \retdesc Value returned by last call to CFE_SB_RcvMsg(). See function notes for exceptions. \endcode
** \endreturns
*/
int32 App_PipeMgr_PollForMsg(App_PipeMgr_Class*  PipeMgrObj,
                             uint16              MsgInputLimit);



/**
** \brief  Subscribe to receive a message on a pipe manager's pipe.
**
** \note
**   -# MsgName length (including terminating null) must less than or equal
**      to APP_MSGPROC_MAX_NAME_LEN. 
**   -# See cFE API for a complete description of the Quality parameter
**      MaxMsgs
**   -# There's no check to determine whether a user has subscribed for the
**      same message twice. The first MsgObj will be always be used.      .
**
** \param[in,out]  PipeMgrObj   Pointer to an instance of a pipe manager class
** \param[in]      MsgObj       Pointer to an instance of message processing class
** \param[in]      Quality      Quality of service for interprocessor traffic
** \param[in]      MaxMsgs      Max msg (of type MsgId) that can be on a queue
**
** \returns
** \retcode int32 \retdesc Value returned by CFE_SB_SubscribeEx(). See cfe_sb.h for details. \endcode
** \endreturns
*/
int32 App_PipeMgr_SubscribeExToMsg(App_PipeMgr_Class*  PipeMgrObj,
                                   App_Msg_Class*      MsgObj,
                                   CFE_SB_Qos_t        Quality,
                                   uint16              MaxMsgs);


/**
** \brief  Subscribe to receive a message on a pipe manager's pipe.
**
** \note
**   -# See App_PipeMgr_SubscribeExToMsg()'s notes
**   -# The default SB Qos are defined by APP_PIPEMGR_DEF_SB_QOS_PARAM1
**      and APP_PIPEMGR_DEF_SB_QOS_PARAM2
**
** \param[in,out]  PipeMgrObj   Pointer to an instance of a pipe manager class
** \param[in]      MsgObj       Pointer to an instance of message processing class
** \param[in]      MaxMsgs      Max msg (of type MsgId) that can be on a queue
**
** \returns
** \retcode int32 \retdesc Value returned by CFE_SB_SubscribeEx(). See cfe_sb.h for details. \endcode
** \endreturns
*/
int32 App_PipeMgr_SubscribeToMsg(App_PipeMgr_Class*  PipeMgrObj,
                                 App_Msg_Class*      MsgObj,
                                 uint16              MaxMsgs);

#endif /* _app_pipemgr_ */
/** @} */
