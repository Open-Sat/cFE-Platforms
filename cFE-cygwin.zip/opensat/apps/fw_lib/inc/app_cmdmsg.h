/** \file
** 
** \brief Define a class for processing a cFE SB command message. 
**
** $Id: app_cmdmsg.h 1.1 2008/06/21 08:19:52EDT dcmccomas Exp  $
**
** \note
**   -# A command message is a cFE SB message that has a command function
**      code as part of the message header and the user data contains
**      command parameters. A single message ID can have multiple commands 
**      defined for it using unique command codes. This class
**      allows clients to register command callback functions to process
**      commands.Typically one message will be used for all ground commands
**      so the ground can monitor the command counters.
**   -# This object can be used by an application in one of two ways. Either
**      the application defines function codes or App_CmdMsg automatically
**      assigns function codes. If the app defines the function codes then
**      it must call App_CmdMsg_Constructor() followed by calls to 
**      App_CmdMsg_RegFunc() with the function codes as parameter. For auto
**      function code definitions the app first calls App_CmdMsg_Constructor()
**      followed by calls to App_CmdMsg_RegFuncAuto(). Function codes are 
**      assigned based on the order of the registration calls. See
**      App_CmdMsg_RegFuncAuto()'s prologue for more details. In either case
**      the constructor must be called prior to and other App_CmdMsg functions.
**   -# The cFE provides a functional interface to access cFE Message 
**      objects. Applications are unaware of the underlying message
**      format.
**   -# The command valid & invalid counters defined in base App_Msg class
**      contain counts since the last time App_CmdMsg_Constructor() or
**      App_CmdMsg_ResetCnt() was called.
**   -# A valid command is one that has been dispatched and the client's command
**      function returns a TRUE.
**   -# The following macros are used to configure a App_CmdMsg Object.
**      - APP_CMDMSG_MAX_CMDS
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:52EDT $
** $Revision: 1.1 $
** $Log: app_cmdmsg.h  $
** Revision 1.1 2008/06/21 08:19:52EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:40EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.6 2006/10/23 13:50:33EDT dcmccomas 
** 
** Revision 1.5 2006/05/10 13:33:49EDT dcmccomas 
** 
** Revision 1.4 2006/05/01 09:27:52EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:40EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:57:24EST dcmccomas 
** 
** Revision 1.1 2006/03/23 15:18:03EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_cfe
** @{
*/

#ifndef _app_cmdmsg_
#define _app_cmdmsg_

/*
** Includes
*/

#include "cfe_sb.h"

#include "app_msg.h"

/*
** Macro Definitions
*/

/*
** DEFAULT COMMAND FUNCTION CODES
**
** - Note NOOP has a non-zero function code so if a NOOP is issued after
**   a cold init it will cause the last function code to change to a non-zero
**   value.
*/

#define APP_CMDMSG_FC_RESET_CNT     0      /* Reset command counters     */
#define APP_CMDMSG_FC_NOOP          1      /* No Operation               */
#define APP_CMDMSG_FC_CLIENT_START  2      /* First available client FC  */


/* 
** String identifier length (in bytes including '\0') for command messages
** - Keep it short because it can be used in event messages
*/

#define APP_CMDMSG_MAX_NAME_LEN  16        
                                      

/*
** Type Definitions
*/

typedef struct
{

   char             Name[APP_CMDMSG_MAX_NAME_LEN];
   uint16           ParamLen;     /* Length in bytes of command parameters */
   App_Msg_FuncPtr  Ptr;          /* Message processing function pointer   */
   void*            ObjData;      /* Object instance data                  */

} App_CmdMsg_FuncRec;


typedef struct
{
   
   uint16               Cnt;    /* Count of commands defined in the DB          */
   uint16               CntMax; /* Maximum number of commands                   */
   App_CmdMsg_FuncRec*  Func;   /* User supplies the buffer during construction */

} App_CmdMsg_List;

/*
** Command Message Processing Class
*/

typedef struct
{

   App_Msg_Class    Parent;       /* Parent class data             */
   App_CmdMsg_List  Cmd;          /* Command processing functions  */

   uint16           CurCmdCode;   /* Function Code of last command */
   uint32           CurChecksum;  /* Checksum of last command      */
   
} App_CmdMsg_Class;


/*
** Exported Functions
*/

/**
** \brief Initialize a command message object
**
** \note
**   -# This function must be called prior to any other App_CmdMsg_ functions
**   -# MsgName length (including terminating null) must be less than or equal
**      to APP_CMDMSG_MAX_NAME_LEN.
**
** \param[in,out]  CmdMsgObj  Pointer to an instance of a cmd msg class
** \param[in]      MsgName    Pointer to a string used to ID the cmd msg
** \param[in]      MsgId      The cFE SB message ID for the command msg
** \param[in]      FuncBuf[]  Command function definition storage
** \param[in]      FuncMax    Maximum number of commands
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_CmdMsg_Constructor(App_CmdMsg_Class*  CmdMsgObj,
                            const char*        MsgName,
                            CFE_SB_MsgId_t     MsgId,
                            App_CmdMsg_FuncRec FuncBuf[],
                            uint16             FuncMax);

/**
** \brief Initialize a command message object for auto function code assignments
**
** \param[in,out]  CmdMsgObj  Pointer to an instance of a cmd msg class
** \param[in]      MsgName    Pointer to a string used to ID the cmd msg
** \param[in]      MsgId      The cFE SB message ID for the command msg
** \param[in]      FuncBuf[]  Command function definition storage
** \param[in]      FuncMax    Maximum number of commands
**
** \note
**   -# This function must be called prior to any other App_CmdMsg_ functions
**   -# MsgName length (including terminating null) must be less than or equal
**      to APP_CMDMSG_MAX_NAME_LEN.
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_CmdMsg_ConstructorAuto(App_CmdMsg_Class*  CmdMsgObj,
                                const char*        MsgName,
                                CFE_SB_MsgId_t     MsgId,
                                App_CmdMsg_FuncRec FuncBuf[],
                                uint16             FuncMax);


/**
** \brief Register a command callback function
**
** \param[in,out]  CmdMsgObj  Pointer to an instance of a cmd msg class
** \param[in]      CmdName    Pointer to a string used to ID the cmd msg
** \param[in]      FuncPtr    Pointer to the caller's command function
** \param[in,out]  ObjPtr     Pointer to command function's data object
** \param[in]      ParamLen   Length of the command parameters in bytes
** \param[in]      FuncCode   Command function code (not the stream ID)
**
** \note
**   -# CmdName (including terminating null) must be less than or equal to 
**      APP_CMDMSG_MAX_NAME_LEN.
**   -# FuncCode must be defined such that APP_CMDMSG_FC_CLIENT_START <= FuncCode < FuncMax
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_CmdMsg_RegFunc(App_CmdMsg_Class*     CmdMsgObj,
                        const char*           CmdName,
                        const App_Msg_FuncPtr FuncPtr,
                        void*                 ObjPtr,
                        uint16                ParamLen,
                        uint16                FuncCode);

/**
** \brief Register a command callback function
**
** \note
**   -# CmdName (including terminating null) must be less than or equal to 
**      APP_CMDMSG_MAX_NAME_LEN.
**   -# The command function code is automatically assigned. The first call assigns the
**      value APP_CMDMSG_FC_CLIENT_START and each subsequent call increments the function
**      code by 1. The unit test tool function UtGncApp_CreateCmdHeader() can be used to
**      generate a header file containing the command function ocdes.
**
** \param[in,out]  CmdMsgObj  Pointer to an instance of a cmd msg class
** \param[in]      CmdName    Pointer to a string used to ID the cmd msg
** \param[in]      FuncPtr    Pointer to the caller's command function
** \param[in,out]  ObjPtr     Pointer to command function's data object
** \param[in]      ParamLen   Length of the command parameters in bytes
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_CmdMsg_RegFuncAuto(App_CmdMsg_Class*     CmdMsgObj,
                            const char*           CmdName,
                            const App_Msg_FuncPtr FuncPtr,
                            void*                 ObjPtr,
                            uint16                ParamLen);

#endif /* _app_cmdmsg_ */
/** @} */
