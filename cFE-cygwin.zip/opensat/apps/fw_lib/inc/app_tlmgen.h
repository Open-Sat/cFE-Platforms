/** \file
** 
** \brief  Provide a standard mechanism for calling functions that pack data into 
**         telemetry message data structures.
**
** $Id: app_tlmgen.h 1.1 2008/06/21 08:19:58EDT dcmccomas Exp  $
**
** \note
**   -# A typical usage of App_TlmMsg and App_TlmGen is
**       1. Call App_TlmGen_Constructor() once during app initialization
**       2. Call App_TlmMsg_Constructor() for each app telemetry message
**       3. Call App_TlmGen_RegisterMsg() for each telemetry message
**       4. Call App_TlmGen_Execute() each execution cycle
**   -# See App_TlmMsg.h's prologue notes for usage
**   -# App_TlmGen_Constructor() must be called prior to any other App_TlmGen_ functions
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:58EDT $
** $Revision: 1.1 $
** $Log: app_tlmgen.h  $
** Revision 1.1 2008/06/21 08:19:58EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:49EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.5 2006/06/13 11:34:32EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/01 09:23:33EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:41EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:57:24EST dcmccomas 
** 
** Revision 1.1 2006/03/24 14:13:15EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.6 2006/03/09 10:32:37EST jcwu 
** Added new-line at the end (DCR 354).
** Revision 1.5 2006/01/31 10:26:11EST dcmccomas 
** Updated doxygen markup
** Revision 1.4 2005/11/09 07:53:20EST dcmccomas 
** Added doxygen markup
**
*/

/** 
** @addtogroup framework_cfe
** @{
*/

#ifndef _app_tlmgen_
#define _app_tlmgen_

/*
** Includes
*/

#include <math.h>

#include "cfe_sb.h"
#include "mathconstants.h"
#include "app_tlmmsg.h"

/*
** Macro Definitions
*/

#define APP_TLMGEN_EVS_MSG_CNT  0

/* 
** Define a macro that safely (i.e. no underflow exceptions) 
** converts a double to a float.
*/

#define CONVERT_DBLTOFLT(x)  ( ((fabs(x)) > (MTH_FLOAT_ZERO_TOLERANCE)) ? ((float) x) : ((float) 0.0) ) 


/*
** Type Definitions
*/

/*
** Telemetry Generator class
*/

typedef struct
{

   uint16  EvsIdBase;
   App_TlmMsg_Class*   FirstMsg;
   App_TlmMsg_Class*   LastMsg;

} App_TlmGen_Class;


                               

/*
** Exported Functions
*/



/**
** brief  Call the functions to pack the telemetry messages
**        and send them on the cFE's software bus.
**
** \note
**   -# The Application's execution will NOT be suspended when a message is
**      sent on the cFE's SB.
**
** \param[in,out]  TlmGenObj   Pointer to an instance of a App_TlmGen class
** \param[in]      SysTime     System time used to time-stamp tlm msgs
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_TlmGen_Execute(App_TlmGen_Class*    TlmGenObj,
                        CFE_TIME_SysTime_t*  SysTime);



/**
** \brief  Register a continuous telemetry message
**
** \param[in,out]  TlmGenObj   Pointer to an instance of a App_TlmGen class
** \param[in]      TlmMsgObj   Pointer to an instance of an App_TlmMsg object
** \param[in]      Filter      Specifies how often msg will be generated
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_TlmGen_RegisterMsg(App_TlmGen_Class* TlmGenObj,
                            App_TlmMsg_Class* TlmMsgObj,
                            uint16            Filter);


/**
** \brief  Register a telemetry meesage that is output upon request
**
** \note
**   -# Use App_TlmGen_RequestMsg() to output the message
** 
** \param[in,out]  TlmGenObj   Pointer to an instance of a App_TlmGen class
** \param[in]      TlmMsgObj   Pointer to an instance of an App_TlmMsg object
**
** \returns
** \retcode uint16 \retdesc App_TlmGen's telemetry message identifier \endcode
** \endreturns
*/
void App_TlmGen_RegisterReqMsg(App_TlmGen_Class* TlmGenObj,
                               App_TlmMsg_Class* TlmMsgObj);


/**
** \brief  Request a telemetry message to be sent ReqCnt times
**
** \param[in,out]  TlmGenObj   Pointer to an instance of a App_TlmGen class
** \param[in]      TlmMsgId    Pointer to an instance of an App_TlmMsg object
** \param[in]      ReqCnt      Number of times msg should be sent by Execute()
**
** \returns
** \retcode uint16 \retdesc App_TlmGen's telemetry message identifier \endcode
** \endreturns
*/
void App_TlmGen_RequestMsg(App_TlmGen_Class* TlmGenObj,
                           uint16            TlmMsgId,
                           uint16            ReqCnt);


#endif /* _app_tlmgen_ */
/** @} */
