/**
** \file
**
** \brief Unit Specification of Application's Time Services
**
** $Id: app_timesvcs.h 1.1 2008/06/21 08:19:58EDT dcmccomas Exp  $
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**
** $Date: 2008/06/21 08:19:58EDT $
** $Revision: 1.1 $
** $Log: app_timesvcs.h  $
** Revision 1.1 2008/06/21 08:19:58EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.1 2008/06/12 08:24:48EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/05/11 13:34:37EDT myyang 
** - Changed function prototypes so that they include pointer to app_timesvcs_class where needed, so that it
**   does not require singleton
** Revision 1.2 2006/03/27 09:31:33EST myyang 
** - Added function prototype of App_TimeSvcs_RetMissionEpoch()
** Revision 1.1 2006/03/24 09:18:48EST myyang 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_timesvcs_
#define _app_timesvcs_

/*
** Includes
*/

#include "cfe.h"

/*
** Macro Definitions
*/

#define INVERSE_OF_2_TO_THE_32_POWER        ((double)0.0000000002328306436539)
                                           /* 1/(2 to the 32 power) */

/*
** Type Definitions
*/

/** Application's Time Class Data */
typedef struct
{
	double	App_TimeSvcs_MissionEpoch; /**< Application's Mission Epoch */

}App_TimeSvcs_Class;

/*
** Exported Functions
*/

/**
** \brief Constructs App_TimeSvcs_Class with Application's Mission Epoch
**
** \param[in,out]  App_TimeSvcs_Obj  App_TimeSvcs_Obj
** \param[in]      App_MissionEpoch  double
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void App_TimeSvcs_Constructor(App_TimeSvcs_Class*  App_TimeSvcs_Obj,
                              double               App_MissionEpoch);


/**
** \brief Converts cFE time to number of seconds after application's mission epoch
**
** \param[in] Time - CFE_TIME_SysTime_t
**
** \returns
** \retcode double \retdesc Number of seconds after application's mission epoch \endcode
** \endreturns
*/
double App_TimeSvcs_SysTime(CFE_TIME_SysTime_t Time);


/**
** \brief Converts cFE Time to a Julian Date
**
** \param[in]  App_TimeSvcs_Obj   Pointer to Time Services Object
** \param[in]  Time               Time as CFE_TIME_SysTime_t object
**
** \returns
** \retcode double \retdesc 'Time' parameter as a Julian Date \endcode
** \endreturns
*/
double App_TimeSvcs_JDTime(App_TimeSvcs_Class*  App_TimeSvcs_Obj,
                           CFE_TIME_SysTime_t   Time);


/**
** \brief Returns Mission Epoch Time
**
** \param[in] App_TimeSvcs_Obj   Pointer to Time Services Object
**
** \returns
** \retcode double \retdesc Mission Epoch \endcode
** \endreturns
*/
double App_TimeSvcs_RetMissionEpoch(App_TimeSvcs_Class*	App_TimeSvcs_Obj);

#endif /* end _app_timesvcs_ */

/* end of file */
