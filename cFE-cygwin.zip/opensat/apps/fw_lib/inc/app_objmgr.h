/**
** @file
**
** Unit Specification of App Object Manager
**
** $Id: app_objmgr.h 1.1 2009/01/29 11:09:16EST myang Exp  $
**
** References:
**		-# Core Flight Executive Application Developers Guide.
**		-# GN&C FSW Framework Programmer's Guide
**
** $Date: 2009/01/29 11:09:16EST $
** $Revision: 1.1 $
** $Log: app_objmgr.h  $
** Revision 1.1 2009/01/29 11:09:16EST myang 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/inc/project.pj
** Revision 1.9 2007/12/06 15:05:30EST dcmccomas 
** 
** Revision 1.8 2006/11/17 09:06:29EST myyang 
**  - Set Object's Execution Function Pointer as pointer to a function that returns a boolean.
** Revision 1.7 2006/11/06 11:46:18EST myyang 
**  - Added FuncCode field to CmdInitTbl
** Revision 1.6 2006/06/27 15:44:32EDT myyang 
** - ObjMgr Constructor's Evs Ids are offsetted from APP_FRAME_EVS_ID_MAX (hard-coded in app_frame.h)
** Revision 1.5 2006/06/07 15:48:48EDT myyang 
**  - App_ObjMgr_RetStat changed and App_ObjMgr_Status added
** Revision 1.4 2006/05/23 14:59:25EDT myyang 
** - Removed custom parameter for constructor function call
** - Added custom parameter to initialization table
** Revision 1.3 2006/05/11 13:34:06EDT myyang 
** - Changed data initialization table so that it does not need data size
** - Changed object initialization table so that it does not include num of faults
** - Changed definition of object constructor pointer
** Revision 1.2 2006/05/02 10:46:25EDT myyang 
** - Added Pointer to App_Frame to Object Manager Execution Function
** Revision 1.1 2006/05/01 15:16:47EDT myyang 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_objmgr_
#define _app_objmgr_

/*
** Includes
*/

#include "cfe.h"

#include "app_frame.h"

/*
** Macro Definitions
*/
/** 
** @addtogroup framework_evs
** @{
*/

#define APP_OBJMGR_EVS_TBL_REGISTER_ERR			APP_FRAME_EVS_ID_MAX + 1	/**< Relative Evs Id if Table Fails to Register */
#define APP_OBJMGR_EVS_TBL_LOAD_ERR				APP_FRAME_EVS_ID_MAX + 2	/**< Relative Evs Id if Table with Initial Values Fails to Load */

#define APP_OBJMGR_EVS_MSG_MAX_ID				APP_FRAME_EVS_ID_MAX + 25	/**< Number of Event Svcs Ids used by App_ObjMgr */

/** @} */

/*
** Type Definitions
*/

/** Status of the App_ObjMgr Constructor */
typedef enum{

	APP_OBJMGR_CONSTRUCT_SUCCESS,	/**< App_ObjMgr Constructed Successfully */
	APP_OBJMGR_TABLE_ERROR			/**< App_ObjMgr Had Error with cFE Tables */

}App_ObjMgr_Status;

/** Return structure of the App_ObjMgr Constructor */
typedef struct{

	uint16				StartingEvsId;	/**< The first EVS Id available to use by the application task */
	App_ObjMgr_Status	Status;			/**< The status of the App_ObjMgr Constructor execution */

}App_ObjMgr_RetStat;

typedef boolean (*App_ObjMgr_Exec_FuncPtr) (void* ObjMgrPtr, void* App_FramePtr, void* DataPtr);	/**< Definition of Object's Execution Function Pointer*/
typedef void (*App_ObjMgr_Construct_FuncPtr) (void* CmdObj, uint16 EvsBaseId);						/**< Definition of Object's Constructor Function Pointer */
typedef void (*App_ObjMgr_CustomConstruct_FuncPtr)(void* CmdObj1, void* CmdObj2, void* AddlParam);	/**< Definition of Object's Custom Constructor Function Pointer*/

/** App Object Manager Class Specification */
typedef struct{

	char*					App_ObjMgr_Name;		/**< App Object Manager Name */

	uint16					App_ObjMgr_EvsIdBase;	/**< App Object Manager Base Event Id */

	CFE_TBL_Handle_t*		App_ObjMgr_Tbl;			/**< App Object Manager Table Handles */

	void**					App_ObjMgr_Obj;			/**< App Object Manager Object Pointers */

	App_TlmMsg_Class*		App_ObjMgr_TlmMsg;		/**< App Object Manager Telemetry Messages */

	App_ObjMgr_Exec_FuncPtr	App_ObjMgr_ExecFunc;	/**< App Object Manager Execution Function Pointer */

}App_ObjMgr_Class;

/** Cmd Registration Data Entry Specification */
typedef struct{
	char*			CmdName;	/**< Command Name */
    CFE_SB_MsgId_t	MsgId;		/**< Command Message Id */
    App_Msg_FuncPtr	FuncPtr;	/**< Command Function Pointer */
    void*			ObjPtr;		/**< Command Function Object Pointer Parameter */
    uint16			ParamLen;	/**< Command Function Input Parameter Data Length */
	uint16			FuncCode;	/**< Command Function Code - Will not be used if 
									 App_Frame->FcMethod == APP_FRAME_CMD_FC_AUTO */
}CmdInitTbl;

/** Table Registration Data Entry Specification */
typedef struct{
	char						*Name;					/**< Table Name */
	uint32						Size;					/**< Table Size */
	uint16						TblOptionFlags;			/**< Table Option Specification */
	CFE_TBL_CallbackFuncPtr_t	TblValidationFuncPtr;	/**< Function Pointer to Table Validator */
	CFE_TBL_SrcEnum_t			SrcType;				/**< Table Source */
	void*						InitialTblValues;		/**< Table Initialization Values */
}TblInitTbl;

/** Output Data Entry Specification */
typedef struct{
	uint16	DataType;	/**< Data Type of Output Data */
	char*	DataName;	/**< Name of Data */
	void*	DataLoc;	/**< Pointer to Output Data */
}DataSendInitTbl;

/** Telemetry Generator Function Registration Specification */
typedef struct{
	CFE_SB_MsgPtr_t		MsgPtr;			/**< Telemetry Message Pointer */
	App_TlmMsg_FuncPtr	TlmGenFuncPtr;	/**< Telemetry Generating Function Pointer */
	char*				MsgName;		/**< Telemetry Message Name */
	CFE_SB_MsgId_t		TlmMsgId;		/**< Telemetry Message Id */
	uint16				MsgLen;			/**< Telemetry Message Length */
	uint16				Filter;			/**< Telemetry Message Filter */
	void*				ObjDataPtr;		/**< Telemetry Message Data Ptr */
}TlmGenInitTbl;

/** Object Pointer Registration Specification */
typedef struct{
	void*							ObjPtr;					/**< Object Class Pointer */
	uint16							ObjEvsMaxCnt;			/**< Maximum Evs Id Cnt of Object */
	App_ObjMgr_Construct_FuncPtr	ObjConstructorFunction;	/**< List Object Constructor Functions */
}ObjInitTbl;

/** Object Initialization Table Specification */
typedef struct{

	uint16		NumCmds;		/**< Number of Commands */
	uint16		NumTbls;		/**< Number of Tables */
	uint16		NumDataSend;	/**< Number of Data Outputs */	
	uint16		NumObjs;		/**< Number of Objects */
	uint16		NumPkts;		/**< Number of Telemetry Packets */

	uint16		ObjEvsIdCnt;	/**< Number of Addl Event Cnts from Object */
	
	CmdInitTbl*			Cmds;			/**< List of Command Registration Info */

	CFE_TBL_Handle_t*	TblHandleList;	/**< List of Table Handles */
	TblInitTbl*			Tbls;			/**< Table Registration Info Table */

	DataSendInitTbl*	Dtsd;			/**< Data Output Registration Info Table */

	App_TlmMsg_Class*	DataPktList;	/**< List of Data Telmetry Packets */
	TlmGenInitTbl*		DataPkt;		/**< Data Telemetry Packets */

	void**				ObjList;		/**< List Of Object Pointers */
	ObjInitTbl*			Objs;			/**< Data Registration Info Table */

	void*				CustomParam;	/**< Custom Parameter for Custom Constructor */

	App_ObjMgr_Exec_FuncPtr					App_ObjMgr_ExecuteFunc;			/**< Object Execution Function Pointer */

	App_ObjMgr_CustomConstruct_FuncPtr		App_ObjMgr_CustomConstructor;	/**< Pointer to Object Manager's Custom Constructor */

}App_ObjMgr_InitTbl;


/**
** Constructs Application's Object Manager
**
** Features:
**			-# Links Object Manager to Object Class Data
**			-# Executes each Objects constructor
**			-# Registers Output Data to DataBus
**			-# Registers and Loads cFE Tables
**			-# Registers Command Functions with Command Manager
**			-# Registers Telemetry-Generation Function with TlmGen
**			-# Runs any addtional, ObjMgr-Specific constructors
**			-# Links Object Manager to its Execution Function Pointer 
**
** @param[in, out]	NewObjMgr	- Pointer to App Object Manager
** @param[in]		name		- Name of App Object Manager
** @param[in]		App_Frame	- Application Framework Pointer
** @param[in]		InitTbl		- Initialization Information for Object Manager
** @param[in]		EvsBaseId	- EvsBaseId for Objects (should be the starting EvsBaseId returned by App_Frame_Constructor)
**
** @returns App_ObjMgr_RetStat
**
*/
App_ObjMgr_RetStat App_ObjMgr_Constructor(App_ObjMgr_Class*		NewObjMgr,
										  char*					name,
										  App_Frame_Class*		App_Frame,
										  App_ObjMgr_InitTbl*	InitTbl,
										  uint16				EvsBaseId);

#endif /* end _app_objmgr_ */

/* end of file */
