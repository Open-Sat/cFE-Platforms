/*
** 
** Purpose: Define private methods for the app_cmdmsg class. 
**
** $Id: app_cmdmsg_priv.h 1.1 2008/06/21 08:19:41EDT dcmccomas Exp  $
**
** Notes:
**   1. This is a private header. See app_cmd_msg.h's notes for
**      interface details.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:41EDT $
** $Revision: 1.1 $
** $Log: app_cmdmsg_priv.h  $
** Revision 1.1 2008/06/21 08:19:41EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:31EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/07/27 14:28:11EDT dcmccomas 
** Removed doxygen markup.
** Revision 1.2 2006/06/13 11:39:16EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.1 2006/05/01 09:26:37EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_cmdmsg_priv_
#define _app_cmdmsg_priv_

/*
** Includes
*/

#include "app_cmdmsg.h"



/*
** Exported Functions
*/


/*
** Purpose:  Validate the command message and call the command 
**           corresponding command function
**
** Notes:
**   1. This is a virtual function and must comply with the
**      MsgProc_DispatchFuncPtr function signature defined in msgproc.h
**
** Return:
**   - TRUE  - UtFrame constructed
**   - FALSE - UtFrame not constructed
**
*/

boolean App_CmdMsg_DispatchFunc (      App_Msg_Class*   MsgObj, /**< Pointer to an instance of a App_Msg class */ 
                                 const CFE_SB_MsgPtr_t  MsgPtr  /**< A pointer to the CFE's SB message         */
                                );



/**
** Purpose:  Test command function that has no functional behavior
**           other than to issue an event message.
**
** Notes:
**   1. The function signature must comply with the GN&C framework's
**      message processing function definition MsgProc_FuncPtr.
**
** Return
**   - TRUE  - No operation sucessfully executed
**   - FALSE - This cannot occur
**
*/

boolean App_CmdMsg_NoOpCmd(      void*  CmdObj,    /**< Pointer to an instance of a cmd msg class */
                           const void*  CmdParam   /**< Unuse                                     */
                          );



/*
** Purpose:  Initialize the command counters.
**
** Notes:
**   1. The function signature must comply with the GN&C framework's
**      message processing function definition MsgProc_FuncPtr.
**
** Return
**   - TRUE  - Command message counters successfully cleared
**   - FALSE - This cannot occur
**
*/

boolean App_CmdMsg_ResetCntCmd(      void*  CmdObj,   /**< Pointer to an instance of a cmd msg class */
                               const void*  CmdParam  /**< Unused                                    */
                              );


#endif /* _app_cmdmsg_priv */
