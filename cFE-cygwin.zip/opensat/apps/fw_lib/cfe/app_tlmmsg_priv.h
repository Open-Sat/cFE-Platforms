/*
** 
** Purpose: Define private methods for the app_tlmmsg class.
**
** $Id: app_tlmmsg_priv.h 1.1 2008/06/21 08:19:46EDT dcmccomas Exp  $
**
** Notes:
**   1. This is a private header. See app_tlmmsg.h's notes for public
**      interface details.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:46EDT $
** $Revision: 1.1 $
** $Log: app_tlmmsg_priv.h  $
** Revision 1.1 2008/06/21 08:19:46EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:35EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/07/27 14:28:11EDT dcmccomas 
** Removed doxygen markup.
** Revision 1.2 2006/06/13 11:39:15EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.1 2006/05/01 09:26:38EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_tlmmsg_priv_
#define _app_tlmmsg_priv_

/*
** Includes
*/

#include "app_tlmmsg.h"


/*
** Exported Functions
*/


/*
** Purpose:  Set the parameters that determine when the packet is generated
**
*/
void App_TlmMsg_SetGenParams(App_TlmMsg_Class*     MsgObj,     /**< Pointer to an instance of a App_Msg class  */
                             App_TlmMsg_OutputType OutputType, /**< Continuous and filter or requested msg     */
                             uint16                FilterLmt   /**< Specifies how often msg will be generated  */   
                             );


/*
** Purpose:  Set a message's link
**
*/
void App_TlmMsg_SetLink(App_TlmMsg_Class*  MsgObj,  /**< Pointer to an instance of a msg class */
                        App_TlmMsg_Class*  NextMsg  /**< Pointer to msg to be linked           */
                       );


/*
** Purpose:  Determine whether it's time to send the message
**
*/

boolean App_TlmMsg_TimeToSend(App_TlmMsg_Class* TlmMsgObj  /**< Pointer to an instance of a msg class   */
                             );

#endif /* _app_tlmmsg_priv_ */
