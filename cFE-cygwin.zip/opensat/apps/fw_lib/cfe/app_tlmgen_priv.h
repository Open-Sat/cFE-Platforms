/*
** 
** Purpose:  Define private methods for the app_tlmgen class.
**
** $Id: app_tlmgen_priv.h 1.1 2008/06/21 08:19:45EDT dcmccomas Exp  $
**
** Notes:
**   1. This is a private header. See app_tlmgen.h's notes for public
**      interface details.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:45EDT $
** $Revision: 1.1 $
** $Log: app_tlmgen_priv.h  $
** Revision 1.1 2008/06/21 08:19:45EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:34EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/07/27 14:28:11EDT dcmccomas 
** Removed doxygen markup.
** Revision 1.2 2006/06/13 11:39:15EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.1 2006/05/01 09:26:38EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_tlmgen_priv_
#define _app_tlmgen_priv_

/*
** Includes
*/

#include "app_tlmgen.h"


/*
** Exported Functions
*/


/*
** Purpose:  Initialize an Application's telemetry generator
**
** Notes:
**   1. This function must be called prior to any other App_TlmGen_ functions
**   2. This is private because only one app_tlmgen needs to exist for an 
**      application and it is automatically created by the framework.
**
*/
void App_TlmGen_Constructor(App_TlmGen_Class*  TlmGenObj, /**< Pointer to an instance of a App_TlmGen class */
                            uint16*            EvsIdBase  /**< Starting event message ID                    */
                           );



#endif /* _app_tlmgen_priv_ */
