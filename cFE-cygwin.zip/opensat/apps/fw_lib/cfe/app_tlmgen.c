/* 
** File:
**   $Id: app_tlmgen.c 1.2 2009/11/17 10:49:19EST dmccomas Exp  $
**
** Purpose: Implement the GN&C Framework telemetry generator.
**
** Notes
**   1. The local RegisterMsg function was not used as the global API because
**      most users will use App_TlmGen_RegisterMsg() and not worry about the
**      request type of message. Also passing a zero FilterLmt for on-rquest 
**      messages is clumsy. If the request message API is extended to 
**      allow the ground to use it then this design should be revisited.
**   2. The cFE provides a functional interface to access cFE Message 
**      objects. Applications are unaware of the underlying message
**      format.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Developer's Guide
**
** $Date: 2009/11/17 10:49:19EST $
** $Revision: 1.2 $
** $Log: app_tlmgen.c  $
** Revision 1.2 2009/11/17 10:49:19EST dmccomas 
** Updated OS_ calls to CFE_PSP_ calls
** Revision 1.1 2008/06/21 08:19:44EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:33EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.4 2006/05/01 09:24:31EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:55:40EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:55:53EST dcmccomas 
** 
** Revision 1.1 2006/03/24 14:10:05EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.1 2005/11/30 09:10:50EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.4 2005/11/09 07:53:30EST dcmccomas 
** Added doxygen markup
**
*/

/*
** Include Files:
*/

#include "app_tlmmsg_priv.h"
#include "app_tlmgen_priv.h"

#include <string.h>

#include "cfe_evs.h"

/*
** Macros
*/

#define EVS_ID(Offset)  ((uint16)(TlmGenObj->EvsIdBase + Offset)) 


/*
** Local Function Prototypes
*/

static void TlmGen_RegisterMsg (App_TlmGen_Class*     TlmGenObj,
                                App_TlmMsg_Class*     TlmMsgObj,
                                App_TlmMsg_OutputType OutputType,
                                uint16                FilterLmt);

/*
** Exported Functions
*/


/******************************************************************************
** Function: App_TlmGen_Constructor
**
*/
void App_TlmGen_Constructor(App_TlmGen_Class*  TlmGenObj,
                            uint16*            EvsIdBase)
{
 
   
   TlmGenObj->EvsIdBase = *EvsIdBase;
   *EvsIdBase += APP_TLMGEN_EVS_MSG_CNT;



   TlmGenObj->FirstMsg = NULL;
   TlmGenObj->LastMsg = NULL;


} /* End App_TlmGen_Constructor() */



/******************************************************************************
** Function: App_TlmGen_Execute
**
*/
void App_TlmGen_Execute(App_TlmGen_Class*    TlmGenObj, 
                        CFE_TIME_SysTime_t*  SysTime)
{

   App_TlmMsg_Class* TlmMsgObj;
   CFE_SB_MsgPtr_t   TlmMsg;


   TlmMsgObj = TlmGenObj->FirstMsg;
   
   while (TlmMsgObj != NULL)
   {

      if (App_TlmMsg_TimeToSend(TlmMsgObj) == TRUE)
      {
         TlmMsg = TlmMsgObj->Ptr;
         CFE_SB_SetMsgTime(TlmMsg, *SysTime);

         (TlmMsgObj->GenFunc.Ptr)(TlmMsgObj->GenFunc.ObjData, TlmMsg);

         CFE_SB_SendMsg(TlmMsg);
      
      } /* End if SendMsg */

      TlmMsgObj = TlmMsgObj->NextMsgPtr;

   } /* End message loop */


} /* End App_TlmGen_Execute() */



/******************************************************************************
** Function: App_TlmGen_RegisterMsg
**
*/
void App_TlmGen_RegisterMsg(App_TlmGen_Class*  TlmGenObj,
                            App_TlmMsg_Class*  TlmMsgObj,
                            uint16             Filter
                           )
{

   TlmGen_RegisterMsg(TlmGenObj, TlmMsgObj, APP_TLMGEN_OUTPUT_CONTINUOUS, Filter);


} /* End App_TlmGen_RegisterMsg() */

  
/******************************************************************************
** Function: App_TlmGen_RegisterReqMsg
**
*/
void App_TlmGen_RegisterReqMsg(App_TlmGen_Class* TlmGenObj, /**< Pointer to an instance of an App_TlmGen class  */
                               App_TlmMsg_Class* TlmMsgObj  /**< Pointer to an instance of an App_TlmMsg object */
                              )
{

   TlmGen_RegisterMsg(TlmGenObj, TlmMsgObj, APP_TLMGEN_OUTPUT_ON_REQUEST, 0);

} /* End App_TlmGen_RegisterReqMsg() */


/******************************************************************************
** Function:  App_TlmGen_RequestMsg
**
*/
void App_TlmGen_RequestMsg(App_TlmGen_Class* TlmGenObj, /**< Pointer to an instance of an App_TlmGen class   */
                           uint16            TlmMsgId,  /**< ID used when App_TlmMsg_Constructor() called    */
                           uint16            ReqCnt     /**< Number of times msg should be sent by Execute() */
                          )
{

   App_TlmMsg_Class* TlmMsgObj;

   TlmMsgObj = TlmGenObj->FirstMsg;
   
   while (TlmMsgObj != NULL)
   {

      if (TlmMsgObj->Id == TlmMsgId && TlmMsgObj->OutputType == APP_TLMGEN_OUTPUT_ON_REQUEST)
         
         App_TlmMsg_SetReqCnt(TlmMsgObj, ReqCnt);

      TlmMsgObj = TlmMsgObj->NextMsgPtr;
      
   } /* End if while loop */

} /* End App_TlmGen_RequestMsg() */


/******************************************************************************
** Function: TlmGen_RegisterMsg
**
*/
static void TlmGen_RegisterMsg (App_TlmGen_Class*     TlmGenObj,
                                App_TlmMsg_Class*     TlmMsgObj,
                                App_TlmMsg_OutputType OutputType,
                                uint16                FilterLmt)
{

   if (TlmGenObj->FirstMsg == NULL)
   {
      TlmGenObj->FirstMsg = TlmMsgObj;
   }
   else
   {
      App_TlmMsg_SetLink(TlmGenObj->LastMsg, TlmMsgObj);
   }

   TlmGenObj->LastMsg = TlmMsgObj;

   App_TlmMsg_SetGenParams(TlmMsgObj, OutputType, FilterLmt);


} /* End TlmGen_RegisterMsg() */

/* end of file */
