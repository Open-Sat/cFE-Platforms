/* 
** File:
**   $Id: app_msg.c 1.2 2009/11/17 10:49:17EST dmccomas Exp  $
**
** Purpose: Implement the GN&C Framework Utility message class.
**
** Notes
**   1. Event messages need to identify the message because the same
**      EVS ID is used for each message type.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2009/11/17 10:49:17EST $
** $Revision: 1.2 $
** $Log: app_msg.c  $
** Revision 1.2 2009/11/17 10:49:17EST dmccomas 
** Updated OS_ calls to CFE_PSP_ calls
** Revision 1.1 2008/06/21 08:19:42EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:32EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.5 2006/10/23 14:13:10EDT dcmccomas 
** 
** Revision 1.4 2006/06/13 11:39:15EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.3 2006/05/01 09:24:32EDT dcmccomas 
** 
** Revision 1.2 2006/04/06 08:55:39EDT dcmccomas 
** 
** Revision 1.1 2006/03/23 15:19:12EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Include Files:
*/

#include "app_frame_cfe_events.h"
#include "app_msg_priv.h"

#include <string.h>

#include "cfe_psp.h"
#include "cfe_error.h"
#include "cfe_evs.h"


/*
** Local Functions
*/

static boolean DispatchFunc (      App_Msg_Class*   MsgObj,
                             const CFE_SB_MsgPtr_t  MsgPtr);

/*
** Exported Functions
*/


/******************************************************************************
** Function: App_Msg_Constructor
**
** Notes:
**    1. Since this is the base class Virtual.Dispatch.Data shoud not be
**       needed but initialize it for completeness.
**
*/
void App_Msg_Constructor(App_Msg_Class*   MsgObj,
                         const char*      MsgName,
                         CFE_SB_MsgId_t   MsgId,
                         uint16           UserDataLen,
                         App_Msg_FuncPtr  FuncPtr,
                         void*            ObjPtr
                         )
{

   App_Msg_ConstructorBase(MsgObj, MsgName, MsgId, UserDataLen,
                           DispatchFunc, MsgObj);

   App_Msg_RegisterFunc(MsgObj, FuncPtr, ObjPtr);


} /* End App_Msg_Constructor() */



/******************************************************************************
** Function: App_Msg_ConstructorBase
**
** Notes:
**    1. Since this is the base class Virtual.Dispatch.Data shoud not be
**       needed but initialize it for completeness.
**
*/
void App_Msg_ConstructorBase(App_Msg_Class*   MsgObj,
                             const char*      MsgName,
                             CFE_SB_MsgId_t   MsgId,
                             uint16           UserDataLen,
                             App_Msg_DispatchFuncPtr DispatchFunc,
                             void*                   DispatchFuncObj
                             )
{

   CFE_PSP_MemSet(MsgObj,0,sizeof(App_Msg_Class));

   MsgObj->MsgId       = MsgId;
   MsgObj->UserDataLen = UserDataLen;

   strncpy(MsgObj->Name,MsgName,APP_MSG_MAX_NAME_LEN);
   MsgObj->Name[APP_MSG_MAX_NAME_LEN-1] = '\0';

   MsgObj->ProcFunc.Ptr     = NULL;
   MsgObj->ProcFunc.ObjData = NULL;

   MsgObj->Virtual.Dispatch.Function = DispatchFunc;
   MsgObj->Virtual.Dispatch.Data     = DispatchFuncObj;    

   MsgObj->NextMsgPtr = NULL;
   
} /* End App_Msg_ConstructorBase() */



/******************************************************************************
** Function: App_Msg_GetId
**
*/

CFE_SB_MsgId_t App_Msg_GetId(App_Msg_Class*  MsgObj)
{

   return MsgObj->MsgId;

} /* End App_Msg_GetId() */


/******************************************************************************
** Function: DispatchFunc
**
** Notes:
**    1. Local base class DispatchFunc
**    2. It is not considered an error if the function pointer is NULL. Not 
**       sure why a user would do this but it is not prohibited.
**
*/
static boolean DispatchFunc (      App_Msg_Class*   MsgObj,
                             const CFE_SB_MsgPtr_t  MsgPtr)
{


   boolean  ValidMsg = FALSE;
      
   MsgObj->CurDataLen = CFE_SB_GetUserDataLength(MsgPtr);

   if (MsgObj->CurDataLen == MsgObj->UserDataLen)
   {
      if (MsgObj->ProcFunc.Ptr != NULL) 
         ValidMsg = (MsgObj->ProcFunc.Ptr)(MsgObj->ProcFunc.ObjData, (void*)CFE_SB_GetUserData(MsgPtr));

   } /* End if valid length */
   else
   {

      CFE_EVS_SendEvent (APP_MSG_EVS_INVALID_LEN,
                         CFE_EVS_ERROR,
                         "Msg %s Dispatch Err: Msg 0x%04x has invalid len %d.Expected %d",
                         MsgObj->Name,
							    MsgObj->MsgId,
						       MsgObj->CurDataLen,
                         MsgObj->UserDataLen
                         );
  
   } /* End if invalid length */


   if (ValidMsg == TRUE)
   
      MsgObj->ValidCnt++;

   else
      
      MsgObj->InvalidCnt++;


   return ValidMsg;

} /* End DispatchFunc () */


/******************************************************************************
** Function: App_Msg_DispatchFunc
**
*/
boolean App_Msg_DispatchFunc (      App_Msg_Class*   MsgObj,
                              const CFE_SB_MsgPtr_t  MsgPtr)

{

   boolean RetVal = FALSE;

   if (*MsgObj->Virtual.Dispatch.Function != NULL)
      
      RetVal = (*MsgObj->Virtual.Dispatch.Function)(MsgObj,MsgPtr);


   return RetVal;

} /* End App_Msg_DispatchFunc() */



/******************************************************************************
** Function: App_Msg_Register
**
*/
void App_Msg_RegisterFunc(App_Msg_Class*   MsgObj,
                          App_Msg_FuncPtr  FuncPtr,
                          void*            ObjPtr)
{


   MsgObj->ProcFunc.Ptr     = FuncPtr;
   MsgObj->ProcFunc.ObjData = ObjPtr;


} /* End App_Msg_RegisterFunc() */


/******************************************************************************
** Function: App_Msg_SetLink
**
*/
void App_Msg_SetLink(App_Msg_Class*  MsgObj,
                     App_Msg_Class*  NextMsg)
{

   MsgObj->NextMsgPtr = NextMsg;

} /* End App_Msg_SetLink() */

/* end of file */
