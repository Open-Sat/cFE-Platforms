/* 
** File:
**   $Id: app_pipemgr.c 1.1 2008/06/21 08:19:43EDT dcmccomas Exp  $
**
** Purpose: Implement the GNC Framework pipe manager.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:43EDT $
** $Revision: 1.1 $
** $Log: app_pipemgr.c  $
** Revision 1.1 2008/06/21 08:19:43EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:32EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.10 2006/11/15 14:03:37EST dcmccomas 
** 
** Revision 1.9 2006/11/15 09:55:21EST dcmccomas 
** 
** Revision 1.8 2006/11/14 08:45:40EST dcmccomas 
** 
** Revision 1.7 2006/08/22 09:01:45EDT dcmccomas 
** Added pipe flush and return count for poll and pend.
** Revision 1.6 2006/08/21 14:53:18EDT dcmccomas 
** Add support for new cFE ES performance monitoring API
** Revision 1.5 2006/06/13 11:39:15EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/01 09:24:31EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:55:39EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:55:45EST dcmccomas 
** 
** Revision 1.1 2006/03/23 15:19:13EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Include Files:
*/

#include "app_frame_cfe_events.h"
#include "app_msg_priv.h"
#include "app_pipemgr.h"

#include <string.h>

#include "cfe_error.h"
#include "cfe_es.h"
#include "cfe_evs.h"


/*
** Exported Functions
*/


/******************************************************************************
** Function: App_PipeMgr_Constructor
**
** Notes:
**    1. Need to save EvsIdBase because it's needed each time
**       App_PipeMgr_SubscribeToMsg() is called
**
*/
int32 App_PipeMgr_Constructor(App_PipeMgr_Class*  PipeMgrObj,
                              const char*         PipeName,
                              uint16              PipeDepth,
                              uint32              CfePerfId)
{
 
   int32   SbStatus;


   PipeMgrObj->CfePerfId = CfePerfId;
   PipeMgrObj->PipeDepth = PipeDepth;
   /*
   ** Initialize Message Information
   */

   PipeMgrObj->Msg.SbPtr    = 0;    /* Last message processed info */
   PipeMgrObj->Msg.CurId    = 0;
   PipeMgrObj->Msg.RcvCount = 0;

   PipeMgrObj->Msg.First = NULL; /* Null linked list */
   PipeMgrObj->Msg.Last  = NULL;

   /*
   ** Initialize Pipe Information
   */

   PipeMgrObj->PipeId    = 0;

   strncpy(PipeMgrObj->Name,PipeName,APP_PIPEMGR_MAX_NAME_LEN);
   PipeMgrObj->Name[APP_PIPEMGR_MAX_NAME_LEN-1] = '\0';

   SbStatus = CFE_SB_CreatePipe (&(PipeMgrObj->PipeId),PipeDepth,PipeName);

   if (SbStatus != CFE_SUCCESS)
   {

      CFE_EVS_SendEvent (APP_PIPEMGR_EVS_PIPE_CREATE_ERR,
                         CFE_EVS_ERROR,
                         "Pipe Mgr %s(Id %d) Pipe Creation Error: cFE SB Status = 0x%04x",
                         PipeMgrObj->Name,
                         PipeMgrObj->PipeId,
                         SbStatus);
   }

   return SbStatus;

} /* End App_PipeMgr_Constructor() */


/******************************************************************************
** Function: App_PipeMgr_Flush
**
*/
int32 App_PipeMgr_Flush(App_PipeMgr_Class*  PipeMgrObj)
{

   int32           SbStatus = CFE_SUCCESS;
   boolean         PipeHasMsg = TRUE;


   PipeMgrObj->Msg.RcvCount = 0;

   while ( PipeHasMsg && (PipeMgrObj->Msg.RcvCount < PipeMgrObj->PipeDepth) ) 
   {
   
      SbStatus = CFE_SB_RcvMsg(&(PipeMgrObj->Msg.SbPtr),
                               PipeMgrObj->PipeId,
                               CFE_SB_POLL);

      switch (SbStatus) 
      {

         case CFE_SB_NO_MESSAGE:
         case CFE_SB_TIME_OUT:
            /*
            ** Neither of these cases are considered errors. In each
            ** case no message needs to be processed and the loop should 
            ** be exited.
            */
            PipeHasMsg = FALSE;
            break;

         case CFE_SUCCESS:
            break;

         default:
            break;

         } /* End SbStatus switch */

         if (PipeHasMsg)
            PipeMgrObj->Msg.RcvCount++;

      } /* End while loop */

   return SbStatus;


}/* End App_PipeMgr_Flush() */
                           

/******************************************************************************
** Function: App_PipeMgr_PendForMsg
**
** Notes:
**    1. MsgCount is incremented for error cases to guarantee the message
**       loop with terminate in the event of unforeseen SB errors.
**
*/
int32 App_PipeMgr_PendForMsg(App_PipeMgr_Class*  PipeMgrObj,
                             int32               Timeout,
                             uint16              MsgInputLimit)
{

   int32           SbStatus = CFE_SUCCESS;
   boolean         FoundMsg;
   boolean         PipeHasMsg = TRUE;
   boolean         MsgFuncValid;
   App_Msg_Class*  MsgObj;


   PipeMgrObj->Msg.RcvCount = 0;

   while ( PipeHasMsg && (PipeMgrObj->Msg.RcvCount < MsgInputLimit) ) 
   {

   
      if (Timeout != CFE_SB_POLL)
         CFE_ES_PerfLogExit(PipeMgrObj->CfePerfId);
      
      SbStatus = CFE_SB_RcvMsg(&(PipeMgrObj->Msg.SbPtr),
                               PipeMgrObj->PipeId,
                               Timeout);

      if (Timeout != CFE_SB_POLL)
         CFE_ES_PerfLogEntry(PipeMgrObj->CfePerfId);

      switch (SbStatus) 
      {

         case CFE_SB_NO_MESSAGE:
         case CFE_SB_TIME_OUT:
            /*
            ** Neither of these cases are considered errors. In each
            ** case no message needs to be processed and the loop should 
            ** be exited.
            */
            PipeHasMsg = FALSE;
            break;

         case CFE_SUCCESS:

            FoundMsg = FALSE;
            MsgObj = PipeMgrObj->Msg.First;

            while (MsgObj != NULL)
            {
               
               PipeMgrObj->Msg.CurId = CFE_SB_GetMsgId(PipeMgrObj->Msg.SbPtr);
               
               if (App_Msg_GetId(MsgObj) == PipeMgrObj->Msg.CurId)
               {
                  MsgFuncValid = App_Msg_DispatchFunc (MsgObj, PipeMgrObj->Msg.SbPtr);
                  if (MsgFuncValid == FALSE)
                  {
                     SbStatus |= CFE_SEVERITY_ERROR;
                  }
                  FoundMsg = TRUE;
               }

               MsgObj = MsgObj->NextMsgPtr;

            }/* End Msg Loop */

            if (!FoundMsg)
            {
            
               CFE_EVS_SendEvent (APP_PIPEMGR_EVS_UNREG_MSG_RCVD,
                                  CFE_EVS_ERROR,
                                  "Pipe Mgr %s(Id %d) Unregistered Message 0x%04x Recieved",
                                  PipeMgrObj->Name,
                                  PipeMgrObj->PipeId,
                                  CFE_SB_GetMsgId(PipeMgrObj->Msg.SbPtr));
            
            }

            break;

         default:
            /*
            ** Report software bus error
            */
            CFE_EVS_SendEvent (APP_PIPEMGR_EVS_PIPE_READ_ERR,
                               CFE_EVS_ERROR,
                               "Pipe Mgr %s(Id %d) Pipe Read Error: Unhandled SD rcv status 0x%04x",
                               PipeMgrObj->Name,
                               PipeMgrObj->PipeId,
                               SbStatus);
            break;

         } /* End SbStatus switch */

         if (PipeHasMsg)
            PipeMgrObj->Msg.RcvCount++;

      } /* End while loop */


   return SbStatus;


} /* End PipeMgr_PendForMsg() */



/****************************************************************************** 
** Function: App_PipeMgr_PollForMsg
**
*/
int32 App_PipeMgr_PollForMsg(App_PipeMgr_Class*  PipeMgrObj, 
                              uint16              MsgInputLimit)
{

   int32  SbStatus;


   SbStatus = App_PipeMgr_PendForMsg(PipeMgrObj, CFE_SB_POLL, MsgInputLimit);

   return SbStatus;


} /* End App_PipeMgr_PollForMsg() */



/******************************************************************************
** Functon: App_PipeMgr_SubscribeToMsg
**
*/
int32 App_PipeMgr_SubscribeToMsg(App_PipeMgr_Class*  PipeMgrObj,
                                 App_Msg_Class*      MsgObj,
                                 uint16              MaxMsgs)
{
   int32  SubscribeStatus;

   CFE_SB_Qos_t    MsgQos = { APP_PIPEMGR_DEF_SB_QOS_PARAM1,
                              APP_PIPEMGR_DEF_SB_QOS_PARAM2 };

   SubscribeStatus = App_PipeMgr_SubscribeExToMsg(PipeMgrObj, MsgObj, MsgQos, MaxMsgs);


   return SubscribeStatus;

} /* End App_PipeMgr_SubscribeToMsg() */

/******************************************************************************
** Functon: App_PipeMgr_SubscribeExToMsg
**
*/
int32 App_PipeMgr_SubscribeExToMsg(App_PipeMgr_Class*  PipeMgrObj,
                                   App_Msg_Class*      MsgObj,
                                   CFE_SB_Qos_t        Quality,
                                   uint16              MaxMsgs)
{

   int32  SubscribeStatus;

   SubscribeStatus = CFE_SB_SubscribeEx (MsgObj->MsgId, PipeMgrObj->PipeId, 
                                         Quality, MaxMsgs);

   if (SubscribeStatus == CFE_SUCCESS)
   {

      if (PipeMgrObj->Msg.First == NULL)
      {
         PipeMgrObj->Msg.First = MsgObj;
      }
      else
      {
         App_Msg_SetLink(PipeMgrObj->Msg.Last,MsgObj);
      }

      PipeMgrObj->Msg.Last = MsgObj;

   }
   else
   {

      CFE_EVS_SendEvent (APP_PIPEMGR_EVS_MSG_SUBSCRIBE_ERR,
                         CFE_EVS_ERROR,
                         "Pipe Mgr %s(Id %d): Msg 0x%04x subscribe failed. SB status 0x%04x",
                         PipeMgrObj->Name,
                         PipeMgrObj->PipeId,
                         MsgObj->MsgId,
                         SubscribeStatus);

   }


   return SubscribeStatus;

} /* End App_PipeMgr_SubscribeExToMsg() */

/* end of file */
