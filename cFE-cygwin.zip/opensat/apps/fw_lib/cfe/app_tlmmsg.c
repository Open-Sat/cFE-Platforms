/* 
** File:
**   $Id: app_tlmmsg.c 1.1 2008/06/21 08:19:45EDT dcmccomas Exp  $
**
** Purpose: Implement the GN&C Framework Utility telemetry message.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:45EDT $
** $Revision: 1.1 $
** $Log: app_tlmmsg.c  $
** Revision 1.1 2008/06/21 08:19:45EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:34EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/05/01 09:24:33EDT dcmccomas 
** 
** Revision 1.2 2006/04/06 08:55:39EDT dcmccomas 
** 
** Revision 1.1 2006/03/29 12:58:51EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Include Files:
*/

#include "app_tlmmsg_priv.h"

#include <string.h>

/*
** Exported Functions
*/

/******************************************************************************
** Function: App_TlmMsg_Constructor
**
** Notes:
**  1. Setting OutputType to APP_TLMGEN_OUTPUT_ON_REQUEST makes it a non-random
**     value. App_TlmMsg_SetGenParams() is used to set its final value.
** 
*/
void App_TlmMsg_Constructor(App_TlmMsg_Class*  MsgObj,
                            CFE_SB_MsgPtr_t    MsgPtr,
                            const char*        MsgName,
                            CFE_SB_MsgId_t     MsgId,
                            uint16             MsgLen,
                            App_TlmMsg_FuncPtr FuncPtr,
                            void*              ObjDataPtr
                           )
{
 
   CFE_SB_InitMsg(MsgPtr, MsgId, MsgLen, TRUE);

   MsgObj->Id  = MsgId;
   MsgObj->Len = MsgLen;
   MsgObj->Ptr = MsgPtr;

   strncpy(MsgObj->Name,MsgName,APP_TLMMSG_MAX_NAME_LEN);
   MsgObj->Name[APP_TLMMSG_MAX_NAME_LEN-1] = '\0';

   MsgObj->GenFunc.Ptr     = FuncPtr;
   MsgObj->GenFunc.ObjData = ObjDataPtr;

   MsgObj->NextMsgPtr = NULL;

   MsgObj->FilterCnt  = 0;
   MsgObj->FilterLmt  = 0;
   MsgObj->OutputType = APP_TLMGEN_OUTPUT_ON_REQUEST;

} /* End App_TlmMsg_Constructor() */


/******************************************************************************
** Function: App_TlmMsg_SetGenParams
**
*/
void App_TlmMsg_SetGenParams(App_TlmMsg_Class*     MsgObj,
                             App_TlmMsg_OutputType OutputType,
                             uint16                FilterLmt)
{

   MsgObj->FilterLmt  = FilterLmt;
   MsgObj->OutputType = OutputType;

} /* End App_TlmMsg_SetGenParams() */

/******************************************************************************
** Function: App_TlmMsg_SetLink
**
*/
void App_TlmMsg_SetLink(App_TlmMsg_Class*  MsgObj,
                        App_TlmMsg_Class*  NextMsg)
{

   MsgObj->NextMsgPtr = NextMsg;

} /* End App_TlmMsg_SetLink() */

/******************************************************************************
** Function: App_TlmMsg_SetReqCnt
**
*/
void App_TlmMsg_SetReqCnt(App_TlmMsg_Class*  MsgObj,
                          uint16             ReqCnt)
{

   MsgObj->FilterCnt = ReqCnt;

} /* End App_TlmMsg_SetReqCnt() */


/******************************************************************************
** Function: App_TlmMsg_TimeToSend
**
** Notes:
**  1. FilterCnt is used differently depending upon the OutputType. For
**     continuous messages it is incremented and tested against a limit. For
**     requested messages it is decremented until it reaches zero.
**
*/
boolean App_TlmMsg_TimeToSend(App_TlmMsg_Class* TlmMsgObj)
{

   boolean SendMsg = FALSE;

   if (TlmMsgObj->OutputType == APP_TLMGEN_OUTPUT_CONTINUOUS)
   {
         
      TlmMsgObj->FilterCnt++;

      if ( TlmMsgObj->FilterCnt >= TlmMsgObj->FilterLmt)
      {

         SendMsg = TRUE;
         TlmMsgObj->FilterCnt = 0;

      }
   } /* End if a continuous message */
   else
   {
      if (TlmMsgObj->FilterCnt > 0)
      {
            
         SendMsg = TRUE;
         TlmMsgObj->FilterCnt--;

      }
   } /* End if a requested message */
            
   return SendMsg;

} /* End App_TlmMsg_TimeToSend() */

/* end of file */
