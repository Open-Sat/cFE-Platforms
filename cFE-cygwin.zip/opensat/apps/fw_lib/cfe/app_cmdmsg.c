/* 
** File:
**   $Id: app_cmdmsg.c 1.2 2009/11/17 10:49:13EST dmccomas Exp  $
**
** Purpose: Implement the GN&C Framework command message class.
**
** Notes
**   1. Event messages need to identify the message because the same
**      EVS ID is used for each command message type.
**   2. Cmd.Cnt is used to automatically assign function codes when 
**      App_CmdMsg_RegFuncAuto() is used. When App_CmdMsg_RegFunc() is used
**      Cmd.Cnt maintains a count of registered functions.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
**
** $Date: 2009/11/17 10:49:13EST $
** $Revision: 1.2 $
** $Log: app_cmdmsg.c  $
** Revision 1.2 2009/11/17 10:49:13EST dmccomas 
** Updated OS_ calls to CFE_PSP_ calls
** Revision 1.1 2008/06/21 08:19:41EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:31EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.9 2007/01/24 14:58:23EST dcmccomas 
** New APP_CMDMSG_EVS_INVALID_FUNC_REG text "Cmd Msg %s(Id 0x%04x): Function code %d outside valid range %d thru %d
** Revision 1.8 2006/10/23 14:13:10EDT dcmccomas 
** 
** Revision 1.7 2006/10/23 13:50:16EDT dcmccomas 
** 
** Revision 1.6 2006/07/26 08:09:45EDT dcmccomas 
** Made change to dispatch's invalid command length event message.
** Revision 1.5 2006/06/13 11:39:14EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/10 13:35:06EDT dcmccomas 
** 
** Revision 1.3 2006/05/01 09:24:31EDT dcmccomas 
** 
** Revision 1.2 2006/04/06 08:55:39EDT dcmccomas 
** 
** Revision 1.1 2006/03/23 15:19:10EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
*/

/*
** Include Files:
*/

#include "app_frame_cfe_events.h"
#include "app_msg_priv.h"
#include "app_cmdmsg_priv.h"

#include <string.h>

#include "cfe_psp.h"
#include "cfe_error.h"
#include "cfe_evs.h"


/*
** File Function Prototypes
*/

static void LoadFuncRec(App_CmdMsg_FuncRec*   FuncRec,
                        const char*           CmdName,
                        const App_Msg_FuncPtr FuncPtr,
                        uint16                ParamLen,
                        void*                 ObjPtr
                       );

static boolean UnregisteredCmd(      void* CmdObj, 
                               const void* CmdParam);

/*
** Exported Functions
*/


/******************************************************************************
** Function: App_CmdMsg_Constructor
**
** Notes:
**    1. Even though an unregistered command should never be called, the 
**       command list is initialized with an undefined command function
**       pointer just to make sure there aren't any dangling pointers.
**
*/
void App_CmdMsg_Constructor(App_CmdMsg_Class*  CmdMsgObj,
                            const char*        MsgName,
                            CFE_SB_MsgId_t     MsgId,
                            App_CmdMsg_FuncRec FuncBuf[],
                            uint16             FuncMax
                           )
{
 

   uint16              Cmd;
   App_CmdMsg_FuncRec  UnregCmdFuncRec;

   App_Msg_ConstructorBase(&CmdMsgObj->Parent,
                           MsgName, MsgId, 0, 
                           App_CmdMsg_DispatchFunc,
                           CmdMsgObj);

   /*
   ** Initialized App_CmdMsg subclass data
   */

   CmdMsgObj->CurCmdCode  = 0;
   CmdMsgObj->CurChecksum = 0;

   CmdMsgObj->Cmd.CntMax  = FuncMax;
   CmdMsgObj->Cmd.Func    = FuncBuf;

   strcpy(UnregCmdFuncRec.Name,"NULL");
   UnregCmdFuncRec.ParamLen = 0;
   UnregCmdFuncRec.Ptr      = UnregisteredCmd;
   UnregCmdFuncRec.ObjData  = CmdMsgObj;
      
   strcpy(CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_RESET_CNT].Name,"CmdMsg RstCnt");
   CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_RESET_CNT].ParamLen = 0;
   CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_RESET_CNT].Ptr      = App_CmdMsg_ResetCntCmd;
   CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_RESET_CNT].ObjData  = CmdMsgObj;
    
   strcpy(CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_NOOP].Name,"CmdMsg Noop");
   CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_NOOP].ParamLen = 0;
   CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_NOOP].Ptr      = App_CmdMsg_NoOpCmd;
   CmdMsgObj->Cmd.Func[APP_CMDMSG_FC_NOOP].ObjData  = CmdMsgObj;
    
   CmdMsgObj->Cmd.Cnt = CmdMsgObj->Cmd.CntMax;

   for (Cmd=APP_CMDMSG_FC_CLIENT_START; Cmd < CmdMsgObj->Cmd.CntMax; Cmd++)
   {

      CFE_PSP_MemCpy(&(CmdMsgObj->Cmd.Func[Cmd]),&UnregCmdFuncRec, sizeof(App_CmdMsg_FuncRec));

   } /* End command loop */


} /* End App_CmdMsg_Constructor() */


/******************************************************************************
** Function: App_CmdMsg_ConstructorAuto
**
** Notes:
**    1. Override base constructor's Cmd.Cnt because the automatic function
**       code assignment uses the count as the function code when commands
**       are registered via App_CmdMsg_RegFuncAuto().
**
*/
void App_CmdMsg_ConstructorAuto(App_CmdMsg_Class*  CmdMsgObj,
                                const char*        MsgName,
                                CFE_SB_MsgId_t     MsgId,
                                App_CmdMsg_FuncRec FuncBuf[],
                                uint16             FuncMax
                               )
{

   App_CmdMsg_Constructor(CmdMsgObj, MsgName, MsgId, FuncBuf, FuncMax);

   CmdMsgObj->Cmd.Cnt = (uint16)APP_CMDMSG_FC_CLIENT_START;

}

/******************************************************************************
** Function: App_CmdMsg_DispatchFunc
**
*/

boolean App_CmdMsg_DispatchFunc (      App_Msg_Class*   MsgObj,
                                 const CFE_SB_MsgPtr_t  MsgPtr) 
{

   App_CmdMsg_Class* CmdMsgObj = (App_CmdMsg_Class*)MsgObj->Virtual.Dispatch.Data;

   boolean  ValidCmd = FALSE;
   App_CmdMsg_FuncRec*  CmdFunc;

   
   CmdMsgObj->Parent.CurDataLen = CFE_SB_GetUserDataLength(MsgPtr);
   CmdMsgObj->CurCmdCode        = CFE_SB_GetCmdCode(MsgPtr);
   CmdMsgObj->CurChecksum       = CFE_SB_GetChecksum(MsgPtr);

   if (CmdMsgObj->CurCmdCode < CmdMsgObj->Cmd.Cnt)
   {

      CmdFunc = &(CmdMsgObj->Cmd.Func[CmdMsgObj->CurCmdCode]);

      if (CmdMsgObj->Parent.CurDataLen == CmdFunc->ParamLen)
      {
       
         if (CFE_SB_ValidateChecksum(MsgPtr) == TRUE)
         {

            ValidCmd = (CmdFunc->Ptr)(CmdFunc->ObjData, (void*)CFE_SB_GetUserData(MsgPtr));

         } /* End if valid checksum */
         else
         {
         
            CFE_EVS_SendEvent (APP_CMDMSG_EVS_INVALID_CHECKSUM,
                               CFE_EVS_ERROR,
                               "Cmd Msg %s(Id 0x%04x) Dispatch Error: Invalid (non-zero) checksum %d for cmd %d",
							          CmdMsgObj->Parent.Name,
							          CmdMsgObj->Parent.MsgId,
                               CmdMsgObj->CurChecksum,
							          CmdMsgObj->CurCmdCode);
         }

      } /* End if valid length */
      else
      {

         CFE_EVS_SendEvent (APP_CMDMSG_EVS_INVALID_LEN,
                            CFE_EVS_ERROR,
                            "Cmd Msg %s(Id %d) Dispatch Err: Invalid len %d (Expected %d) for cmd %d",
                            CmdMsgObj->Parent.Name,
                            CmdMsgObj->Parent.MsgId,
                            CmdMsgObj->Parent.CurDataLen,
                            CmdFunc->ParamLen,
                            CmdMsgObj->CurCmdCode);

      }

   } /* End if valid function code */
   else
   {
   
      CFE_EVS_SendEvent (APP_CMDMSG_EVS_INVALID_FUNC_CODE,
                         CFE_EVS_ERROR,
                         "Cmd Msg %s(Id 0x%04x) Dispatch Error: Invalid function code %d",
                         CmdMsgObj->Parent.Name,
                         CmdMsgObj->Parent.MsgId,
                         CmdMsgObj->CurCmdCode);
   
   } /* End if invalid function code */


   if (ValidCmd == TRUE)
   {
      if (CmdMsgObj->CurCmdCode != APP_CMDMSG_FC_RESET_CNT)
         CmdMsgObj->Parent.ValidCnt++;
   
   }
   else
      CmdMsgObj->Parent.InvalidCnt++;

   return ValidCmd;

} /* End App_CmdMsg_DispatchFunc() */


/******************************************************************************
** Function: App_CmdMsg_NoOpCmd
**
** Notes:
**    1. The cFE adds the task name to the events so this event message will
**       be unique for each task.
**
*/

boolean App_CmdMsg_NoOpCmd(      void*  CmdObj, 
                           const void*  CmdParam)
{

   App_CmdMsg_Class* CmdMsgObj = (App_CmdMsg_Class*)CmdObj;

   CFE_EVS_SendEvent (APP_CMDMSG_EVS_NOOP_CMD,
                      CFE_EVS_INFORMATION,
                      "Cmd Msg %s(Id 0x%4x): No operation command received",
                      CmdMsgObj->Parent.Name,
                      CmdMsgObj->Parent.MsgId);

   return TRUE;


} /* End App_CmdMsg_NoOpCmd() */


/******************************************************************************
** Function: CmdMsg_RegFunc
**
** Notes:
**    1. Since the application is supplying the function codes 
**       CmdMsgObj->Cmd.Cnt is set once during construction to
**       the maximum allowed number of commands.
*/
void App_CmdMsg_RegFunc(App_CmdMsg_Class*     CmdMsgObj,
                        const char*           CmdName,
                        const App_Msg_FuncPtr FuncPtr,
                        void*                 ObjPtr,
                        uint16                ParamLen,
                        uint16                FuncCode)
{


   if ( (FuncCode >= APP_CMDMSG_FC_CLIENT_START) &&
        (FuncCode < CmdMsgObj->Cmd.CntMax) )
   {

      LoadFuncRec(&CmdMsgObj->Cmd.Func[FuncCode], CmdName, FuncPtr, ParamLen, ObjPtr);

   }
   else
   {

      CFE_EVS_SendEvent (APP_CMDMSG_EVS_INVALID_FUNC_REG,
                         CFE_EVS_ERROR,
                         "Cmd Msg %s(Id 0x%04x): Function code %d outside valid range %d thru %d",
                         CmdMsgObj->Parent.Name,
                         CmdMsgObj->Parent.MsgId,
                         FuncCode,
                         APP_CMDMSG_FC_CLIENT_START,
                         (CmdMsgObj->Cmd.CntMax-1));
 
   }


} /* End App_CmdMsg_RegFunc() */


/******************************************************************************
** Function: CmdMsg_RegFuncAuto
**
** Notes:
**    None
**
*/
void App_CmdMsg_RegFuncAuto(App_CmdMsg_Class*     CmdMsgObj,
                            const char*           CmdName,
                            const App_Msg_FuncPtr FuncPtr,
                            void*                 ObjPtr,
                            uint16                ParamLen)
{


   if (CmdMsgObj->Cmd.Cnt < CmdMsgObj->Cmd.CntMax)
   {

      LoadFuncRec(&CmdMsgObj->Cmd.Func[CmdMsgObj->Cmd.Cnt], CmdName, FuncPtr, ParamLen, ObjPtr);

      CmdMsgObj->Cmd.Cnt++;

   }
   else
   {

      CFE_EVS_SendEvent (APP_CMDMSG_EVS_MAX_CMD_REG,
                         CFE_EVS_ERROR,
                         "Cmd Msg %s(Id 0x%04x): Registration exceeds max cmds of %d",
                         CmdMsgObj->Parent.Name,
                         CmdMsgObj->Parent.MsgId,
                         CmdMsgObj->Cmd.CntMax);
 
   }


} /* End App_CmdMsg_RegFuncAuto() */


/******************************************************************************
** Function: App_CmdMsg_ResetCntCmd
**
** Notes:
**    1. The cFE adds the task name to the events so this event message will
**       be unique for each task.
*/

boolean App_CmdMsg_ResetCntCmd(      void*  CmdObj, 
                               const void*  CmdParam)
{

   App_CmdMsg_Class*  CmdMsgObj = (App_CmdMsg_Class*)CmdObj;

   CmdMsgObj->Parent.ValidCnt   = 0;
   CmdMsgObj->Parent.InvalidCnt = 0;

   return TRUE;

} /* End App_CmdMsg_ResetCntCmd() */

/******************************************************************************
** Function: LoadFuncRec
**
** Notes:
**    None
**
*/
static void LoadFuncRec(App_CmdMsg_FuncRec*   FuncRec,
                        const char*           CmdName,
                        const App_Msg_FuncPtr FuncPtr,
                        uint16                ParamLen,
                        void*                 ObjPtr
                       )
{

      strncpy(FuncRec->Name,CmdName,APP_CMDMSG_MAX_NAME_LEN);
      FuncRec->Name[APP_CMDMSG_MAX_NAME_LEN-1] = '\0';

      FuncRec->Ptr      = FuncPtr;
      FuncRec->ObjData  = ObjPtr;
      FuncRec->ParamLen = ParamLen;

} /* End LoadFuncRec() */


/******************************************************************************
** Function: UnregisteredCmd 
**
** Notes:
**
**    1. This function is used to populate the default function dispatch table
**       so there aren't any dangling pointers.
**
*/

static boolean UnregisteredCmd(      void* CmdObj, 
                               const void* CmdParam)
{

   App_CmdMsg_Class*  CmdMsgObj = (App_CmdMsg_Class*)CmdObj;

   CFE_EVS_SendEvent (APP_CMDMSG_EVS_UNDEF_CMD,
                      CFE_EVS_ERROR,
                      "Cmd Msg %s(Id 0x%04x): Unregister command function %d received",
                      CmdMsgObj->Parent.Name,
                      CmdMsgObj->Parent.MsgId,
                      CmdMsgObj->CurCmdCode);

   return FALSE;

} /* End UnregisteredCmd() */


/* end of file */
