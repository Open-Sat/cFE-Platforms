/*
** 
** Purpose: Define private methods for the app_msg class. 
**
** $Id: app_msg_priv.h 1.1 2008/06/21 08:19:42EDT dcmccomas Exp  $
**
** Notes:
**   1. This is the private header. See app_msg.h's notes.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:42EDT $
** $Revision: 1.1 $
** $Log: app_msg_priv.h  $
** Revision 1.1 2008/06/21 08:19:42EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:32EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/07/27 14:28:09EDT dcmccomas 
** Removed doxygen markup.
** Revision 1.2 2006/06/13 11:39:14EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.1 2006/05/01 09:26:37EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_msg_priv_
#define _app_msg_priv_

/*
** Includes
*/

#include "app_msg.h"


/*
** Exported Functions
*/

/*
** Purpose:  Initialize a message processing object
**
** Notes:
**   1. This function (or another constructor) must be called prior to any other
**      App_Msg_ functions
**   2. This constructor should only be used by subclasses which is why it is
**      defined as private. Typically only the framework would need to subclass
**      this class.
**   3. MsgName length (including terminating null) must be less than or equal
**      to APP_MSGPROC_MAX_NAME_LEN.
**
*/
void App_Msg_ConstructorBase(App_Msg_Class*   MsgObj,      /**< Pointer to an instance of a App_Msg class  */
                             const char*      MsgName,     /**< Pointer to a string used to ID the msg     */
                             CFE_SB_MsgId_t   MsgId,       /**< The cFE SB message ID for the msg          */
                             uint16           UserDataLen, /**< Length of the message data in bytes        */
                             App_Msg_DispatchFuncPtr DispatchFunc,    /**< Virtual Dispatch function ptr   */
                             void*                   DispatchFuncObj  /**< DIspatch function obj data ptr  */
                            );



/*
** Purpose:  Dispatch a message processing object's processing function
**
** Notes:
**   1. This is a virtual function 
**
*/
boolean App_Msg_DispatchFunc (      App_Msg_Class*  MsgObj,
                              const CFE_SB_MsgPtr_t MsgPtr);




/*
** Purpose:  Set a message's link
**
*/

void App_Msg_SetLink(App_Msg_Class*  MsgObj,  /**< Pointer to an instance of a msg class */
                     App_Msg_Class*  NextMsg  /**< Pointer to msg to be linked           */
                     );

#endif /* _app_msg_priv_ */
