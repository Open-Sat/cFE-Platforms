/* 
** File:
**   $Id: app_timesvcs.c 1.1 2008/06/21 08:19:44EDT dcmccomas Exp  $
**
** Purpose: Implements Application's Time Services Functions
**
** $Date: 2008/06/21 08:19:44EDT $
** $Revision: 1.1 $
** $Log: app_timesvcs.c  $
** Revision 1.1 2008/06/21 08:19:44EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/cfe/project.pj
** Revision 1.1 2008/06/12 08:24:33EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.3 2006/05/11 13:24:06EDT myyang 
** - Removed TimeSvcs singleton
** Revision 1.2 2006/03/27 09:25:31EST myyang 
** - Added App_TimeSvcs_RetMissionEpoch() function
** Revision 1.1 2006/03/24 09:18:29EST myyang 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Includes
*/

#include "app_timesvcs.h"

#include "mathconstants.h"

/*
** File Data
*/

/*
** Local Function Prototypes
*/

static double SubSecConvert(uint32 Subseconds);

/*
** Exported Functions
*/

/******************************************************************************
** Function:  App_TimeSvcs_Constructor()
**
*/
void App_TimeSvcs_Constructor(App_TimeSvcs_Class*	App_TimeSvcs_Obj,
							  double				App_MissionEpoch)
{

	App_TimeSvcs_Obj->App_TimeSvcs_MissionEpoch = App_MissionEpoch;

} /* end App_TimeSvcs_Constructor() */

/******************************************************************************
** Function:  App_TimeSvcs_SysTime()
**
*/
double App_TimeSvcs_SysTime(CFE_TIME_SysTime_t Time)
{

	return((double)(Time.Seconds) + SubSecConvert(Time.Subseconds));

}  /*  end App_TimeSvcs_SysTime()  */


/******************************************************************************
** Function:  App_TimeSvcs_JDTime()
**
*/
double App_TimeSvcs_JDTime(App_TimeSvcs_Class*	App_TimeSvcs_Obj,
						   CFE_TIME_SysTime_t Time)
{

	return(App_TimeSvcs_Obj->App_TimeSvcs_MissionEpoch + (App_TimeSvcs_SysTime(Time)/(double)MTH_SECS_PER_DAY));

}  /*  end App_TimeSvcs_JDTime()  */

/******************************************************************************
** Function:  App_TimeSvcs_RetMissionEpoch()
**
*/
double App_TimeSvcs_RetMissionEpoch(App_TimeSvcs_Class*	App_TimeSvcs_Obj)
{
	return(App_TimeSvcs_Obj->App_TimeSvcs_MissionEpoch);

} /* end App_TimeSvcs_RetMissionEpoch() */


/******************************************************************************
** Function:  SubSecConvert()
**
** Purpose:
**	  1. Converts subseconds component of CFE Time to double.
*/
static double SubSecConvert(uint32 Subseconds)
{

	return((double)Subseconds * INVERSE_OF_2_TO_THE_32_POWER);

}  /*  end SubSecConvert()  */

/*  end of file  */
