/* 
** File:
**   $Id: app_frame.c 1.1 2008/06/21 08:19:49EDT dcmccomas Exp  $
**
** Purpose: Implement the class to manage the framework components of a GN&C Application.
**
** Notes
**   1. Only one application frame can exist per Application
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. GN&C FSW Developer's Guide
**   3. GN&C FSW Framework Specification
**
** $Date: 2008/06/21 08:19:49EDT $
** $Revision: 1.1 $
** $Log: app_frame.c  $
** Revision 1.1 2008/06/21 08:19:49EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.1 2008/06/12 08:24:38EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision on laptop late for LRO and before FSBL
** Update doxygen. Add FaultCnt and functions to allocate ID resources
** Revision 1.15 2007/01/30 09:50:21EST dcmccomas 
** Change cFE ES call to CFE_ES_GetResetType and renamed variables accordingly
** Revision 1.14 2006/11/09 12:57:04EST dcmccomas 
** 
** Revision 1.13 2006/11/02 12:17:38EST dcmccomas 
** Added FcMethod to App_Frame_Class
** Revision 1.12 2006/11/01 09:12:41EST dcmccomas 
** Added changes for auto vs user defined cmd function code
** Revision 1.11 2006/10/23 15:33:02EDT dcmccomas 
** 
** Revision 1.10 2006/08/21 14:52:25EDT dcmccomas 
** Add support for new cFE ES performance monitoring API
** Revision 1.9 2006/07/27 14:31:33EDT dcmccomas 
** Modified App_Frame constructor to pass in maximum fault detector count.
** Revision 1.8 2006/06/13 11:35:13EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.7 2006/05/26 14:26:36EDT dcmccomas 
** 
** Revision 1.6 2006/05/10 13:34:08EDT dcmccomas 
** 
** Revision 1.5 2006/05/01 09:21:46EDT dcmccomas 
** 
** Revision 1.4 2006/04/06 08:56:25EDT dcmccomas 
** 
** Revision 1.3 2006/03/28 14:56:55EST dcmccomas 
** 
** Revision 1.2 2006/03/24 14:10:51EST dcmccomas 
** Added "app_" prefix to cfe and gnc framework objects that are included by app_frame
** Revision 1.1 2006/03/24 07:13:56EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.5 2006/03/09 10:33:58EST jcwu 
** Added new-line at the end (DCR 354).
** Revision 1.4 2006/01/31 10:25:15EST dcmccomas 
** 
** Revision 1.3 2006/01/20 14:36:47EST dcmccomas 
** Completed unit test
** Revision 1.2 2006/01/19 15:17:17EST dcmccomas 
** Removed cFE Table stub
** Revision 1.1 2005/11/30 09:10:57EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.3 2005/11/29 08:23:28EST dcmccomas 
** 
** Revision 1.2 2005/11/09 07:52:32EST dcmccomas 
** Added doxygen markup
**
*/

/*
** Includes
*/

#include "app_frame.h"
#include "app_frame_gnc_events.h"
#include "app_tlmgen_priv.h"
#include "app_faultrep_priv.h"
#include "app_databus_priv.h"
#include "app_housekp_priv.h"

/*
** Macro Definitions
*/

#define EVS_ID(Offset)  ((uint16)(AppFrameObj->EventCnt + Offset)) 

/*
** Exported Functions
*/


/******************************************************************************
** Function: App_Frame_Constructor
**
** Notes:
**   1. The framework always initializes the same way regardless of the cFE's
**      CFE_ES_GetAppRestartType() return value.
**   2. The CFE_EVS_Register() can be overridden by an application if needed.
*/

App_Frame_Init App_Frame_Constructor(App_Frame_Class*          AppFrameObj,
                                     double                    MissionEpoch,
                                     uint32                    CfePerfId,
                                     const App_Frame_Cmd*      Cmd,
                                     const App_Frame_HouseKp*  HouseKp,
                                     const App_Frame_DataSrc*  DataSrc,
                                     const App_Frame_FaultRep* FaultRep)
{

   App_Frame_Init  Init;


   /*
   ** Pre-layer initialization
   */

   AppFrameObj->EvsIdCnt   = APP_FRAME_GNC_FIXED_EVENT_MAX; /* Start after fixed Ids */
   AppFrameObj->FaultIdCnt = 0;

   /*
   ** Intialize cFE
   */

   Init.CfeAppRegStatus = CFE_ES_RegisterApp();
   Init.CfeResetType    = CFE_ES_GetResetType(&Init.CfeResetSubtype);

   CFE_EVS_Register(NULL,0,0);

   /*
   ** Intialize Framework cFE Utility Layer
   */

   App_TimeSvcs_Constructor(&AppFrameObj->TimeSvcs, MissionEpoch);

   Init.CmdPipeStatus = App_PipeMgr_Constructor(&AppFrameObj->CmdPipeMgr,
                                                Cmd->PipeName,
                                                Cmd->PipeDepth,
                                                CfePerfId);
   
   AppFrameObj->FcMethod = Cmd->FcMethod;

   if (Cmd->FcMethod == APP_FRAME_CMD_FC_AUTO)
   {

      App_CmdMsg_ConstructorAuto(&AppFrameObj->CmdMsg,
                                 Cmd->MsgName, 
                                 Cmd->MsgId,
                                 Cmd->RegistrationBuf,
                                 Cmd->RegistrationMax);

   } /* End if FC assignment method == APP_FRAME_CMD_FC_AUTO */
   else
   {
   
      App_CmdMsg_Constructor(&AppFrameObj->CmdMsg,
                             Cmd->MsgName, 
                             Cmd->MsgId,
                             Cmd->RegistrationBuf,
                             Cmd->RegistrationMax);
   
   } /* End if FC assignment method == APP_FRAME_CMD_FC_USER */



   App_PipeMgr_SubscribeToMsg(&AppFrameObj->CmdPipeMgr,
                              &AppFrameObj->CmdMsg.Parent,
                              Cmd->MsgOnPipeMax);

   App_TlmGen_Constructor(&AppFrameObj->TlmGen,
                          &AppFrameObj->EvsIdCnt);

   /*
   ** Intialize Framework GN&C Utility Layer
   */

   App_FaultRep_Constructor(&(AppFrameObj->FaultRep),
                            FaultRep->FaultIdCnt,
                            &AppFrameObj->EvsIdCnt);

   if (Cmd->FcMethod == APP_FRAME_CMD_FC_AUTO)
   {

      App_CmdMsg_RegFuncAuto(&AppFrameObj->CmdMsg,
                             "FaultRep Clear",
                             App_FaultRep_ClearFaultDetCmd, 
                             &(AppFrameObj->FaultRep), 
                             sizeof(App_FaultRep_ClearFaultDetCmdParam));

      App_CmdMsg_RegFuncAuto(&AppFrameObj->CmdMsg,
                             "FaultRep Config",
                             App_FaultRep_ConfigFaultDetCmd, 
                             &(AppFrameObj->FaultRep),
                             sizeof(App_FaultRep_ConfigFaultDetCmdParam));

   } /* End if FC assignment method == APP_FRAME_CMD_FC_AUTO */
   else
   {
   
      App_CmdMsg_RegFunc(&AppFrameObj->CmdMsg,
                         "FaultRep Clear",
                         App_FaultRep_ClearFaultDetCmd, 
                         &(AppFrameObj->FaultRep), 
                         sizeof(App_FaultRep_ClearFaultDetCmdParam),
                         APP_FRAME_FC_FAULTREP_CLEAR);

      App_CmdMsg_RegFunc(&AppFrameObj->CmdMsg,
                         "FaultRep Config",
                         App_FaultRep_ConfigFaultDetCmd, 
                         &(AppFrameObj->FaultRep),
                         sizeof(App_FaultRep_ConfigFaultDetCmdParam),
                         APP_FRAME_FC_FAULTREP_CONFIG);
   
   } /* End if FC assignment method == APP_FRAME_CMD_FC_USER */

   App_TlmMsg_Constructor(&(AppFrameObj->FaultRepTlmMsg),
                         (CFE_SB_Msg_t*)&(AppFrameObj->FaultRep.SbMsg.Hdr),
                          "FaultRep",
                          FaultRep->MsgId,
                          sizeof(App_FaultRep_SbMsg),
                          App_FaultRep_GenTlmMsg, 
                          &(AppFrameObj->FaultRep));

   App_TlmGen_RegisterMsg(&(AppFrameObj->TlmGen),
                          &(AppFrameObj->FaultRepTlmMsg), 1); /* Send every cycle */

   App_DataBus_Constructor(&AppFrameObj->DataBus,
                           DataSrc->RegistrationBuf,
                           DataSrc->RegistrationMax,
	                        &AppFrameObj->EvsIdCnt);

   App_HouseKp_Constructor(&AppFrameObj->HouseKp,
                           &AppFrameObj->CmdPipeMgr,
                           &AppFrameObj->CmdMsg,
                           &AppFrameObj->FaultRep,
                           &AppFrameObj->TlmGen,
                           HouseKp->ReqMsgId,
                           HouseKp->ReqMsgLen,
                           HouseKp->ReplyMsgId,
                           &AppFrameObj->EvsIdCnt);

   Init.StartingEvsId = AppFrameObj->EvsIdCnt;

   return Init;
   
} /* End App_Frame_Constructor() */


/******************************************************************************
** Function: App_Frame_AllocateEvsIds
**
** Notes:
**   1. The framework always initializes the same way regardless of the cFE's
**      CFE_ES_GetAppRestartType() return value.
**   2. The CFE_EVS_Register() can be overridden by an application if needed.
*/
uint16 App_Frame_AllocateEvsIds(App_Frame_Class* AppFrameObj,
                                uint16           EvsIdReqCnt)
{
 
   uint16 UserEvsId = AppFrameObj->EvsIdCnt;

   AppFrameObj->EvsIdCnt += EvsIdReqCnt;

   return UserEvsId;

} /* End App_Frame_AllocateEvsIds() */


/******************************************************************************
** Function: App_Frame_AllocateFaultIds
**
*/
uint16 App_Frame_AllocateFaultIds(App_Frame_Class* AppFrameObj,
                                  uint16           FaultIdReqCnt)
{
 
   uint16 UserFaultId = AppFrameObj->FaultIdCnt;

   AppFrameObj->FaultIdCnt += FaultIdReqCnt;

   return  UserFaultId;

} /* End App_Frame_AllocateFaultIds() */

/* end of file */
