/* 
** File:
**   $Id: framework.c 1.2 2009/11/17 10:49:53EST dmccomas Exp  $
**
** Purpose: Application framework entry point
**
** Notes
**   1. This routine is called when fw_cfe shared library is loaded
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
**
** $Date: 2009/11/17 10:49:53EST $
** $Revision: 1.2 $
** $Log: framework.c  $
** Revision 1.2 2009/11/17 10:49:53EST dmccomas 
** Updated OS_ function calls to CFE_PSP_ function calls
** Revision 1.1 2008/06/21 08:19:51EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.1 2008/06/12 08:24:39EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.1 2006/07/27 13:26:37EDT jjhageman 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Include Files:
*/

#include "osapi.h"

/*
** Local Functions
*/

/******************************************************************************
** Application framework entry function
**
*/
uint32 Framework_Init(void)
{

  OS_printf("GNC-FSW Framework Loaded\n");
  return OS_SUCCESS;

} /* End of Framework_Init() */

/* end of file */
