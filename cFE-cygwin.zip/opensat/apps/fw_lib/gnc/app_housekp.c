/* 
** File:
**   $Id: app_housekp.c 1.2 2009/11/17 10:49:49EST dmccomas Exp  $
**
** Purpose: Implement the GN&C Framework house keeping class.
**
** Notes
**   1. Event messages need to identify the message because the same
**      EVS ID is used for each message type.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2009/11/17 10:49:49EST $
** $Revision: 1.2 $
** $Log: app_housekp.c  $
** Revision 1.2 2009/11/17 10:49:49EST dmccomas 
** Updated OS_ function calls to CFE_PSP_ function calls
** Revision 1.1 2008/06/21 08:19:50EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.1 2008/06/12 08:24:38EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.5 2006/06/13 11:35:12EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.4 2006/05/01 09:21:47EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:25EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:56:55EST dcmccomas 
** 
*/

/*
** Include Files:
*/

#include "app_housekp_priv.h"

#include <string.h>

#include "cfe_psp.h"
#include "cfe_error.h"
#include "cfe_evs.h"


/*
** Macros
*/

#define EVS_ID(Offset)   ((uint16)(HouseKpObj->EvsIdBase + Offset)) 


/*
** Exported Functions
*/

/******************************************************************************
** Function: App_HouseKp_Constructor
**
*/
void App_HouseKp_Constructor(App_HouseKp_Class*   HouseKpObj,
                             App_PipeMgr_Class*   PipeMgrObj,
                             App_CmdMsg_Class*    CmdMsgObj,
                             App_FaultRep_Class*  FaultRepObj,
                             App_TlmGen_Class*    TlmGenObj,
                             CFE_SB_MsgId_t       ReqMsgId,
                             uint16               ReqMsgLen,
                             CFE_SB_MsgId_t       ReplyMsgId,
					              uint16*              EvsIdBase)
{
 
   /*
   ** Initialze object data 
   */

   HouseKpObj->ReqMsgId   = ReqMsgId;
   HouseKpObj->ReplyMsgId = ReplyMsgId;
   HouseKpObj->CmdMsg     = CmdMsgObj;
   HouseKpObj->TlmGen     = TlmGenObj;
   HouseKpObj->FaultRep   = FaultRepObj;

   /*
   ** HK Request Message
   **  - Construct an App_Msg for it
   **  - Subscribe to it on the app's cmd pipe with a max of 1 request on the pipe at a time
   ** HK Reply Message
   **  - Construct an App_TlmMsg for it
   **  - Register it with App_TlmGen
   */


   App_Msg_Constructor(&(HouseKpObj->ReqMsg),
                       APP_HOUSEKP_NAME,
                       ReqMsgId,
                       ReqMsgLen,
                       App_HouseKp_ProcessRequest,
                       HouseKpObj);

   HouseKpObj->EvsIdBase = *EvsIdBase;
   *EvsIdBase += APP_HOUSEKP_EVS_MSG_CNT;

   App_PipeMgr_SubscribeToMsg(PipeMgrObj, 
                              &(HouseKpObj->ReqMsg),1);


   App_TlmMsg_Constructor(&HouseKpObj->ReplyMsgObj,
                         (CFE_SB_MsgPtr_t )&HouseKpObj->ReplyMsg,
                          APP_HOUSEKP_NAME,
                          ReplyMsgId,
                          sizeof(App_HouseKp_ReplyMsg),
                          App_HouseKp_LoadReplyMsgData , 
                          HouseKpObj);

   App_TlmGen_RegisterReqMsg(TlmGenObj, &HouseKpObj->ReplyMsgObj);
      
} /* End App_HouseKp_Constructor() */



/******************************************************************************
** Function: App_HouseKp_LoadReplyMsgData
**
*/

void App_HouseKp_LoadReplyMsgData (void*           TlmObjPtr, /**< Pointer to an instance of a HouseKp class */
                                   CFE_SB_MsgPtr_t TlmMsgPtr  /**< Pointer to telemetry SB message           */
                                  )
{

   App_HouseKp_Class*     HouseKpObj = (App_HouseKp_Class*)TlmObjPtr;
   App_HouseKp_ReplyMsg*  ReplyMsg   = (App_HouseKp_ReplyMsg*)TlmMsgPtr;

   ReplyMsg->CmdCntValid   = HouseKpObj->CmdMsg->Parent.ValidCnt;
   ReplyMsg->CmdCntInvalid = HouseKpObj->CmdMsg->Parent.InvalidCnt;

   CFE_PSP_MemCpy(&(ReplyMsg->FaultRepEnabledFlags),
                  (void*)&(HouseKpObj->FaultRep->FaultDet.Enabled),
                  sizeof(uint16)*APP_FAULTREP_BITFIELD_WORDS);

   CFE_PSP_MemCpy(&(ReplyMsg->FaultRepLatchedFlags),
                  (void*)&(HouseKpObj->FaultRep->FaultDet.Latched),
                  sizeof(uint16)*APP_FAULTREP_BITFIELD_WORDS);

} /* End App_HouseKp_LoadReplyMsgData() */



/******************************************************************************
** Function: App_HouseKp_ProcessRequest
**
*/

boolean App_HouseKp_ProcessRequest(      void*  MsgProcObj,
                                   const void*  MsgData)
{
   
   App_HouseKp_Class*  HouseKpObj = (App_HouseKp_Class*)MsgProcObj;

   App_TlmGen_RequestMsg((App_TlmGen_Class*)HouseKpObj->TlmGen, HouseKpObj->ReplyMsgId, 1);

   return TRUE;

} /* End App_HouseKp_ProcessRequest() */

/* end of file */
