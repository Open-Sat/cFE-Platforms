/*
** 
** Purpose: Define a class that maps data producers to data consumers.
**
** $Id: app_databus_priv.h 1.1 2008/06/21 08:19:48EDT dcmccomas Exp  $
**
** Notes:
**   1. This is a private header. See app_databus.h's notes for public
**      interface details.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:48EDT $
** $Revision: 1.1 $
** $Log: app_databus_priv.h  $
** Revision 1.1 2008/06/21 08:19:48EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.1 2008/06/12 08:24:36EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.4 2006/07/27 14:31:24EDT dcmccomas 
** Removed doxygen markup.
** Revision 1.3 2006/06/13 11:35:11EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.2 2006/05/10 13:34:07EDT dcmccomas 
** 
** Revision 1.1 2006/05/01 09:27:34EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_databus_priv_
#define _app_databus_priv_

/*
** Includes
*/


#include "app_databus.h"

/*
** Exported Functions
*/


/*
** Purpose: Instantiate a App_DataBus object.
**
** Notes:
**   1. This is private because only one App_DataBus needs to exist for an 
**      application and it is automatically created by the framework.
**   2. This function must be called prior to any other App_DataBus_ functions
**
*/
void App_DataBus_Constructor(App_DataBus_Class*  DataBusObj,    /**< Pointer to a App_DataBus_Class object */
                             App_DataBus_DataSrc DataSrcBuf[],  /**< Array of data sources                 */
                             uint16              DataSrcMax,    /**< Number of entries in DataSrc[]        */
                             uint16*             EvsIdBase      /**< Starting event message ID             */
                            );



#endif /* _app_databus_priv_ */
