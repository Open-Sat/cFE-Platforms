/**
** @file
**
** File:
**
** $Id: app_objmgr.c 1.2 2009/11/17 10:49:51EST dmccomas Exp  $
**
** Purpose:  Implements App_ObjMgr_Class
**
** $Date: 2009/11/17 10:49:51EST $
** $Revision: 1.2 $
** $Log: app_objmgr.c  $
** Revision 1.2 2009/11/17 10:49:51EST dmccomas 
** Updated OS_ function calls to CFE_PSP_ function calls
** Revision 1.1 2009/01/29 11:09:37EST myang 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.7 2006/11/06 11:48:53EST myyang 
**  - Checks App_Frame->FcMethod, if == APP_FRAME_CMD_FC_AUTO, will execute App_CmdMsg_RegFuncAuto()
**    else, will execute App_CmdMsg_RegFunc()
** Revision 1.6 2006/08/09 08:48:33EDT myyang 
** - Rearrange event id assignment in app_objmgr to have app_objmgr level event ids assigned before object event ids
**      
** Revision 1.5 2006/06/27 15:38:09EDT myyang 
** - ObjMgr Constructor Uses Hard-Coded Evs Ids
** Revision 1.4 2006/06/07 15:44:04EDT myyang 
** - New order of initialization:  Register command messages, tables, telemetry messages, objects, and data sources
** - Changed how Evs Base Ids are set so that app_objmgr event messages will come immediately after app_frame event messages
** Revision 1.3 2006/05/23 15:02:02EDT myyang 
** - Removed custom parameter from function call and used initialization table's custom parameter
** Revision 1.2 2006/05/11 13:29:40EDT myyang 
** - Edited call to App_DataBus_RegisterSrc() so that it does not need data size
** - Edited call to object constructor so that it does not use Fault Detector Id
** Revision 1.1 2006/05/01 15:16:44EDT myyang 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Includes
*/

#include "app_objmgr.h"

#include "cfe.h"

/*
** Macro Definitions
*/

/*
** Exported Functions
*/


/******************************************************************************
** Function: App_ObjMgr_Constructor()
**
*/
App_ObjMgr_RetStat App_ObjMgr_Constructor(App_ObjMgr_Class*		NewObjMgr,
										  char*					name,
										  App_Frame_Class*		App_Frame,
										  App_ObjMgr_InitTbl*	InitTbl,
										  uint16				EvsBaseId)
{

	uint8 i;
	uint16	EvsCounter = 0;
	int32 RetStat;
	App_ObjMgr_RetStat	ConstructorRetStat = {APP_OBJMGR_CONSTRUCT_SUCCESS, 0};

	/* Clears All ObjMgr's Class Data */
	CFE_PSP_MemSet(NewObjMgr, 0, sizeof(App_ObjMgr_Class));

	/* Assigns name to ObjMgr */
	NewObjMgr->App_ObjMgr_Name = name;

	/* Assigns Pointer to Object Manager's Execution Function */
	NewObjMgr->App_ObjMgr_ExecFunc = InitTbl->App_ObjMgr_ExecuteFunc;

	/* Sets Object Manager's base Evs Id */
	NewObjMgr->App_ObjMgr_EvsIdBase = EvsBaseId;

	/* Starting the EvsCounter */
	EvsCounter = NewObjMgr->App_ObjMgr_EvsIdBase + InitTbl->ObjEvsIdCnt;

	/* Registers ObjMgr Commands with Command Manager */
	if (App_Frame->FcMethod == APP_FRAME_CMD_FC_AUTO)
	{
		for(i = 0; i < InitTbl->NumCmds; i++)
		{
			App_CmdMsg_RegFuncAuto(&(App_Frame->CmdMsg),
								   InitTbl->Cmds[i].CmdName,
								   InitTbl->Cmds[i].FuncPtr,
								   InitTbl->Cmds[i].ObjPtr,
								   InitTbl->Cmds[i].ParamLen);
		}
	}
	else
	{
		for(i = 0; i < InitTbl->NumCmds; i++)
		{
			App_CmdMsg_RegFunc(&(App_Frame->CmdMsg),
							   InitTbl->Cmds[i].CmdName,
							   InitTbl->Cmds[i].FuncPtr,
							   InitTbl->Cmds[i].ObjPtr,
							   InitTbl->Cmds[i].ParamLen,
							   InitTbl->Cmds[i].FuncCode);
		}
	}

	/* Links App_ObjMgr to Objects it will Manage */
	NewObjMgr->App_ObjMgr_Obj = InitTbl->ObjList;

	/* Links App_ObjMgr to Table Handles it will Manage */
	NewObjMgr->App_ObjMgr_Tbl = InitTbl->TblHandleList;

	for(i = 0; i < InitTbl->NumTbls; i++)
	{
		/* Will Register cFE Tables */
		RetStat = CFE_TBL_Register(&(NewObjMgr->App_ObjMgr_Tbl[i]),
								   InitTbl->Tbls[i].Name,
								   InitTbl->Tbls[i].Size,
								   InitTbl->Tbls[i].TblOptionFlags,
								   InitTbl->Tbls[i].TblValidationFuncPtr);

		if (RetStat >= CFE_SUCCESS)
		{
			/* Will Load Initial Table Data If Available */
			if(InitTbl->Tbls[i].InitialTblValues != NULL)
			{
				RetStat = CFE_TBL_Load(NewObjMgr->App_ObjMgr_Tbl[i], InitTbl->Tbls[i].SrcType, InitTbl->Tbls[i].InitialTblValues);

				/* If table fails to load */
				if(RetStat != CFE_SUCCESS)
				{
					CFE_EVS_SendEvent(APP_OBJMGR_EVS_TBL_LOAD_ERR, CFE_EVS_ERROR, "Table Failed to Load (Handle = %x Idx = %d), RetStat = %x", NewObjMgr->App_ObjMgr_Tbl[i], i, RetStat);
					ConstructorRetStat.Status = APP_OBJMGR_TABLE_ERROR;
				}
			}
		}
		/* If table fails to register */
		else
		{
			CFE_EVS_SendEvent (APP_OBJMGR_EVS_TBL_REGISTER_ERR,
                            CFE_EVS_ERROR,
                            "Failed to Register Table (Idx = %d), RetStat = %x", i, RetStat);

			ConstructorRetStat.Status = APP_OBJMGR_TABLE_ERROR;
		}
	}

	/* Links App_ObjMgr to Data Telemetry Messages it will Manage */
	NewObjMgr->App_ObjMgr_TlmMsg = InitTbl->DataPktList;

	/* Registers Telemetry Generating Functions with Telemetry Generators */
	for(i = 0; i < InitTbl->NumPkts; i++)
	{
		/* Constructs Telemetry Msg */
		App_TlmMsg_Constructor(&NewObjMgr->App_ObjMgr_TlmMsg[i], 
			InitTbl->DataPkt[i].MsgPtr, 
			InitTbl->DataPkt[i].MsgName, 
			InitTbl->DataPkt[i].TlmMsgId,
			InitTbl->DataPkt[i].MsgLen,
			InitTbl->DataPkt[i].TlmGenFuncPtr,
			InitTbl->DataPkt[i].ObjDataPtr);

		/* Registers Telemetry Msg with Telemetry Generator */
		App_TlmGen_RegisterMsg(&(App_Frame->TlmGen),
			&NewObjMgr->App_ObjMgr_TlmMsg[i], InitTbl->DataPkt[i].Filter);
	}

	for (i = 0; i< InitTbl->NumObjs; i++)
	{
		/* Links Object Pointers to Object Manager */
		NewObjMgr->App_ObjMgr_Obj[i] = InitTbl->Objs[i].ObjPtr;

		/* Will run the Object's Constructors if Available */
		if(InitTbl->Objs[i].ObjConstructorFunction != NULL)
		{
			(InitTbl->Objs[i].ObjConstructorFunction)(NewObjMgr->App_ObjMgr_Obj[i], EvsCounter);

			EvsCounter += InitTbl->Objs[i].ObjEvsMaxCnt;	/* Increments Evs Counters by the EvsIdCount of Object */
		}
	}

	/* Will Register Output Data to DataBus */
	for (i = 0; i < InitTbl->NumDataSend; i++)
	{
		App_DataBus_RegisterSrc(&App_Frame->DataBus,
			InitTbl->Dtsd[i].DataType, 
			InitTbl->Dtsd[i].DataName,
			InitTbl->Dtsd[i].DataLoc);
	}

	/* Executes any Custom Constructors on Object Manager */
	if (InitTbl->App_ObjMgr_CustomConstructor != NULL)
	{
		(InitTbl->App_ObjMgr_CustomConstructor)(App_Frame, NewObjMgr, InitTbl->CustomParam);
	}

	/* Sets first Evs Id available to application task by setting StartingEvsId to EvsCounter */
	ConstructorRetStat.StartingEvsId = EvsCounter;

	return (ConstructorRetStat);
	
}  /*  End ObjMgr_Constructor()  */

/*  end of file  */
