/* 
** File:
**   $Id: app_databus.c 1.1 2008/06/21 08:19:47EDT dcmccomas Exp  $
**
** Purpose: Implementation of the Data Bus unit
**
** Note
**   1. This is an Application service object which means it has functions
**      that are directly callable from any other object contained in the
**      application. However these objects don't have direct access to the
**      application's global App_DataBus object. Therefore App_DataBus is
**      implemented as a "singleton." A singleton is implemented by the 
**      Constructor storing a static pointer to the global instance. The
**      "service" functions called by other objects do NOT pass a reference
**      to the object as the first parameter.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:47EDT $
** $Revision: 1.1 $
** $Log: app_databus.c  $
** Revision 1.1 2008/06/21 08:19:47EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.1 2008/06/12 08:24:36EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.7 2007/02/21 14:44:48EST dcmccomas 
** 
** Revision 1.6 2006/06/13 11:35:12EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.5 2006/05/10 13:34:07EDT dcmccomas 
** 
** Revision 1.4 2006/05/01 09:21:44EDT dcmccomas 
** 
** Revision 1.3 2006/04/06 08:56:25EDT dcmccomas 
** 
** Revision 1.2 2006/03/28 14:56:55EST dcmccomas 
** 
** Revision 1.1 2006/03/24 14:11:25EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.4 2006/03/09 10:34:45EST jcwu 
** Added new-line at the end (DCR 354).
** Revision 1.3 2006/01/19 09:38:56EST dcmccomas 
** Completed unit test
** Revision 1.2 2006/01/11 08:00:42EST dcmccomas 
** 
** Revision 1.1 2005/11/30 09:10:57EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.3 2005/11/29 06:50:33EST dcmccomas 
** Removed groups
** Revision 1.2 2005/11/09 07:52:51EST dcmccomas 
** Added doxygen markup
**
*/

/*
** Include Files
*/

#include "app_databus.h"

#include <string.h> 

#include "cfe_evs.h"
#include "app_timesvcs.h"

/*
** Macro Definitions
*/

#define EVS_ID(Offset)  ((uint16)(DataBusObj->EvsIdBase + Offset)) 



/*
** Data Bus Function Definitions
*/

/******************************************************************************
** Function: App_DataBus_CommitData
**
*/

void  App_DataBus_CommitData (App_DataBus_Class*  DataBusObj,
                              App_DataType        DataId)
{


   App_DataBus_CommitDataWithTime (DataBusObj, DataId, DataBusObj->CycleTime);


} /* App_DataBus_CommitData() */


/******************************************************************************
** Function: App_DataBus_CommitDataWithTime
**
*/

void  App_DataBus_CommitDataWithTime (App_DataBus_Class*  DataBusObj,
                                      App_DataType        DataId,
                                      double              Time)
{

   App_DataBus_DataSrc* DataSrc;

   if (DataId < DataBusObj->DataSrcCntMax)
   {

      DataSrc = &DataBusObj->DataSrc[DataId];

      if (DataSrc->Registered == TRUE)
      {

         DataSrc->Status     = APP_DATABUS_VALID;
         DataSrc->UpdateTime = Time;

      } /* End if registered */
      else
      {

         CFE_EVS_SendEvent (EVS_ID(APP_DATABUS_EVS_UNREGISTERED_DATA_COMMIT),
                            CFE_EVS_ERROR,
                            "Attempt to commit unregistered data source ID %d ", DataId);


      } /* End if not registered */


   } /* End if DataId valid */
   else
   {

      CFE_EVS_SendEvent (EVS_ID(APP_DATABUS_EVS_INVALID_DATA_SRC_ID),
                         CFE_EVS_ERROR,
                         "Invalid data source ID %d in App_DataBus_CommitData() call", DataId);


   } /* End if DataId invalid */

} /* App_DataBus_CommitDataWithTime() */



/******************************************************************************
** Function: App_DataBus_Constructor
**
*/

void App_DataBus_Constructor(App_DataBus_Class*  DataBusObj,
                             App_DataBus_DataSrc DataSrcBuf[],
                             uint16              DataSrcMax,
                             uint16*             EvsIdBase)
{
  
   uint16 Id;
   

   DataBusObj->CycleTime = 0.0;
   DataBusObj->CfeCycleTime.Seconds = 0;
   DataBusObj->CfeCycleTime.Subseconds = 0;

   DataBusObj->EvsIdBase = *EvsIdBase;
   *EvsIdBase += APP_DATABUS_EVS_MSG_CNT;

   DataBusObj->DataSrc       = DataSrcBuf;
   DataBusObj->DataSrcCnt    = 0;
   DataBusObj->DataSrcCntMax = DataSrcMax;
   for (Id = 0; Id < DataSrcMax; Id++)
   {

      strcpy(DataBusObj->DataSrc[Id].Name,"NULL");

      DataBusObj->DataSrc[Id].Registered = FALSE;
      DataBusObj->DataSrc[Id].Status     = APP_DATABUS_INVALID;
      DataBusObj->DataSrc[Id].UpdateTime = 0.0;
      DataBusObj->DataSrc[Id].Buf        = NULL;

   } /* End Data loop */


} /* End App_DataBus_Constructor() */



/******************************************************************************
** Function: App_DataBus_GetCfeCycleTime
**
*/

CFE_TIME_SysTime_t App_DataBus_GetCfeCycleTime(App_DataBus_Class*  DataBusObj)
{

   return DataBusObj->CfeCycleTime;

} /* End App_DataBus_GetCfeCycleTime() */


/******************************************************************************
** Function: App_DataBus_GetCycleTime
**
*/

double App_DataBus_GetCycleTime(App_DataBus_Class*  DataBusObj)
{

   return DataBusObj->CycleTime;

} /* End App_DataBus_GetCycleTime() */




/******************************************************************************
** Function: App_DataBus_GetDataRef
**
*/

void** App_DataBus_GetDataRef(App_DataBus_Class*  DataBusObj,
                              App_DataType        DataId)
{

   void** BufPtr = APP_DATABUS_NULL_BUF;

   if (DataId < DataBusObj->DataSrcCntMax)
   {

      BufPtr = &DataBusObj->DataSrc[DataId].Buf;

   } /* End if DataId valid */
   else
   {

      CFE_EVS_SendEvent (EVS_ID(APP_DATABUS_EVS_INVALID_DATA_SRC_ID),
                         CFE_EVS_ERROR,
                         "Invalid data source ID %d in App_DataBus_GetDataRef() call", DataId);
   
   } /* End if DataId invalid */
      
   return BufPtr;


} /* End App_DataBus_GetDataRef() */



/******************************************************************************
** Function: App_DataBus_GetDataRecord
**
*/

boolean  App_DataBus_GetDataRecord (App_DataBus_Class*    DataBusObj,
                                    App_DataType          DataId,
                                    App_DataBus_DataSrc*  DataSrc)
{

   boolean RetStatus = TRUE;

   if (DataId < DataBusObj->DataSrcCntMax)
   {

      *DataSrc = DataBusObj->DataSrc[DataId];
         
   }  /* End if DataId valid */
   else 
   {

      CFE_EVS_SendEvent (EVS_ID(APP_DATABUS_EVS_INVALID_DATA_SRC_ID),
                         CFE_EVS_ERROR,
                         "Invalid data source ID %d in App_DataBus_GetDataRecord() call", DataId);

      RetStatus = FALSE;

   } /* End if DataId invalid */
      
   return RetStatus;

} /* End App_DataBus_GetDataRecord() */


/******************************************************************************
** Function: App_DataBus_GetDataStatus
**
*/

App_DataBus_DataStatus  App_DataBus_GetDataStatus (App_DataBus_Class*  DataBusObj,
                                                   App_DataType        DataId)
{

   App_DataBus_DataSrc  DataSrc;

   if ( App_DataBus_GetDataRecord (DataBusObj, DataId, &DataSrc) == FALSE )

      DataSrc.Status = APP_DATABUS_UNREG;

   return DataSrc.Status;

} /* End App_DataBus_GetDataStatus() */


/******************************************************************************
** Function: App_DataBus_RegisterSrc
**
*/
void App_DataBus_RegisterSrc(App_DataBus_Class*  DataBusObj,
                             App_DataType        DataId,
                             const char*         SrcName,
                             void*               DataBuf)
{

   App_DataBus_DataSrc* DataSrc;

   if (DataId < DataBusObj->DataSrcCntMax)
   {

      DataSrc = &DataBusObj->DataSrc[DataId];

      strncpy(DataSrc->Name, SrcName, APP_DATABUS_DATA_SRC_NAME_LEN_MAX);
      DataSrc->Name[APP_DATABUS_DATA_SRC_NAME_LEN_MAX-1] = '\0';

      DataSrc->Registered = TRUE;
      DataSrc->Status     = APP_DATABUS_STALE;
      DataSrc->UpdateTime = 0.0;
    
      DataSrc->Buf    = DataBuf;

   } /* End if DataId valid */

   else
   {

      CFE_EVS_SendEvent (EVS_ID(APP_DATABUS_EVS_INVALID_DATA_SRC_ID),
                         CFE_EVS_ERROR,
                         "Invalid data source ID %d in App_DataBus_RegisterSrc() call", DataId);


   } /* End if DataId invalid */


} /* App_DataBus_RegisterSrc() */



/******************************************************************************
** Function: App_DataBus_SetDataStatus
**
*/

void  App_DataBus_SetDataStatus (App_DataBus_Class*     DataBusObj,
                                 App_DataType           DataId,
                                 App_DataBus_DataStatus Status)
{

   if (DataId < DataBusObj->DataSrcCntMax)
   {

      DataBusObj->DataSrc[DataId].Status = Status;

   } /* End if DataId valid */

   else
   {

      CFE_EVS_SendEvent (EVS_ID(APP_DATABUS_EVS_INVALID_DATA_SRC_ID),
                         CFE_EVS_ERROR,
                         "Invalid data source ID %d in App_DataBus_SetDataStatus() call", DataId);


   } /* End if DataId invalid */


} /* End App_DataBus_SetDataStatus() */


/******************************************************************************
** Function: App_DataBus_StartCycle
**
** Notes:
**  1. Use CFE_TIME_GetTime() as to opposed to functions like CFE_TIME_GetUTC()
**     because each mission will configure the CFE so CFE_TIME_GetTime() 
**     will return the desired time format for the mission.
**
*/

void App_DataBus_StartCycle(App_DataBus_Class*  DataBusObj)
{

   DataBusObj->CfeCycleTime = CFE_TIME_GetTime();

   App_DataBus_StartCycleWithTime(DataBusObj, App_TimeSvcs_SysTime(DataBusObj->CfeCycleTime));


} /* End App_DataBus_StartCycle() */



/******************************************************************************
** Function: App_DataBus_StartCycleWithTime
**
*/

void App_DataBus_StartCycleWithTime(App_DataBus_Class*  DataBusObj,
                                    double              Time)
{

   uint16  i;

   DataBusObj->CycleTime = Time;

   for (i=0; i < DataBusObj->DataSrcCntMax; i++)
   {
      if (DataBusObj->DataSrc[i].Registered == TRUE)
         DataBusObj->DataSrc[i].Status = APP_DATABUS_STALE;
   }


} /* End App_DataBus_StartCycleWithTime() */

/* end of file */
