/*
** 
** Purpose: Define private member functions for the app_housekp class.
**
** $Id: app_housekp_priv.h 1.1 2008/06/21 08:19:51EDT dcmccomas Exp  $
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. The GN&C FSW Framework Programmer's Guide
**
** $Date: 2008/06/21 08:19:51EDT $
** $Revision: 1.1 $
** $Log: app_housekp_priv.h  $
** Revision 1.1 2008/06/21 08:19:51EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/framework/fsw/gnc/project.pj
** Revision 1.1 2008/06/12 08:24:39EDT dcmccomas 
** Initial revision
** Member added to project c:/MKSDATA/MKS-REPOSITORY/GNC-FSW-REPOSITORY/lib/project.pj
** Revision 1.2 2006/07/27 14:31:22EDT dcmccomas 
** Removed doxygen markup.
** Revision 1.1 2006/06/13 11:35:33EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

#ifndef _app_housekp_priv_
#define _app_housekp_priv_

/*
** Includes
*/

#include "app_housekp.h"


/*
** Exported Functions
*/


/*
** Purpose:  Initialize an application's house keepng object
**
** Notes:
**   1. This function must be called prior to any other HouseKp_ functions
**   2. The application's command pipe is used to receive the housekeeping
**      packet. 
**
*/
void App_HouseKp_Constructor(App_HouseKp_Class*   HouseKpObj,  /**< Pointer to an app's housekeeping class     */
                             App_PipeMgr_Class*   PipeMgrObj,  /**< Pointer to an app's command pipe manager   */
                             App_CmdMsg_Class*    CmdMsgObj,   /**< Pointer to an app's command message object */
                             App_FaultRep_Class*  FaultRepObj, /**< Pointer to an app's fault reporter object  */
                             App_TlmGen_Class*    TlmGenObj,   /**< Pointer to an app's tlm generator object   */
                             CFE_SB_MsgId_t       ReqMsgId,    /**< Housekeeping request msg identifier        */
                             uint16               ReqMsgLen,   /**< Housekeeping request msg total byte length */
                             CFE_SB_MsgId_t       ReplyMsgId,  /**< Housekeeping reply msg identifier          */
                             uint16*              EvsIdBase    /**< The starting event message ID              */
                            );


/*
** Purpose:  Load current data into the housekeeping telemetry packet.
**
** Notes:
**   1. The function signature must comply with the GN&C framework's
**      telemetry interface standard.
**
*/

void App_HouseKp_LoadReplyMsgData (void*           TlmObjPtr, /**< Pointer to an instance of a HouseKp class */
                                   CFE_SB_MsgPtr_t TlmMsgPtr  /**< Pointer to telemetry SB message           */
                                  );



/*
** Purpose:  Process a housekeeping request by notifying TlmGen to
**           send the housekeeping packet this execution cycle.
**
** Notes:
**   1. The function signature must comply with the GN&C framework's
**      command interface standard.
**
** Return:
**   - TRUE  - No operation sucessfully executed
**   - FALSE - This cannot occur
**
*/

boolean App_HouseKp_ProcessRequest(      void*  CmdObj,   /**< Pointer to an instance of a HouseKp class */
                                   const void*  CmdParam  /**< Unused                                    */
                                  );


#endif /* _app_housekp_ */
