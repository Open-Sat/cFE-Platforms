/* 
** File:
**   $Id: $
**
** Purpose: Implement the test application.
**
** Notes:
**   1.
**
** References:
**   1. CFS C Coding Standards
**   2. OpenSat Object-based Application Developers Guide.
**
** $Date: $
** $Revision: $
** $Log: $
**
*/

/*
** Includes
*/

#include <string.h>
#include "test.h"


/*
** Local Function Prototypes
*/

static int32 InitApp(void);
static void ProcessCommands(void);

/*
** Global Data
*/

TEST_Class  Test;
TEST_HkPkt  TestHkPkt;

/******************************************************************************
** Function: TEST_Main
**
*/
void TEST_Main(void)
{

   int32  Status    = CFE_SEVERITY_ERROR;
   uint32 RunStatus = CFE_ES_APP_ERROR;


   Status = CFE_ES_RegisterApp();
   CFE_EVS_Register(NULL,0,0);

   /*
   ** Perform application specific initialization
   */
   if (Status == CFE_SUCCESS)
   {
       Status = InitApp();
   }

   /*
   ** At this point many flight apps use CFE_ES_WaitForStartupSync() to
   ** synchronize their startup timing with other apps. This is not
   ** needed.
   */

   if (Status == CFE_SUCCESS) RunStatus = CFE_ES_APP_RUN;

   /*
   ** Main process loop
   */
   while (CFE_ES_RunLoop(&RunStatus))
   {

      /*
      ** This is just a an example loop. There are many ways to control the
      ** main loop execution.
      */

      OS_TaskDelay(TEST_RUNLOOP_DELAY);

      EXOBJ_LoadDataFromTable();

      ProcessCommands();

   } /* End CFE_ES_RunLoop */


   /* Write to system log in case events not working */

   CFE_ES_WriteToSysLog("TEST Terminating, RunLoop status = 0x%08X\n", RunStatus);

   CFE_EVS_SendEvent(TEST_EXIT_ERR_EID, CFE_EVS_CRITICAL, "TEST Terminating,  RunLoop status = 0x%08X", RunStatus);

   CFE_ES_ExitApp(RunStatus);  /* Let cFE kill the task (and any child tasks) */

} /* End of TEST_Main() */


/******************************************************************************
** Function: TEST_NoOpCmd
**
*/

boolean TEST_NoOpCmd(const CFE_SB_MsgPtr_t MsgPtr)
{

   CFE_EVS_SendEvent (TEST_CMD_NOOP_INFO_EID,
                      CFE_EVS_INFORMATION,
                      "No operation command received for TEST version %d.%d",
                      TEST_MAJOR_VERSION,TEST_MINOR_VERSION);

   return TRUE;


} /* End TEST_NoOpCmd() */


/******************************************************************************
** Function: TEST_ResetAppCmd
**
*/

boolean TEST_ResetAppCmd(const CFE_SB_MsgPtr_t MsgPtr)
{

   CMDMGR_ResetStatus();
   TBLMGR_ResetStatus();
   EXOBJ_ResetStatus();

   return TRUE;

} /* End TEST_ResetAppCmd() */


/******************************************************************************
** Function: TEST_SendHousekeepingPkt
**
*/
void TEST_SendHousekeepingPkt(void)
{

   /*
   ** CMDMGR Data
   */

   TestHkPkt.ValidCmdCnt   = Test.CmdMgr.ValidCmdCnt;
   TestHkPkt.InvalidCmdCnt = Test.CmdMgr.InvalidCmdCnt;

   /*
   ** TBLMGR Data
   */

   TestHkPkt.ExObjTblLoadActive     = Test.TblMgr.ExObjTbl.LoadActive;
   TestHkPkt.ExObjTblLastLoadValid  = Test.TblMgr.ExObjTbl.LastLoadValid;
   TestHkPkt.ExObjTblAttrErrCnt     = Test.TblMgr.ExObjTbl.AttrErrCnt;

   /*
   ** OBJECT Data
   ** - At a minimum all OBJECT variables effected by a reset must be included
   */

   TestHkPkt.EnableDataLoad = Test.ExObj.EnableDataLoad;
   TestHkPkt.Spare          = 0;
   TestHkPkt.TblIndex       = Test.ExObj.TblIndex;
   TestHkPkt.Data1          = Test.ExObj.Data1;
   TestHkPkt.Data2          = Test.ExObj.Data2;
   TestHkPkt.Data3          = Test.ExObj.Data3;

   CFE_SB_TimeStampMsg((CFE_SB_Msg_t *) &TestHkPkt);
   CFE_SB_SendMsg((CFE_SB_Msg_t *) &TestHkPkt);

} /* End TEST_SendHousekeepingPkt() */


/******************************************************************************
** Function: InitApp
**
*/
static int32 InitApp(void)
{
    int32 Status = CFE_SUCCESS;

    /*
    ** Initialize 'entity' objects
    */

    EXOBJ_Constructor(&Test.ExObj);

    /*
    ** Initialize application managers
    */

    TBLMGR_Constructor(&Test.TblMgr, TEST_EXOBJ_TBL_DEF_LOAD_FILE);

    CFE_SB_CreatePipe(&Test.CmdPipe, CMDMGR_PIPE_DEPTH, CMDMGR_PIPE_NAME);
    CFE_SB_Subscribe(TEST_CMD_MID, Test.CmdPipe);
    CFE_SB_Subscribe(TEST_SEND_HK_MID, Test.CmdPipe);

    CMDMGR_Constructor(&Test.CmdMgr);
    CMDMGR_RegisterFunc(TEST_CMD_RESET_FC,           TEST_ResetAppCmd,        0);
    CMDMGR_RegisterFunc(TEST_CMD_NOOP_FC,            TEST_NoOpCmd,            0);
    CMDMGR_RegisterFunc(TEST_CMD_EXOBJ_TBL_LOAD_FC,  TBLMGR_LoadExObjTableCmd,   TBLMGR_LOAD_TBL_CMD_DATA_LEN);
    CMDMGR_RegisterFunc(TEST_CMD_EXOBJ_TBL_DUMP_FC,  TBLMGR_DumpExObjTableCmd,   TBLMGR_DUMP_TBL_CMD_DATA_LEN);
    CMDMGR_RegisterFunc(TEST_CMD_ENA_DATA_LOAD_FC,   EXOBJ_EnableDataLoadCmd,    EXOBJ_ENABLE_DATA_LOAD_CMD_DATA_LEN);
    CMDMGR_RegisterFunc(TEST_CMD_SET_TBL_INDEX_FC,   EXOBJ_SetTblIndexCmd,       EXOBJ_SET_TBL_INDEX_CMD_DATA_LEN);

    CFE_SB_InitMsg(&TestHkPkt, TEST_TLM_HK_MID, TEST_TLM_HK_LEN, TRUE);

    /*
    ** Application startup event message
    */
    Status = CFE_EVS_SendEvent(TEST_INIT_INFO_EID,
                               CFE_EVS_INFORMATION,
                               "TEST Initialized. Version %d.%d.%d.%d",
                               TEST_MAJOR_VERSION,
                               TEST_MINOR_VERSION,
                               TEST_REVISION,
                               TEST_MISSION_REV);

    return(Status);

} /* End of InitApp() */


/******************************************************************************
** Function: ProcessCommands
**
*/
static void ProcessCommands(void)
{

   int32           Status;
   CFE_SB_Msg_t*   CmdMsgPtr;
   CFE_SB_MsgId_t  MsgId;

   Status = CFE_SB_RcvMsg(&CmdMsgPtr, Test.CmdPipe, CFE_SB_POLL);

   if (Status == CFE_SUCCESS)
   {

      MsgId = CFE_SB_GetMsgId(CmdMsgPtr);

      switch (MsgId)
      {
         case TEST_CMD_MID:
            CMDMGR_DispatchFunc(CmdMsgPtr);
            break;

         case TEST_SEND_HK_MID:
            TEST_SendHousekeepingPkt();
            break;

         default:
            CFE_EVS_SendEvent(TEST_CMD_INVALID_MID_ERR_EID, CFE_EVS_ERROR,
                              "Received invalid command packet,MID = 0x%4X",MsgId);

            break;

      } /* End Msgid switch */

   } /* End if SB received a packet */

} /* End ProcessCommands() */


/* end of file */
