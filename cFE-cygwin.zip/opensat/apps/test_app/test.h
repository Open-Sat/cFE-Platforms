/*
** $Id: $
** 
** Purpose: Define the Test application.
**
** Notes:
**   1.
**
** References:
**   1. CFS C Coding Standards
**   2. OpenSat Object-based Application Developers Guide.
**
** $Date: $
** $Revision: $
** $Log: $
**
*/
#ifndef _test_
#define _test_

/*
** Includes
*/

#include "app_config.h"
#include "cmdmgr.h"
#include "tblmgr.h"
#include "exobj.h"

/*
** Macro Definitions
*/

#define TEST_INIT_INFO_EID            (TEST_BASE_EID + 0)
#define TEST_EXIT_ERR_EID             (TEST_BASE_EID + 1)
#define TEST_CMD_NOOP_INFO_EID        (TEST_BASE_EID + 2)
#define TEST_CMD_INVALID_MID_ERR_EID  (TEST_BASE_EID + 3)

/*
** Type Definitions
*/

typedef struct
{

   CMDMGR_Class CmdMgr;
   TBLMGR_Class TblMgr;
   EXOBJ_Class  ExObj;

   CFE_SB_PipeId_t CmdPipe;

} TEST_Class;

typedef struct
{

   uint8    Header[CFE_SB_TLM_HDR_SIZE];

   /*
   ** CMDMGR Data
   */
   uint16   ValidCmdCnt;
   uint16   InvalidCmdCnt;

   /*
   ** TBLMGR Data
   */

   boolean  ExObjTblLoadActive;
   boolean  ExObjTblLastLoadValid;
   uint16   ExObjTblAttrErrCnt;

   /*
   ** EXOBJ Data
   */

   boolean    EnableDataLoad;
   uint8      Spare;
   uint16     TblIndex;
   uint16     Data1;
   uint16     Data2;
   uint16     Data3;

} OS_PACK TEST_HkPkt;

#define TEST_TLM_HK_LEN sizeof (TEST_HkPkt)

/*
** Exported Data
*/

extern TEST_Class  Test;

/*
** Exported Functions
*/

/******************************************************************************
** Function: TEST_Main
**
*/
void TEST_Main(void);

#endif /* _test_ */
