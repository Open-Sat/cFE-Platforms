/* 
** File:
**   $Id: $
**
** Purpose: Provide default values for ExObj_A's table
**
** Notes
**   1. This is non-flight code.
**
** References:
**   1. GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:43EDT $
** $Revision: 1.1 $
** $Log: example_app/objA_tbldef.c  $
** Revision 1.1 2006/05/10 13:36:43EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2005/11/07 14:15:13EST dcmccomas 
** Added doygen markup
**
*/

/*
** Includes
*/


#include "exobj_a.h"
#include "fwapp_tabledef.h"


/*
** Exported Data
*/


ExObj_A_Table  ExObj_A_TblDef =
{

   {
      EXOBJ_A_TBL_BIAS_0,
      EXOBJ_A_TBL_BIAS_1,
      EXOBJ_A_TBL_BIAS_2
   },
   {
      EXOBJ_A_TBL_SF_0,
      EXOBJ_A_TBL_SF_1,
      EXOBJ_A_TBL_SF_2
   }  

}; /* End ExObj_A_TblDef */

/* end of file */
