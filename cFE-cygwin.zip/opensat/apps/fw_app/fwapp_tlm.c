/* 
** File:
**   $Id: $
**
** Purpose: Build telemetry message for the example GN&C Framework Application
**    
** $Id: example_app/fwapp_tlm.c 1.6 2006/05/10 13:35:50EDT dcmccomas Exp  $
**
** $Date: 2006/05/10 13:35:50EDT $
** $Revision: 1.6 $
** $Log: example_app/exapp_tlm.c  $
** Revision 1.6 2006/05/10 13:35:50EDT dcmccomas 
** 
**
*/

/*
** Includes
*/

#include "fwapp.h"
#include "fwapp_tlm.h"
#include "fwapp_spec.h"

#include "exobj_a.h"
#include "exobj_b.h"
#include "exobj_c_mgr.h"

/*
** Function Definitions
*/

/******************************************************************************
** Function: FwAppTlm_Constructor
**
*/
void FwApp_Tlm_Constructor (FwApp_Tlm_Class*   FwAppTlmObj,
                           App_TlmGen_Class*   AppTlmGenObj,
                           App_DataBus_Class*  AppDataBusObj)
{


   App_TlmMsg_Constructor(&FwAppTlmObj->HkMsgObj,
                         (CFE_SB_Msg_t*)&FwAppTlmObj->HkTlmMsg,
                          "FWAPP HK",
                          FWAPP_TLM_HK_MSG_ID,
                          FWAPP_TLM_HK_LEN,
                          FwApp_Tlm_Housekeeping, 
                          AppDataBusObj);

   App_TlmGen_RegisterMsg(AppTlmGenObj,
                          &FwAppTlmObj->HkMsgObj, 2); /* Send every other cycle */

   App_TlmMsg_Constructor(&FwAppTlmObj->VecMsgObj,
                         (CFE_SB_Msg_t*)&FwAppTlmObj->VecTlmMsg,
                          "FWAPP VEC",
                          FWAPP_TLM_VEC_MSG_ID,
                          FWAPP_TLM_VEC_LEN,
                          FwApp_Tlm_Vector, 
                          AppDataBusObj);

   App_TlmGen_RegisterMsg(AppTlmGenObj,
                          &FwAppTlmObj->VecMsgObj, 1); /* Send every cycle */


} /* End FwApp_Tlm_Constructor() */

/******************************************************************************
** Function: FwAppTlm_Housekeeping
**
*/
void FwApp_Tlm_Housekeeping (void* TlmObjPtr, CFE_SB_MsgPtr_t TlmMsgPtr)
{
   ExObj_B_Class**     ExObjB;
   ExObj_C_Mgr_Class** ExObjCMgr;

   App_DataBus_Class*     DataBusObj = (App_DataBus_Class*)TlmObjPtr;
   FwApp_Tlm_HkMsgStruct* Msg = (FwApp_Tlm_HkMsgStruct*)TlmMsgPtr;

   ExObjB = (ExObj_B_Class**)App_DataBus_GetDataRef(DataBusObj, FWAPP_DB_EXOBJ_B);
   ExObjCMgr = (ExObj_C_Mgr_Class**)App_DataBus_GetDataRef(DataBusObj, FWAPP_DB_EXOBJ_C_MGR);

   Msg->Data.CmdCounter       = FwApp.AppFrame.CmdMsg.Parent.ValidCnt;
   Msg->Data.CmdErrCounter    = FwApp.AppFrame.CmdMsg.Parent.InvalidCnt;

   Msg->Data.FaultDetEnabled  = FwApp.AppFrame.FaultRep.FaultDet.Enabled[0];
   Msg->Data.FaultDetLatched  = FwApp.AppFrame.FaultRep.FaultDet.Latched[0];

   Msg->Data.ObjBConfig = FwApp.ObjMgr.ExObjB.Enabled;
   Msg->Data.ObjCConfig = (*ExObjCMgr)->ExObjCEnabled;

} /* End FwApp_Tlm_Housekeeping() */


/******************************************************************************
** Function: FwAppTlm_Vector
**
*/
void FwApp_Tlm_Vector (void* TlmObjPtr, CFE_SB_MsgPtr_t TlmMsgPtr)
{
   uint16              i;
   ExObj_A_Class**     ExObjA;
   ExObj_B_Class**     ExObjB;
   ExObj_C_Mgr_Class** ExObjCMgr;

   App_DataBus_Class*      DataBusObj = (App_DataBus_Class*)TlmObjPtr;
   FwApp_Tlm_VecMsgStruct* Msg = (FwApp_Tlm_VecMsgStruct*)TlmMsgPtr;

   ExObjA = (ExObj_A_Class**)App_DataBus_GetDataRef(DataBusObj, FWAPP_DB_EXOBJ_A);
   ExObjB = (ExObj_B_Class**)App_DataBus_GetDataRef(DataBusObj, FWAPP_DB_EXOBJ_B);
   ExObjCMgr = (ExObj_C_Mgr_Class**)App_DataBus_GetDataRef(DataBusObj, FWAPP_DB_EXOBJ_C_MGR);

   for (i=0; i < 3; i++)
   {

      Msg->Data.ExObjAVec[i] = CONVERT_DBLTOFLT((*ExObjA)->Vector.Comp[i]);
      Msg->Data.ExObjBVec[i] = CONVERT_DBLTOFLT((*ExObjB)->Vector.Comp[i]);
      Msg->Data.ExObjCVec[i] = CONVERT_DBLTOFLT((*ExObjCMgr)->ExObjC->ErrVector.Comp[i]);
   }


} /* End FwApp_Tlm_Vector() */

/* end of file */
