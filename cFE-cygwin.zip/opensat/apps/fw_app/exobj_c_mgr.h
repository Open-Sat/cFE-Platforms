/** \file
** 
** \brief Unit specification for a ExObj_C manager
**
** $Id: example_app/objC_mgr.h 1.1 2006/05/10 13:36:45EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**   -# Framework usage notes:
**      - ExObj_C represents an object that could exist in the
**        library and the mission required a new object (this object) to
**        control how the library object is used. This object is not
**        that complicated and could be implemented within exapp_objmgr.
**        The object hierarchy managed by app_objmgr is a mission 
**        design decision.
**      - Shows how a reusable object's table is combined with mission
**        specific code's table.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:45EDT $
** $Revision: 1.1 $
** $Log: example_app/objC_mgr.h  $
** Revision 1.1 2006/05/10 13:36:45EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_exapp
** @{
*/

#ifndef _exobj_c_mgr_
#define _exobj_c_mgr_


/*
** Includes
*/

#include "cfe_tbl.h"

#include "exobj_c.h"


/*
** Macro Definitions
*/

#define EXOBJ_C_MGR_EVS_OBJC_ENABLED    0
#define EXOBJ_C_MGR_EVS_OBJC_DISABLED   1
#define EXOBJ_C_MGR_EVS_ID_CNT          2

#define EXOBJ_C_MGR_FD_DATA_SRC_A_ERR   0
#define EXOBJ_C_MGR_FD_DATA_SRC_B_ERR   1
#define EXOBJ_C_MGR_FD_ID_CNT           2

/*
** Type Definitions
*/



typedef struct
{
   
   ExObj_C_Class*  ExObjC;
   boolean         ExObjCEnabled;

   uint16          EvsIdBase;
   uint16          FaultDetIdBase;

   App_FaultRep_Class*  FaultRepObj;

} ExObj_C_Mgr_Class;



/*
** Illustrate how a reusable non-entity object's table data
** can be aggregated with higher level data into a single table.
*/

typedef struct
{

   ExObj_C_Table  ExObjC;
   float          FdLimit[2];  

} ExObj_C_Mgr_Table;


/*
** Command parameter definitions
*/


typedef struct
{

   boolean  Enable;     /* TRUE - Enable ExObj_C; FALSE - Disable ExObj_C */

} ExObj_C_Mgr_ConfigCmdParam;



/*
** Exported Functions
*/

/**
** \brief  Initialize ExObj_C_Mgr's data
**
** \param[in,out]	ExObjCMgr      Pointer to a ExApp_ObjMgr instance
** \param[in,out] ExObjCTbl      Pointer to a object C manager's table
** \param[in,out] FaultRepObj    Pointer to the application's fault reporter
** \param[in,out] EvsIdBase,     Pointer to cFE EVS ID; updated with next available ID
** \param[in,out] FaultDetIdBase Pointer to pp's fault detestor ID; updated with next available ID
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void ExObj_C_Mgr_Constructor (ExObj_C_Mgr_Class*   ExObjCMgr,
                              ExObj_C_Mgr_Table*   ExObjCTbl,
                              App_FaultRep_Class*  FaultRepObj,
                              uint16*              EvsIdBase,
                              uint16*              FaultDetIdBase
                             );


/**
** \brief  Execute the ExObj_C_Mgr
**
** \param[in,out]	ExObjCMgr      Pointer to a ExApp_ObjMgr instance
** \param[in,out] ExObjCTbl      Pointer to a object C manager's table
** \param[in,out] VecA           Pointer to vector A
** \param[in,out] VecB           Pointer to vector B
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void ExObj_C_Mgr_Execute(ExObj_C_Mgr_Class*  ExObjCMgr,
                         ExObj_C_Mgr_Table*  ExObjCTbl,
                         const Vector3d*     VecA,
                         const Vector3d*     VecB
                        );


/**
** \brief  Enable/Disable ExObj_C
**
** \note
**   -# The function signature must comply with the GN&C framework's
**      command interface standard (See app_cmdmsg.h).
**
** \param[in,out]	CmdObj    Pointer to a ExObj_C_Mgr_Class instance
** \param[in]     CmdParam  Pointer to a ExObj_C_Mgr_ConfigCmdParam
**
** \returns
** \retcode TRUE  \retdesc Valid command parameters and ExObj_C enabled/disabled as commanded \endcode
** \retcode FALSE \retdesc Invalid command parameters and ground notify of error \endcode
** \endreturns
*/
boolean ExObj_C_Mgr_ConfigCmd (      void*  CmdObj,
                               const void*  CmdParam);



#endif /* _exobj_c_mgr_ */
/** @} */
