/** \file
** 
** \brief Unit specification for an example application object manager
**
** $Id: example_app/fwapp_objmgr.h 1.2 2006/06/13 11:41:54EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**   -# Framework design notes:
**      - The configure ObjB command was added to illustrate an object
**        manager level command function. An additional object management
**        layer can be designed if the complexity demands it. ObjC_Mgr 
**        illustrates this concept.
**      - Object A and B's table pointers are managed differently.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/06/13 11:41:54EDT $
** $Revision: 1.2 $
** $Log: example_app/exapp_objmgr.h  $
** Revision 1.2 2006/06/13 11:41:54EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.1 2006/05/10 13:36:41EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup framework_fwapp
** @{
*/

#ifndef _fwapp_objmgr_
#define _fwapp_objmgr_


/*
** Includes
*/

#include "cfe_tbl.h"

#include "app_frame.h"

#include "exobj_a.h"
#include "exobj_b.h"
#include "exobj_c_mgr.h"

/*
** Macro Definitions
*/

#define FWAPP_OBJMGR_EVS_EXOBJ_B_ENABLED    0
#define FWAPP_OBJMGR_EVS_EXOBJ_B_DISABLED   1
#define FWAPP_OBJMGR_EVS_ID_CNT             2


/*
** Type Definitions
*/

typedef struct
{
   
   ExObj_A_Class*    Ptr;
   
   boolean           TblInit;
   ExObj_A_Table*    TblPtr;
   CFE_TBL_Handle_t  TblHandle;

} FwApp_ObjMgr_ExObjA;

typedef struct
{
   
   ExObj_B_Class*    Ptr;
   
   boolean           TblInit;
   CFE_TBL_Handle_t  TblHandle;

   boolean           Enabled;

} FwApp_ObjMgr_ExObjB;



typedef struct
{
   
   ExObj_C_Mgr_Class* Ptr;

   boolean            TblInit;
   CFE_TBL_Handle_t   TblHandle;

} FwApp_ObjMgr_ExObjCMgr;


typedef struct
{
   
   App_Frame_Class*        AppFrameObj; /* TBD - Add to App_ObjMgr */
 
   FwApp_ObjMgr_ExObjA     ExObjA;
   FwApp_ObjMgr_ExObjB     ExObjB;
   FwApp_ObjMgr_ExObjCMgr  ExObjCMgr;
   
   uint16 EvsIdBase;
 
} FwApp_ObjMgr_Class;


/*
** Command parameter definitions
*/

typedef struct
{

   boolean  Enable;     /* TRUE - Enable ObjB; FALSE - Disable ObjB */

} FwApp_ObjMgr_ConfigExObjBCmdParam;



/*
** Exported Functions
*/

/**
** \brief  Initialize FwApp's custom object manager data
**
** \param[in,out]	FwAppObjMgr  Pointer to FwApp_ObjMgr_Class Object
** \param[in,out] AppFrame     Pointer to application framework object
** \param[in,out] EvsIdBase    Pointer to cFE EVS ID base. Updated with next available ID.
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void FwApp_ObjMgr_Constructor (FwApp_ObjMgr_Class*  FwAppObjMgr,
                               App_Frame_Class*     AppFrame,
                               uint16*              EvsIdBase
                              );


/**
** \brief Execute the FwApp's objects
**
** \param[in,out]	FwAppObjMgr  Pointer to FwApp_ObjMgr_Class Object
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void FwApp_ObjMgr_Execute (FwApp_ObjMgr_Class* FwAppObjMgr);  


/**
** \brief  Enable/disable ObjB
**
** \note
**   -# The function signature must comply with the GN&C framework's
**      command interface standard (See app_cmdmsg.h).
**
** \param[in,out]	CmdObj   Pointer to a FwApp_ObjMgr instance
** \param[in]     CmdPram  Pointer to a FwApp_ObjMgr_ConfigObjBCmdParam
**
** \returns
** \retcode void \endcode
** \endreturns
*/

boolean FwApp_ObjMgr_ConfigExObjBCmd (      void*  CmdObj,
                                      const void*  CmdParam);




#endif /* _fwapp_objmgr_ */
/** @} */
