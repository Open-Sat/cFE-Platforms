/*
** 
** Purpose: Define default values for ObjC_Mgr's table
**
** $Id: example_app/objC_mgr_tbldef.c 1.1 2006/05/10 13:36:45EDT dcmccomas Exp  $
**
** Notes
**   1. This is non-flight code.
**
** References:
**   1. GN&C FSW Developer's Guide
**
**    
** $Date: 2006/05/10 13:36:45EDT $
** $Revision: 1.1 $
** $Log: example_app/objC_mgr_tbldef.c  $
** Revision 1.1 2006/05/10 13:36:45EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2005/11/07 14:15:15EST dcmccomas 
** Added doygen markup
**
*/

/*
** Includes
*/


#include "exobj_c_mgr.h"
#include "fwapp_tabledef.h"


/*
** Exported Data
*/


ExObj_C_Mgr_Table  ExObj_C_Mgr_TblDef =
{

   /* 
   ** ObjC's table
   */
   {
      /* Coeff[] */
      {
         EXOBJ_C_TBL_FAULT_LMT_0,
         EXOBJ_C_TBL_FAULT_LMT_1,
         EXOBJ_C_TBL_FAULT_LMT_2
      }
   },

   /*
   ** ObjC Manager additions
   */

   {
      EXOBJ_C_MGR_TBL_FD_VECA_MAG_LIM,
      EXOBJ_C_MGR_TBL_FD_VECB_MAG_LIM

   }
}; /* End ExObj_C_TblDef */


/* end of file */
