/* 
** File:
**   $Id: $
**
** Purpose: Implement the ExObj_B class
**
** Notes
**   1. This is non-flight code.
**
** $Date: 2006/05/10 13:36:43EDT $
** $Revision: 1.1 $
** $Log: example_app/objB.c  $
** Revision 1.1 2006/05/10 13:36:43EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2005/11/07 14:15:13EST dcmccomas 
** Added doygen markup
**
*/

/*
** Includes
*/

#include "exobj_b.h"


/*
** Exported Functions
*/

/******************************************************************************
** Function: ExObj_B_Constructor
**
*/
void ExObj_B_Constructor(ExObj_B_Class*  ExObjB,
                         ExObj_B_Table*  ExObjBTbl,              
                         uint16          ObjId)

{

   int i;

   ExObjB->Id = ObjId;

   for (i=0; i < 3; i++)
   {
   
      ExObjB->Vector.Comp[i]  = 0.0;
   
   } /* End axis loop */


} /* ExObj_B_Constructor() */




/******************************************************************************
** Function: ExObj_B_ComputeVector
**
*/

void ExObj_B_ComputeVector(ExObj_B_Class*  ExObjB,
                           ExObj_B_Table*  ExObjBTbl,
                           double          SomeValue)
{

   int i;

   for (i=0; i < 3; i++)
   {

      ExObjB->Vector.Comp[i] = SomeValue * ExObjBTbl->Coeff[i];

   }


} /* ExObj_B_ComputeVector() */


/* end of file */
