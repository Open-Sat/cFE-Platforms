/* 
** File:
**   $Id: $
**
** Purpose: Provide default values for ExObj_B's table
**
** Notes
**   1. This is non-flight code.
**
** References:
**   1. GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:44EDT $
** $Revision: 1.1 $
** $Log: example_app/objB_tbldef.c  $
** Revision 1.1 2006/05/10 13:36:44EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2005/11/07 14:15:13EST dcmccomas 
** Added doygen markup
**
*/

/*
** Includes
*/


#include "exobj_b.h"
#include "fwapp_tabledef.h"


/*
** Exported Data
*/


ExObj_B_Table  ExObj_B_TblDef =
{
   
   {
      EXOBJ_B_TBL_COEFF_0,
      EXOBJ_B_TBL_COEFF_1,
      EXOBJ_B_TBL_COEFF_2
   }

}; /* End ExObj_B_TblDef */


/* end of file */
