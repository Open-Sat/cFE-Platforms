/** \file
** 
** \brief Unit specification for the example application telemetry
**
**    $Id: example_app/fwapp_tlm.h 1.6 2006/07/27 14:30:27EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/07/27 14:30:27EDT $
** $Revision: 1.6 $
** $Log: example_app/exapp_tlm.h  $
** Revision 1.6 2006/07/27 14:30:27EDT dcmccomas 
** Added missing doxygen markup.
** Revision 1.5 2006/05/10 13:35:50EDT dcmccomas 
** 
**
*/

/** 
** @addtogroup framework_fwapp
** @{
*/

#ifndef _fwapp_tlm_ 
#define _fwapp_tlm_

/*
** Includes
*/

#include "cfe_sb.h"
#include "app_tlmmsg.h"
#include "app_databus.h"
#include "app_tlmgen.h"
#include "app_faultrep.h"

/*
** Type Definitions
*/

typedef struct 
{

   uint16   CmdCounter;
   uint16   CmdErrCounter;

   uint16   FaultDetEnabled;  /* Only do first word for simplicity */
   uint16   FaultDetLatched;  /* Only do first word for simplicity */

   boolean  ObjBConfig;
   boolean  ObjCConfig;

} FwApp_Tlm_HkMsgData;


typedef struct 
{

   float    ExObjAVec[3];
   float    ExObjBVec[3];
   float    ExObjCVec[3];


} FwApp_Tlm_VecMsgData;


typedef struct 
{

   uint8                Hdr[CFE_SB_TLM_HDR_SIZE];
   FwApp_Tlm_HkMsgData  Data;

} FwApp_Tlm_HkMsgStruct;

#define FWAPP_TLM_HK_LEN (sizeof(FwApp_Tlm_HkMsgStruct))

typedef struct 
{

   uint8                Hdr[CFE_SB_TLM_HDR_SIZE];
   FwApp_Tlm_VecMsgData  Data;

} FwApp_Tlm_VecMsgStruct;

#define FWAPP_TLM_VEC_LEN (sizeof(FwApp_Tlm_VecMsgStruct))


typedef struct 
{

   FwApp_Tlm_HkMsgStruct  HkTlmMsg;
   App_TlmMsg_Class       HkMsgObj;

   FwApp_Tlm_VecMsgStruct VecTlmMsg;
   App_TlmMsg_Class       VecMsgObj;

} FwApp_Tlm_Class;



/*
** Exported Functions
*/

/**
** \brief  Initialize an FwApp_Tlm_Class
**
** \param[in,out]  FwAppTlmObj   Pointer to a FwApp_TlmClass instance
** \param[in,out]  AppTlmGenObj  Pointer to framework's telemetry generator
** \param[in,out]  AppDataBusObj Pointer to framework's data bus
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void FwApp_Tlm_Constructor (FwApp_Tlm_Class*    FwAppTlmObj,
                            App_TlmGen_Class*   AppTlmGenObj,
                            App_DataBus_Class*  AppDataBusObj);




/**
** \brief  Pack data into example app's housekeeping telemetry packet
**
** \notes
**   -# It must have the same function signature as TlmGen_Func defined in
**      app_tlmgen.h
**
** \param[in,out]  TlmObjPtr  Pointer to example application telemetry manager object
** \param[out]     TlmMsgPtr  Pointer to telemetry message to be packed
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void FwApp_Tlm_Housekeeping (void*            TlmObjPtr, 
                             CFE_SB_MsgPtr_t  TlmMsgPtr);


/**
** \brief  Pack data into example app's vector telemetry packet
**
** \notes
**   -# It must have the same function signature as TlmGen_Func defined in
**      app_tlmgen.h
**
** \param[in,out]  TlmObjPtr  Pointer to example application telemetry manager object
** \param[out]     TlmMsgPtr  Pointer to telemetry message to be packed
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void FwApp_Tlm_Vector (void*            TlmObjPtr, 
                       CFE_SB_MsgPtr_t  TlmMsgPtr);

#endif /* _fwapp_tlm_ */
/** @} */
