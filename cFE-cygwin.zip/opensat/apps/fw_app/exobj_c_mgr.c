/* 
** File:
**   $Id: $
**
** Purpose: ExObj_C manager
**
** $Id: example_app/objC_mgr.c 1.1 2006/05/10 13:36:45EDT dcmccomas Exp  $
**
** Notes
**   1. This is non-flight code.
**   2. Framework design notes:
**      - ExObj_C is defined as static file data. This means only one instance of
**        ExObj_C can exist. ExObj_C could be defined within ExObj_C_Mgr_Class as 
**        opposed to a pointer to ExObj_C.
**      - If this object were being designed to be reused it couldn't depend
**        on fwapp_spec.h. The object ID would have to be passed into the
**        constructor.
**
** $Date: 2006/05/10 13:36:45EDT $
** $Revision: 1.1 $
** $Log: example_app/objC_mgr.c  $
** Revision 1.1 2006/05/10 13:36:45EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Includes
*/

#include "exobj_c_mgr.h"

#include "cfe_evs.h"
#include "fwapp_spec.h"



/*
** Macro Definitions
*/

#define EVS_ID(Offset) ((uint16)(ExObjCMgr->EvsIdBase + Offset)) 
#define FD_ID(Offset)  ((uint16)(ExObjCMgr->FaultDetIdBase + (Offset))) 


/*
** File Data
*/

static ExObj_C_Class  ExObjC;


/*
** Local Functions
*/

static boolean SrcDataValid(ExObj_C_Mgr_Class*  ExObjCMgr,
                            ExObj_C_Mgr_Table*  ExObjCTbl,
                            const Vector3d*     VecA,
                            const Vector3d*     VecB);


/******************************************************************************
** Function: ExObj_C_Mgr_Constructor
**
*/

void ExObj_C_Mgr_Constructor(ExObj_C_Mgr_Class*  ExObjCMgr,
                             ExObj_C_Mgr_Table*  ExObjCMgrTbl,
                             App_FaultRep_Class* FaultRepObj,
                             uint16*             EvsIdBase,
                             uint16*             FaultDetIdBase)
{


   ExObjCMgr->ExObjC        = &ExObjC;
   ExObjCMgr->ExObjCEnabled = TRUE;
   ExObjCMgr->FaultRepObj   = FaultRepObj;

   ExObj_C_Constructor(ExObjCMgr->ExObjC, &ExObjCMgrTbl->ExObjC, FWAPP_EXOBJ_C_ID,
                       EvsIdBase, FaultDetIdBase);

   ExObjCMgr->EvsIdBase       = *EvsIdBase;
   ExObjCMgr->FaultDetIdBase  = *FaultDetIdBase;

   *EvsIdBase      += EXOBJ_C_MGR_EVS_ID_CNT;
   *FaultDetIdBase += EXOBJ_C_MGR_FD_ID_CNT;


} /* End ExObj_C_Mgr_Constructor() */



/******************************************************************************
** Function: ExObj_C_Mgr_Execute
**
*/

void ExObj_C_Mgr_Execute(ExObj_C_Mgr_Class*  ExObjCMgr,
                         ExObj_C_Mgr_Table*  ExObjCMgrTbl,
                         const Vector3d*     VecA,                    
                         const Vector3d*     VecB)
{



   ExObjCMgr->ExObjC->ErrVector.Comp[0] = 0.0;
   ExObjCMgr->ExObjC->ErrVector.Comp[1] = 0.0;
   ExObjCMgr->ExObjC->ErrVector.Comp[2] = 0.0;

   if (ExObjCMgr->ExObjCEnabled)
   {

      if ( SrcDataValid(ExObjCMgr, ExObjCMgrTbl, VecA, VecB) )
      {
      
         ExObj_C_ComputeErrVector(ExObjCMgr->ExObjC, &ExObjCMgrTbl->ExObjC, VecA, VecB, ExObjCMgr->FaultRepObj);

      } /* End if SrcDataValid() */

      
   } /* End if ExObj_C enabled */
     


} /* End ExObj_C_Mgr_Execute() */




/******************************************************************************
** Function: ExObj_C_Mgr_ConfigCmd
**
*/

boolean ExObj_C_Mgr_ConfigCmd (      void*  CmdObj,
                               const void*  CmdParam)
{

   ExObj_C_Mgr_Class*  ExObjCMgr = (ExObj_C_Mgr_Class*)CmdObj;
   
   ExObj_C_Mgr_ConfigCmdParam*  Cmd = (ExObj_C_Mgr_ConfigCmdParam*)CmdParam;


   if (Cmd->Enable == TRUE)
   {
   
      ExObjCMgr->ExObjCEnabled = TRUE;
      CFE_EVS_SendEvent (EVS_ID(EXOBJ_C_MGR_EVS_OBJC_ENABLED),
                         CFE_EVS_INFORMATION,
                         "ExObj C enabled");

   
   } else
   {

      ExObjCMgr->ExObjCEnabled = FALSE;

      CFE_EVS_SendEvent (EVS_ID(EXOBJ_C_MGR_EVS_OBJC_DISABLED),
                         CFE_EVS_INFORMATION,
                         "ExcObj C disabled");
   
   }

   return TRUE;

} /* End ExObj_C_Mgr_ConfigCmd() */



/******************************************************************************
** Function: SrcDataValid
**
** Note:
**   1. This is for framework illustrative purposes only.
**      
*/

static boolean SrcDataValid(ExObj_C_Mgr_Class*  ExObjCMgr,
                            ExObj_C_Mgr_Table*  ExObjCMgrTbl,
                            const Vector3d*     VecA,
                            const Vector3d*     VecB)
{

   boolean RetStatus = TRUE;

   if ( Vector3d_Magnitude(VecA) < ExObjCMgrTbl->FdLimit[0] )
   {
      App_FaultRep_FaultDetFailed(ExObjCMgr->FaultRepObj,FD_ID(EXOBJ_C_MGR_FD_DATA_SRC_A_ERR));
      RetStatus = FALSE;
   }

   if ( Vector3d_Magnitude(VecB) < ExObjCMgrTbl->FdLimit[1] )
   {
      App_FaultRep_FaultDetFailed(ExObjCMgr->FaultRepObj,FD_ID(EXOBJ_C_MGR_FD_DATA_SRC_B_ERR));
      RetStatus = FALSE;
   }

   return RetStatus;

} /* End SrcDataValid() */


/*  end of file  */
