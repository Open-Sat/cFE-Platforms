/** \file
** 
** \brief Unit specification for the ExObj_C class (framework dependent object)
**
** $Id: example_app/objC.h 1.1 2006/05/10 13:36:45EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code
**   -# Framework dependent(non-entity) object have flight architectural
**      dependencies either on the cFE or the GN&C framework. They can
**      still be in the reuse library but they can't be shared as easily
**      on other platforms as framework independent(entity) objects.
**
** \par References:
**   -# Core Flight Executive Application Developers Guide.
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:45EDT $
** $Revision: 1.1 $
** $Log: example_app/objC.h  $
** Revision 1.1 2006/05/10 13:36:45EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2006/05/01 09:27:02EDT dcmccomas 
** 
** Revision 1.1 2005/11/07 07:39:52EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/** 
** @addtogroup objects_fr
** @{
*/

#ifndef _exobj_c_
#define _exobj_c_

/*
** Includes
*/

#include "app_faultrep.h"
#include "common_types.h"
#include "vector3d.h"


/******************************************************************************
** Macro Definitions
*/

/*
** cFE Event Service IDs
*/

#define  EXOBJ_C_EVS_CONFIG_CMD_ERR   0
#define  EXOBJ_C_EVS_ID_CNT           1

/*
** Fault Reporter Detector IDs
** - The axis IDs must be contiguous
*/

#define  EXOBJ_C_FD_AXIS_X_FAILED   0
#define  EXOBJ_C_FD_AXIS_Y_FAILED   1
#define  EXOBJ_C_FD_AXIS_Z_FAILED   2
#define  EXOBJ_C_FD_ID_CNT          3


/******************************************************************************
** Type Definitions
*/


typedef struct
{

   uint16     Id;
   uint16     EvsIdBase;
   uint16     FaultDetIdBase;
   boolean    FaultDetEnabled[3];
   Vector3d   ErrVector;

} ExObj_C_Class;


typedef struct
{

   float   FaultLimit[3];

} ExObj_C_Table;


typedef struct
{

   boolean  Enable[3];     /**< TRUE - Enable axis check; FALSE - Disable axis check */

} ExObj_C_ConfigFaultDetCmdParam;


/*
** Exported Functions
*/

/**
** \brief Initialize ExObj_C class data
**
** \note
**   -# Fault Detectors default to disabled
**
** \param[in,out]  ExObjC          An instance of an ExObj_C class
** \param[in]      ExObjCTbl       A reference to a pointer to ObjC's table
** \param[in]      ObjId           Object identifier, just some extra data
** \param[in,out]  EvsIdBase       Starting EVS ID
** \param[in,out]  FaultDetIdBase  Starting fault detector ID
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void ExObj_C_Constructor(ExObj_C_Class*  ExObjC,
                         ExObj_C_Table*  ExObjCTbl,
                         uint16          ObjId,
                         uint16*         EvsIdBase,
                         uint16*         FaultDetIdBase);


/**
** \brief  Compute errors between Sensor and Model data
**
** \note
**   -# If enabled (on per-axis basis) notify FaultRep of errors
**
** \param[in,out]  ExObjC       An instance of an ExObj_C class
** \param[in]      ExObjCTbl    A reference to a pointer to ObjC's table
** \param[in]      Sensor       Sensor data from ExObj_A
** \param[in,out]  Model        Model data from ExObj_B
** \param[in,out]  FaultRepObj  Pointer to App's fault reporter
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void ExObj_C_ComputeErrVector(ExObj_C_Class*      ExObjC,
                              ExObj_C_Table*      ExObjCTbl,
                              const Vector3d*     Sensor,
                              const Vector3d*     Model,
                              App_FaultRep_Class* FaultRepObj);


/**
** \brief  Configure (enable/disable) per-axis fault detector
**
** \note
**   -# This is for illustrative purposes only
**
** \param[in,out]  CmdObj       Pointer to OxObj_C's object data
** \param[in]      CmdParam     Pointer to 
**
** \returns
** \retcode TRUE  \retdesc Valid command parameters and fault detectors set to commanded values \endcode
** \retcode FALSE \retdesc Invalid command parameters and ground notify of error \endcode
** \endreturns
*/

boolean ExObj_C_ConfigFaultDetCmd (      void*  CmdObj,
                                   const void*  CmdParam);


#endif /* _exobj_c_ */
/** @} */
