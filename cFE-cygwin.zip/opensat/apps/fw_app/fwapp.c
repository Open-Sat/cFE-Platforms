/* 
** File:
**   $Id: $
**
** Purpose: Provide an example application using the GNC application framework..
**
** Notes:
**   1. This is non-flight code.
**   2. If a housekeeping packet is required it should be managed by a separate
**      object that registers it during construction and provides a generation
**      function. This decouples an application interface function from the
**      main application.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. GN&C FSW Framework Programmer's Guide
**
** $Date: 2006/11/01 09:12:19EST $
** $Revision: 1.13 $
** $Log: example_app/exapp.c  $
** Revision 1.13 2006/11/01 09:12:19EST dcmccomas 
** Added changes for auto vs user defined cmd function code
** Revision 1.12 2006/08/21 14:52:46EDT dcmccomas 
** Add support for new cFE ES performance monitoring API
** Revision 1.11 2006/07/27 14:30:08EDT dcmccomas 
** Modified App_Frame constructor to pass in maximum fault detector count.
** Revision 1.10 2006/06/13 11:41:54EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.9 2006/05/10 13:35:51EDT dcmccomas 
** 
** Revision 1.8 2006/05/01 09:27:04EDT dcmccomas 
** 
** Revision 1.7 2006/04/06 08:56:03EDT dcmccomas 
** 
** Revision 1.6 2006/03/28 14:56:26EST dcmccomas 
** 
** Revision 1.5 2006/03/24 14:14:10EST dcmccomas 
** Added "app_" prefix to cfe and gnc framework objects
** Revision 1.4 2006/03/23 15:16:25EST dcmccomas 
** Add interface to new app_pipemgr, app_msg, and app_cmdmsg which also changed app_frame.
** Revision 1.3 2005/11/30 09:17:35EST dcmccomas 
** Databus group removal
** Revision 1.2 2005/11/07 14:15:14EST dcmccomas 
** Added doygen markup
**
*/

/*
** Includes
*/

#include "fwapp.h"

#include "mission_def.h"

#include "cfe_evs.h"
#include "cfe_time.h"

#include "app_frame.h"
#include "fwapp_tlm.h"


/*
** Exported Data
*/


FwApp_Class   FwApp;


/*
** Local Function Prototypes
*/

static void FwAppInit(void);

/*
** Function Definitions
*/


/******************************************************************************
** Function: FwApp_Main
**
** Notes:
**   1. This function is only called once by the cFE during processor
**      initialization. All subsequent executions are managed by software
**      bus calls within the infinite loop.
**
*/
void FwApp_Main (void) 
{

   CFE_TIME_SysTime_t CycleTime;
   uint32             AppStatus = CFE_SUCCESS;

   AppStatus = CFE_ES_RegisterApp();
   CFE_ES_WriteToSysLog("FwApp register return = 0x%X\n", AppStatus);
   if (AppStatus == CFE_SUCCESS)
   {
      CFE_ES_PerfLogEntry(FWAPP_CFE_PERF_ID); /* Start performance monitoring */
      FwAppInit();   /* Initialize application */
      AppStatus = CFE_ES_APP_RUN;
   }
   else
   {
      AppStatus = CFE_ES_APP_ERROR;   /* Set status to terminate main loop */
   }


   /* 
   ** Enter main tasking loop
   ** - Call CFE_ES_RunLoop() to check for changes in the Application's status. 
   **   If there is a request to kill this App, it will be passed in through the
   **   RunLoop call.
   */
   
   while (CFE_ES_RunLoop(&AppStatus))
    {

      /* Pend to create a task delay to avoid flooding TLM (avoid scheduler dependencies as well) */
      App_PipeMgr_PendForMsg(&FwApp.AppFrame.CmdPipeMgr,5000,1);

      CycleTime = CFE_TIME_GetUTC();

      App_DataBus_StartCycle(&FwApp.AppFrame.DataBus);


      /*FwApp.ObjMgr.Tbl->App_ObjMgr_ExecuteFunc(&FwApp.ObjMgr.Parent); */
      FwApp_ObjMgr_Execute(&FwApp.ObjMgr);

      /*
	   ** Logic as to whether to merge FaultRep report could go here
	   */ 

      CycleTime = App_DataBus_GetCfeCycleTime(&FwApp.AppFrame.DataBus);
      App_TlmGen_Execute(&FwApp.AppFrame.TlmGen, &CycleTime);


   } /* End main tasking loop */

   /* 
   ** Task will only exit if there is an SB on the scheduler bus
   ** - Write to system log in case event services is not working
   */

   CFE_EVS_SendEvent(999, CFE_EVS_CRITICAL,
                     "Application terminated, Error = 0x%X", AppStatus);

   CFE_ES_WriteToSysLog("FwApp terminating, err = 0x%X", AppStatus);

   CFE_ES_ExitApp(AppStatus); /* Terminate main task and any child tasks */


} /* End FwApp_Main () */

/******************************************************************************
** Data: Initialization Data
**
** Purpose: Provide initialization data FwApp
**
*/
static App_Frame_Cmd FwApp_GndCmd = 
{

   "FwApp Pipe",
   FWAPP_CMD_PIPE_LEN,
   "App Cmd Msg",
   FWAPP_CMD_MSG_ID,
   FWAPP_CMD_MSG_MAX,
   APP_FRAME_CMD_FC_AUTO,

   FwApp.Cmd,
   FWAPP_CMD_CNT
   
};

static App_Frame_FaultRep FwApp_FaultRep =
{

   FWAPP_TLM_FD_MSG_ID,
   FWAPP_FD_ID_CNT+1

};

static App_Frame_HouseKp  FwApp_HouseKp =
{
 
   FWAPP_HK_REQ_MSG_ID,
   FWAPP_HK_REQ_MSG_LEN,
   FWAPP_TLM_HK_RPY_MSG_ID

};

static App_Frame_DataSrc FwApp_DataSrc =
{
 
   FwApp.Data,
   FWAPP_DB_CNT

};

/******************************************************************************
** Function: FwAppInit
**
** Purpose: Initialize the App task.
**
*/
void FwAppInit (void) 
{

   App_Frame_Init  FrameInit;



   FrameInit = App_Frame_Constructor(&FwApp.AppFrame,
                                     FWAPP_MISSION_EPOCH,
                                     FWAPP_CFE_PERF_ID,
	                                  &FwApp_GndCmd,
                                     &FwApp_HouseKp,
                                     &FwApp_DataSrc,
                                     &FwApp_FaultRep);

   FwApp_ObjMgr_Constructor (&FwApp.ObjMgr, &FwApp.AppFrame, &FwApp.AppFrame.EvsIdCnt);


   FwApp_Tlm_Constructor (&FwApp.Tlm, &FwApp.AppFrame.TlmGen, &FwApp.AppFrame.DataBus);


   CFE_EVS_SendEvent (FwApp.AppFrame.EvsIdCnt, /* TBD - Fixed after object manager. */
	                   CFE_EVS_INFORMATION,
	                   "App v1.0 initialized with %d events",
                      FwApp.AppFrame.EvsIdCnt);


} /* End FwAppInit() */

/* end of file */
