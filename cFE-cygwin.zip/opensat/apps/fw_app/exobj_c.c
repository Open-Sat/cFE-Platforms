/*
** File:
**   $Id: example_app/objC.c 1.1 2006/05/10 13:36:44EDT dcmccomas Exp  $
**
** Purpose Implement the ExObj_C class (framework dependent object)
**
** Notes
**   1. This is non-flight code.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:44EDT $
** $Revision: 1.1 $
** $Log: example_app/objC.c  $
** Revision 1.1 2006/05/10 13:36:44EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.3 2006/05/01 09:27:03EDT dcmccomas 
** 
** Revision 1.2 2006/03/24 14:14:11EST dcmccomas 
** Added "app_" prefix to cfe and gnc framework objects
** Revision 1.1 2005/11/07 07:39:50EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Includes
*/

#include <math.h>
#include "cfe_evs.h"
#include "app_faultrep.h"
#include "exobj_c.h"

/*
** Macro Definitions
*/

#define EVS_ID(Offset) ((uint16)(ExObjC->EvsIdBase + (Offset))) 
#define FD_ID(Offset)  ((uint16)(ExObjC->FaultDetIdBase + (Offset))) 



/*
** Exported Functions
*/

/******************************************************************************
** Function: ExObj_C_Constructor
**
*/
void ExObj_C_Constructor(ExObj_C_Class*  ExObjC,
                         ExObj_C_Table*  ExObjCTbl,
                         uint16          ObjId,
                         uint16*         EvsIdBase,
                         uint16*         FaultDetIdBase)
{

   int i;

   
   ExObjC->Id             = ObjId;
   ExObjC->EvsIdBase      = *EvsIdBase;
   ExObjC->FaultDetIdBase = *FaultDetIdBase;

   *EvsIdBase      += EXOBJ_C_EVS_ID_CNT;
   *FaultDetIdBase += EXOBJ_C_FD_ID_CNT;


   for (i=0; i < 3; i++)
   {
   
      ExObjC->ErrVector.Comp[i]  = 0.0;
      ExObjC->FaultDetEnabled[i] = FALSE;
   
   } /* End axis loop */

} /* ExObj_C_Constructor() */


/******************************************************************************
** Function: ExObj_C_ComputeErrVector
**
*/
void ExObj_C_ComputeErrVector(ExObj_C_Class*      ExObjC,
                              ExObj_C_Table*      ExObjCTbl,
                              const Vector3d*     Sensor,
                              const Vector3d*     Model,
                              App_FaultRep_Class* FaultRepObj)
{

   int i;

   for (i=0; i < 3; i++)
   {

      ExObjC->ErrVector.Comp[i] = fabs((double)(Sensor->Comp[i] - Model->Comp[i]));
      
      if (ExObjC->FaultDetEnabled != FALSE)
      {
         if ( ExObjC->ErrVector.Comp[i] > ExObjCTbl->FaultLimit[i] )
         {

            App_FaultRep_FaultDetFailed(FaultRepObj,FD_ID((EXOBJ_C_FD_AXIS_X_FAILED+i)));

         } /* End if fault detector failed */


      } /* End if fault detctor enabled */

   } /* End axis loop */


} /* ExObj_C_ComputeErrVector() */


/******************************************************************************
** Function: ExObj_C_ConfigFaultDetCmd
**
** Notes:
**   1. Enforce explicit TRUE or FALSE value
*/

boolean ExObj_C_ConfigFaultDetCmd (      void*  CmdObj,
                                   const void*  CmdParam)
{

   int i;
   boolean RetStatus = TRUE;

   ExObj_C_Class* ExObjC = (ExObj_C_Class*)CmdObj;

   ExObj_C_ConfigFaultDetCmdParam* ConfigFaultDet = (ExObj_C_ConfigFaultDetCmdParam*)CmdParam;


   for (i=0; ( (i < 3) && (RetStatus == TRUE) ); i++)
   {

      if ( (ConfigFaultDet->Enable[i] == FALSE) || (ConfigFaultDet->Enable[i] == TRUE) )
      {
         
         ExObjC->FaultDetEnabled[i] = ConfigFaultDet->Enable[i];

      } /* End if valid parameter */
      else
      {
      
         CFE_EVS_SendEvent (EVS_ID(EXOBJ_C_EVS_CONFIG_CMD_ERR),
                            CFE_EVS_ERROR,
                            "ExObj_C cmd rejected: Invalid configuration on axis %d", i);
         
         RetStatus = FALSE;

      } /* End if invalid parameter */

   } /* End axis loop */


   return RetStatus;

} /* End ExObj_C_ConfigFaultDetCmd() */

/* end of file */
