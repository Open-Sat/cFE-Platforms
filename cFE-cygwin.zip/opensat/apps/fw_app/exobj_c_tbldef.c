/* 
** File:
**   $Id: $
**
** Purpose: Define default values for ExObj_C's table.
**
** Notes
**   1. This is non-flight code.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:45EDT $
** $Revision: 1.1 $
** $Log: example_app/objC_tbldef.c  $
** Revision 1.1 2006/05/10 13:36:45EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.1 2005/11/07 07:39:53EST dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Includes
*/


#include "exobj_c.h"
#include "fwapp_tabledef.h"


/*
** Exported Data
*/

ExObj_C_Table  ExObj_C_TblDef =
{
   /* Coeff[] */
   {
      EXOBJ_C_TBL_FAULT_LMT_0,
      EXOBJ_C_TBL_FAULT_LMT_1,
      EXOBJ_C_TBL_FAULT_LMT_2
   }

}; /* End ExObj_C_TblDef */


/* end of file */
