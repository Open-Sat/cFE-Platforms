/* 
** File:
**   $Id: $
**
** Purpose: Implement the ObjA class
**
** $Id: example_app/objA.c 1.1 2006/05/10 13:36:42EDT dcmccomas Exp  $
**
** Notes
**   1. This is non-flight code.
**   2. This code demonstrates using a pointer to a table pointer. This
**      resulted in fairly involved syntax. A macro was created to hide
**      the syntax, but this relies on a table pointer naming convention
**      and it's another custom thing a coder must do. See ObjB for
**      a different approach.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:42EDT $
** $Revision: 1.1 $
** $Log: example_app/objA.c  $
** Revision 1.1 2006/05/10 13:36:42EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2005/11/07 14:15:13EST dcmccomas 
** Added doygen markup
**
*/

/*
** Includes
*/

#include "exobj_a.h"

#define TBL(Obj,Field) ((*Obj->Tbl)->Field)

/*
** Exported Functions
*/

/******************************************************************************
** Function: ObjA_Constructor
**
*/
void ExObj_A_Constructor(ExObj_A_Class*   ExObjA,
                         ExObj_A_Table**  ExObjATbl,
                         uint16           ObjId)

{

   int i;

   ExObjA->Id  = ObjId;
   ExObjA->Tbl = ExObjATbl;

   for (i=0; i < 3; i++)
   {
   
      ExObjA->Vector.Comp[i]  = 0.0;
   
   } /* End axis loop */
   
} /* ExObj_A_Constructor() */


/******************************************************************************
** Function: ExObj_A_ComputeVector
**
*/

void ExObj_A_ComputeVector(ExObj_A_Class*  ExObjA,
                           uint8           SensorData[3])

{

   int i;

   for (i=0; i < 3; i++)
   {

      ExObjA->Vector.Comp[i] = 
         
         (double) (SensorData[i] + TBL(ExObjA,Bias[i]) ) * (*ExObjA->Tbl)->ScaleFactor[i];

   }


} /* ExObj_A_ComputeVector() */


/* end of file */
