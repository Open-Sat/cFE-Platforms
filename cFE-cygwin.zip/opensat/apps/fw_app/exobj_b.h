/** \file
** 
** \brief Unit specification for the ExObj_B class (framework independent object)
**
** $Id: example_app/objB.h 1.1 2006/05/10 13:36:44EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**   -# The table approach for this object is to pass a table pointer to each
**      member function. See ExObj_A for alternate approach.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:44EDT $
** $Revision: 1.1 $
** $Log: example_app/objB.h  $
** Revision 1.1 2006/05/10 13:36:44EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.3 2006/01/31 14:48:10EST dcmccomas 
** 
** Revision 1.2 2005/11/07 14:15:14EST dcmccomas 
** Added doygen markup
**
*/

/** 
** @addtogroup objects
** @{
*/

#ifndef _exobj_b_
#define _exobj_b_

/*
** Includes
*/

#include "common_types.h"
#include "vector3d.h"


/*
** Type Definitions
*/


typedef struct
{

   uint16     Id;
   Vector3d   Vector;

} ExObj_B_Class;


typedef struct
{

   float   Coeff[3];

} ExObj_B_Table;


/*
** Exported Functions
*/

/**
** \brief Initialize ObjB class data
**
** \brief Initialize ObjA class data.
**
** \param[in,out]  ExObjB     An instance of an ExObj_B class
** \param[in]      ExObjBTbl  A reference to a pointer to ObjB's table
** \param[in]      ObjId      Object identifier, just some extra data
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void ExObj_B_Constructor(ExObj_B_Class*  ExObjB,
                         ExObj_B_Table*  ExObjBTbl,
                         uint16          ObjId);


/**
** \brief  Compute a vector based on the time.
**
** \param[in,out]  ExObjB     An instance of an ExObj_B class
** \param[in]      ExObjBTbl  A reference to a pointer to ObjB's table
** \param[in]      SomeValue  Any doube value useful for demos
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void ExObj_B_ComputeVector(ExObj_B_Class*  ExObjB,
                           ExObj_B_Table*  ExObjBTbl,
                           double          SomeValue);



#endif /* _exobj_b_ */
/** @} */
