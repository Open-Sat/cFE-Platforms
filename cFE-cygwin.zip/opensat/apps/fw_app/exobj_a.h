/** \file
** 
** \brief Unit specification for the ExObj_A class (framework independent object)
**
** $Id: example_app/objA.h 1.1 2006/05/10 13:36:42EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**   -# This represents an algorithm-based entity object. It could be a sensor
**      object (without fault detection) or a target quaternion object. Its
**      unit test could use data from the analyst's simulation, manually
**      generated expected results, or a combination of both.
**   -# ObjA_Class uses ObjA_Table** to access its table. This
**      demonstrates one of two methods for handling tables (See reference 1
**      for an explanation of tables and entity objects). This method allows
**      the entity object's constructor to get the table pointer reference
**      and other member functions don't require a table pointer parameter.
**      The tradeoff is that the readablity of the code. See ObjB for 
**      another design option.
**
** \par References:
**   -# GN&C FSW Framework Programmer's Guide
**   -# Project algorithm document
**
**    
** $Date: 2006/05/10 13:36:42EDT $
** $Revision: 1.1 $
** $Log: example_app/objA.h  $
** Revision 1.1 2006/05/10 13:36:42EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.3 2006/01/31 14:48:00EST dcmccomas 
** 
** Revision 1.2 2005/11/07 14:15:13EST dcmccomas 
** Added doygen markup
**
*/

/** 
** @addtogroup objects
** @{
*/

#ifndef _exobj_a_
#define _exobj_a_

/*
** Includes
*/

#include "common_types.h"
#include "vector3d.h"


/*
** Type Definitions
*/

typedef struct
{

   float   Bias[3];
   float   ScaleFactor[3];

} ExObj_A_Table;


typedef struct
{

   uint16           Id;       /**< Object identifier */
   Vector3d         Vector;   /**< Output vector     */
   ExObj_A_Table**  Tbl;      /**< See file notes    */

} ExObj_A_Class;



/*
** Exported Functions
*/

/**
** \brief Initialize ObjA class data.
**
** \param[in,out]  ExObjA     An instance of an ExObj_A class
** \param[in]      ExObjATbl  A reference to a pointer to ObjA's table
** \param[in]      ObjId      Object identifier, just some extra data
**
** \returns
** \retcode void \endcode
** \endreturns
*/

void ExObj_A_Constructor(ExObj_A_Class*   ExObjA,
                         ExObj_A_Table**  ExObjATbl,
                         uint16           ObjId);


/**
** \brief Compute a vector based on the sensor data.
**
** \param[in,out]  ExObjA       An instance of an ExObj_A class
** \param[in]      SensorData   Raw measurement data
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void ExObj_A_ComputeVector(ExObj_A_Class*  ExObjA,
                           uint8           SensorData[3]);



#endif /* _exobj_a_ */
/** @} */
