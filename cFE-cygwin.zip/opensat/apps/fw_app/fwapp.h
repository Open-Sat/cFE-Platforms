/** \file
** 
** \brief Unit specification for the example Framework Application.
**
** $Id: example_app/fwapp.h 1.8 2006/07/27 14:30:32EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**
** References:
**   -# Core Flight Executive Application Developers Guide.
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/07/27 14:30:32EDT $
** $Revision: 1.8 $
** $Log: example_app/exapp.h  $
** Revision 1.8 2006/07/27 14:30:32EDT dcmccomas 
** Added missing doxygen markup.
** Revision 1.7 2006/05/10 13:35:51EDT dcmccomas 
** 
** Revision 1.6 2006/03/28 14:56:26EST dcmccomas 
** 
** Revision 1.5 2006/03/24 14:14:11EST dcmccomas 
** Added "app_" prefix to cfe and gnc framework objects
** Revision 1.4 2006/03/23 15:16:26EST dcmccomas 
** Add interface to new app_pipemgr, app_msg, and app_cmdmsg which also changed app_frame.
** Revision 1.3 2005/11/30 09:17:36EST dcmccomas 
** Databus group removal
** Revision 1.2 2005/11/07 14:15:15EST dcmccomas 
** Added doygen markup
**
** \todo 
**   -# fwapp: Can Entity objects use OS_MemSet?
**   -# fwapp: Consider example to use a reusable I/F object that has parameters that are
**             merged into the GCAM's table.
**   -# fwapp: Use of constructor vs. init: CmdMgr and Entity use Init() and 
**             not Constructor(). What do I want?
**   -# fwapp: Decide on use of "Obj" suffix.
**   -# fwapp: Use const qualifier
**   -# fwapp: Put all of the ObjMgr structures into a single App structure that can
**      be sent to TlmGen
**   -# fwapp: Make framework documentation standards. For example list user
**             configurable items in the Notes section of a file prologue. Use 
**             "#ifndef" for each user configurable item.
**   -# fwapp: If a ObjMgr needs to create a table then it makes a copy of the Entity's
**             table inside its table structure. Don't use Entity's GetTableDef()
**             function, instead pass a reference to the ObjMgr's copy.
**   -# fwapp: DataBus - Consider a monitor options:
**             - Function that can be triggered. For example when last object update
**               occurs check status of group.
**             - Could have one monitor function that is called at end of cycle. I'm
**               not sure what it buys because monitoring needs limits in a table and
**               probably mission specific
**   -# fwapp: Need error checking rules based. Errors detected by unit testing should 
**             not need to be checked. Maybe asserts are better for this?
**   -# fwapp: There are three potential interfaces for each framework object. (1) the 
**             object itelf, (2) the Application (Constructor), (3) other objects. 
**             Should separate header files be created?
**   -# fwapp: Predefine common objects I/F to allow reusable components to plug 
**             into bus using group name: BodyRates, SunInBody, EstQ
**   -# fwapp: TBD - There seems to be multiple dimensions to the type: a data type, 
**             the physical type, is it stateless or does it have a state, etc.
**   -# fwapp: Do I need to capture the idea that a databus Allows data to flow 
**             between units without concern of the module hierarchy.  Any "level"
**             can send and receive data. ObjMgrs actually level the communications
**             field, so this aspect isn't relevant.
*/

/** 
** @addtogroup framework_fwapp
** @{
*/

#ifndef _fwapp_ 
#define _fwapp_

/*
** Includes
*/

#include "common_types.h"

#include "app_frame.h"
#include "fwapp_spec.h"
#include "fwapp_tlm.h"
#include "fwapp_objmgr.h"

/*
** Macro Definitions
*/

#ifdef FWAPP_DEBUG
   #define FWAPP_MAIN_LOOP (App_DataBus_GetCycleTime(&FwApp.AppFrame.DataBus) < 5)
#else
   #define FWAPP_MAIN_LOOP (TRUE)
#endif


/*
** Type Definitions
*/

typedef struct 
{

   App_Frame_Class     AppFrame;

   App_DataBus_DataSrc Data[FWAPP_DB_CNT];
   App_CmdMsg_FuncRec  Cmd[FWAPP_CMD_CNT];
   
   FwApp_Tlm_Class     Tlm;
   FwApp_ObjMgr_Class  ObjMgr;


} FwApp_Class;


/*
** Exported Data
*/

extern FwApp_Class  FwApp;


/*
** Exported Functions
*/

/**
** \brief cFE Example Application entry function
**
** \returns
** \retcode void \endcode
** \endreturns
*/
void FwApp_Main(void);


#endif /* _fwapp_ */
/** @} */
