/** \file
** 
** \brief Define default table values for the GN&C framework example app
**
** $Id: example_app/fwapp_tabledef.h 1.1 2006/05/10 13:36:42EDT dcmccomas Exp  $
**
** \note
**   -# This is non-flight code.
**   -# In practice this file could be automatically generated which is why
**      it is separate from the object's header file. Historically it has
**      been a single header file because the GNC parameters are released
**      as a group and all of the GNC code is built at the same time.
**
** References:
**   -# GN&C FSW Framework Programmer's Guide
**
**    
** $Date: 2006/05/10 13:36:42EDT $
** $Revision: 1.1 $
** $Log: example_app/exapp_tabledef.h  $
** Revision 1.1 2006/05/10 13:36:42EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
** Revision 1.2 2005/11/07 14:15:29EST dcmccomas 
** Add doxygen markup
**
*/

/** 
** @addtogroup framework_fwapp
** @{
*/

#ifndef _tabledef_
#define _tabledef_

/*
** Includes
*/

/*
** Macro Definitions
*/

#define  EXOBJ_A_TBL_BIAS_0    0
#define  EXOBJ_A_TBL_BIAS_1    1
#define  EXOBJ_A_TBL_BIAS_2    2

#define  EXOBJ_A_TBL_SF_0      0
#define  EXOBJ_A_TBL_SF_1      1
#define  EXOBJ_A_TBL_SF_2      2

#define  EXOBJ_B_TBL_COEFF_0  10
#define  EXOBJ_B_TBL_COEFF_1  20
#define  EXOBJ_B_TBL_COEFF_2  30

#define  EXOBJ_C_TBL_FAULT_LMT_0  100
#define  EXOBJ_C_TBL_FAULT_LMT_1  200
#define  EXOBJ_C_TBL_FAULT_LMT_2  300

#define  EXOBJ_C_MGR_TBL_FD_VECA_MAG_LIM  10 
#define  EXOBJ_C_MGR_TBL_FD_VECB_MAG_LIM  20

#endif /* _tabledef_ */
/** @} */
