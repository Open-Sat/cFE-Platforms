/* 
** File:
**   $Id: $
**
** Purpose: Example Framework Application Object Manager
**
** Notes
**   1. This is non-flight code.
**   2. Framework design notes:
**      - TBD
**
** $Date: 2006/11/01 09:12:20EST $
** $Revision: 1.3 $
** $Log: example_app/exapp_objmgr.c  $
** Revision 1.3 2006/11/01 09:12:20EST dcmccomas 
** Added changes for auto vs user defined cmd function code
** Revision 1.2 2006/06/13 11:41:54EDT dcmccomas 
** Post unit test updates, mostly cosmetic.
** Revision 1.1 2006/05/10 13:36:41EDT dcmccomas 
** Initial revision
** Member added to project d:/mksdata/gnc-fsw/framework/project.pj
**
*/

/*
** Includes
*/

#include "fwapp_objmgr.h"
#include "fwapp_spec.h"

#include "exobj_a.h"
#include "exobj_b.h"
#include "exobj_c_mgr.h"

/*
** Macro Definitions
*/

#define EVS_ID(Offset) ((uint16)(FwAppObjMgr->EvsIdBase + Offset)) 

/*
** File Data
*/

static ExObj_A_Class      ExObjA;
static ExObj_B_Class      ExObjB;
static ExObj_C_Mgr_Class  ExObjCMgr;


/*
** Imported Globals
*/

extern ExObj_A_Table      ExObj_A_TblDef;
extern ExObj_B_Table      ExObj_B_TblDef;
extern ExObj_C_Mgr_Table  ExObj_C_Mgr_TblDef;


/*
** Function Definitions
*/


void FwApp_ObjMgr_Constructor (FwApp_ObjMgr_Class*  FwAppObjMgr,
                               App_Frame_Class*     AppFrameObj,
                               uint16*              EvsIdBase)
{

   int32   RetStat;
   uint16  FaultId = FWAPP_FD_EXOBJ_C_MGR_START; /* Know there aren't others before ExObj_C */

   /*
   ** Initialize FwApp_ObjMgr
   */

   FwAppObjMgr->AppFrameObj = AppFrameObj;
   FwAppObjMgr->EvsIdBase   = *EvsIdBase;
   *EvsIdBase += EXOBJ_C_MGR_EVS_ID_CNT;

   /*
   ** Initialize Application Objects
   */

   FwAppObjMgr->ExObjA.Ptr      = &ExObjA;
   FwAppObjMgr->ExObjB.Ptr      = &ExObjB;
   FwAppObjMgr->ExObjCMgr.Ptr   = &ExObjCMgr;
   
   FwAppObjMgr->ExObjB.Enabled  = TRUE;


   ExObj_A_Constructor(FwAppObjMgr->ExObjA.Ptr, &FwAppObjMgr->ExObjA.TblPtr, FWAPP_EXOBJ_A_ID);
   ExObj_B_Constructor(FwAppObjMgr->ExObjB.Ptr, &ExObj_B_TblDef, FWAPP_EXOBJ_B_ID);

   ExObj_C_Mgr_Constructor(FwAppObjMgr->ExObjCMgr.Ptr,
                           &ExObj_C_Mgr_TblDef,
                           &FwAppObjMgr->AppFrameObj->FaultRep,
                           EvsIdBase, &FaultId);

   /*
   ** Register Commands
   */

   App_CmdMsg_RegFuncAuto(&(AppFrameObj->CmdMsg),
                          "ExObj_B Config",
                          FwApp_ObjMgr_ConfigExObjBCmd, 
                          (void*)FwAppObjMgr, 
                          sizeof(FwApp_ObjMgr_ConfigExObjBCmdParam));
   
   App_CmdMsg_RegFuncAuto(&(AppFrameObj->CmdMsg),
                          "ExObj_C Config",
                          ExObj_C_Mgr_ConfigCmd, 
                          (void*)FwAppObjMgr->ExObjCMgr.Ptr, 
                          sizeof(ExObj_C_Mgr_ConfigCmdParam));

   App_CmdMsg_RegFuncAuto(&(AppFrameObj->CmdMsg),
                          "ExObj_C Config FD",
                          ExObj_C_ConfigFaultDetCmd, 
                          (void*)&(FwAppObjMgr->ExObjCMgr.Ptr->ExObjC), 
                          sizeof(ExObj_C_ConfigFaultDetCmdParam));
   

   /*
   ** Register Tables
   */

   RetStat = CFE_TBL_Register (&FwAppObjMgr->ExObjA.TblHandle,
                               "ExObj A",
                               sizeof(ExObj_A_Table),
                               CFE_TBL_OPT_SNGL_BUFFER,
                               NULL);
   
   if (RetStat == CFE_SUCCESS)
   {
      FwAppObjMgr->ExObjA.TblInit = TRUE;
      CFE_TBL_Load(FwAppObjMgr->ExObjA.TblHandle, CFE_TBL_SRC_ADDRESS, &ExObj_A_TblDef);
   }


   RetStat = CFE_TBL_Register (&FwAppObjMgr->ExObjB.TblHandle,
                               "ExObj B",
                               sizeof(ExObj_B_Table),
                               CFE_TBL_OPT_SNGL_BUFFER,
                               NULL);
   
   if (RetStat == CFE_SUCCESS)
   {
      FwAppObjMgr->ExObjB.TblInit = TRUE;
      CFE_TBL_Load(FwAppObjMgr->ExObjB.TblHandle, CFE_TBL_SRC_ADDRESS, &ExObj_B_TblDef);
   }


   RetStat = CFE_TBL_Register (&FwAppObjMgr->ExObjCMgr.TblHandle,
                               "ExObj C Mgr",
                               sizeof(ExObj_C_Mgr_Table),
                               CFE_TBL_OPT_SNGL_BUFFER,
                               NULL);
   
   if (RetStat == CFE_SUCCESS)
   {
      FwAppObjMgr->ExObjCMgr.TblInit = TRUE;
      CFE_TBL_Load(FwAppObjMgr->ExObjCMgr.TblHandle, CFE_TBL_SRC_ADDRESS, &ExObj_C_Mgr_TblDef);
   }

   /*
   ** DataBus - Register Data Sources
   */

   App_DataBus_RegisterSrc(&AppFrameObj->DataBus,
                           FWAPP_DB_EXOBJ_A,
                           "ExObj A",
                           FwAppObjMgr->ExObjA.Ptr);

   App_DataBus_RegisterSrc(&AppFrameObj->DataBus,
                           FWAPP_DB_EXOBJ_B,
                           "ExObj B",
                           FwAppObjMgr->ExObjB.Ptr);

   App_DataBus_RegisterSrc(&AppFrameObj->DataBus,
                           FWAPP_DB_EXOBJ_C_MGR,
                           "ExObj C Mgr",
                           FwAppObjMgr->ExObjCMgr.Ptr);


   

} /* End FwApp_ObjMgr_Constructor() */


/******************************************************************************
** Function: FwApp_ObjMgr_Execute
**
*/

void FwApp_ObjMgr_Execute(FwApp_ObjMgr_Class* FwAppObjMgr)
{

   uint32  RetStat;
   uint8   SensorData[3] = {0, 1, 2};
   double  Time, SomeValue;
   
   ExObj_B_Table*      ExObjBTbl;
   ExObj_C_Mgr_Table*  ExObjCMgrTbl;


   /*
   ** Toggle SomeValue between 1 and 2 based on time's second being odd/even
   */

   Time = App_DataBus_GetCycleTime(&(FwAppObjMgr->AppFrameObj->DataBus));
   SomeValue = (double)(((int)Time) % 2) + 1.0;

   if (FwAppObjMgr->ExObjA.TblInit)
   {

       RetStat = CFE_TBL_GetAddress (&FwAppObjMgr->ExObjA.TblPtr, FwAppObjMgr->ExObjA.TblHandle);

       if (RetStat == CFE_SUCCESS)
       {      
          FwAppObjMgr->ExObjA.TblPtr = &ExObj_A_TblDef;
       }
   }
   else
   {
      FwAppObjMgr->ExObjA.TblPtr = &ExObj_A_TblDef;
   }

   ExObj_A_ComputeVector(FwAppObjMgr->ExObjA.Ptr, SensorData);
   App_DataBus_CommitData(&(FwAppObjMgr->AppFrameObj->DataBus), FWAPP_DB_EXOBJ_A);

   if (FwAppObjMgr->ExObjB.Enabled)
   {
     
      if (FwAppObjMgr->ExObjB.TblInit)
      {
   
         RetStat = CFE_TBL_GetAddress (&ExObjBTbl, FwAppObjMgr->ExObjB.TblHandle);

         if (RetStat != CFE_SUCCESS)
         {      
            ExObjBTbl = &ExObj_B_TblDef;
         }
      }
      else
      {
         ExObjBTbl = &ExObj_B_TblDef;
      }
      
      ExObj_B_ComputeVector(FwAppObjMgr->ExObjB.Ptr, ExObjBTbl, SomeValue);
      App_DataBus_CommitData(&(FwAppObjMgr->AppFrameObj->DataBus), FWAPP_DB_EXOBJ_B);

   } /* End if ExObj_B enabled */


   if (FwAppObjMgr->ExObjCMgr.TblInit)
   {
   
      RetStat = CFE_TBL_GetAddress (&ExObjCMgrTbl, FwAppObjMgr->ExObjCMgr.TblHandle);

      if (RetStat != CFE_SUCCESS)
      {      

         ExObjCMgrTbl = &ExObj_C_Mgr_TblDef;
      }
      

   } /* End if ExObj_C table initialized */
   else
   {
   
      ExObjCMgrTbl = &ExObj_C_Mgr_TblDef;
   
   } /* End if ExObj_C table not initialized */

   
   /* Could have logic for stale source data */

   ExObj_C_Mgr_Execute(FwAppObjMgr->ExObjCMgr.Ptr,
                       ExObjCMgrTbl,
                       &(FwAppObjMgr->ExObjA.Ptr->Vector),
                       &(FwAppObjMgr->ExObjB.Ptr->Vector) );
      
   App_DataBus_CommitData(&(FwAppObjMgr->AppFrameObj->DataBus),FWAPP_DB_EXOBJ_C_MGR);


} /* End FwApp_ObjMgr_Execute() */


/******************************************************************************
** Function: FwApp_ObjMgr_ConfigExObjB
**
*/

boolean  FwApp_ObjMgr_ConfigExObjBCmd (      void*  CmdObj,
                                       const void*  CmdParam)
{

   FwApp_ObjMgr_Class*  FwAppObjMgr = (FwApp_ObjMgr_Class*)CmdObj;
   
   FwApp_ObjMgr_ConfigExObjBCmdParam*  Cmd = (FwApp_ObjMgr_ConfigExObjBCmdParam*)CmdParam;


   if (Cmd->Enable == TRUE)
   {
   
      FwAppObjMgr->ExObjB.Enabled = TRUE;
      CFE_EVS_SendEvent (EVS_ID(FWAPP_OBJMGR_EVS_EXOBJ_B_ENABLED),
                         CFE_EVS_INFORMATION,
                         "ExObj B enabled");

   
   } else
   {

      FwAppObjMgr->ExObjB.Enabled = FALSE;

      CFE_EVS_SendEvent (EVS_ID(FWAPP_OBJMGR_EVS_EXOBJ_B_DISABLED),
                         CFE_EVS_INFORMATION,
                         "ExObj B disabled");
   
   }

   return TRUE;

} /* End FwApp_ObjMgr_ConfigExObjBCmd() */



/*  end of file  */
