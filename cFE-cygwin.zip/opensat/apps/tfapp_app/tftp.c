/* 
** File:
**   $Id: $
**
** Purpose: Implement the TFTP protocol.
**
** Notes
**   1. This code is based on the following file: http://cnds.eecs.jacobs-university.de/courses/np-2012/src/tftp/tftp.c
**      In it's header it states "A TFTP (RFC 1350) over IPv4/IPv6 client. This code is intended to
**      demonstrate (i) how to write encoding/decoding functions, (ii) how to implement a simple state
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. OpenSat Object-based Programmer's Guide
**
**
** $Date: $
** $Revision: $
** $Log: $
*/

/*
** Include Files:
*/

#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <time.h>

#include "app_config.h"
#include "tftp.h"
#include "network_includes.h"

/*
** Global File Data
*/

static TFTP_Class*    Tftp = NULL;

/*
** Local Function Prototypes
*/

static int CreateSocket(int Port);
static void FlushSocket(int SocketId);

static void InitSocket(void);

static void CompleteFileTransfer(void);

static void PrintDebugStr(char *spec,...);

static size_t EncodePkt(const uint16 Opcode, uint16 BlockNum,
		                unsigned char *DataPtr, size_t DataLen);

static int DecodeOpcode(unsigned char *Buf, size_t BufLen, uint16_t *Opcode);

static int DecodeBlockNum(unsigned char *Buf, size_t BufLen, uint16_t *BlockNum);

static int DecodeData(unsigned char *Buf, size_t BufLen,
	                  unsigned char **Data, size_t *DataLen);

static int DecodeError(unsigned char *Buf, size_t BufLen,
	                   uint16_t *ErrCode, char **ErrMsg);

static int TransferFile(void);


/******************************************************************************
** Function: TFTP_Constructor
**
*/
void TFTP_Constructor(TFTP_Class*  TftpPtr)
{

   Tftp = TftpPtr;


   /* Assumes some default/undefined states are 0 */
   
   CFE_PSP_MemSet((void*)Tftp, 0, sizeof(TFTP_Class));

   strcpy(Tftp->Host, "localhost");
   strcpy(Tftp->Port, "69");
   strcpy(Tftp->SrcFileName, "Undefined");
   strcpy(Tftp->DestFileName, "Undefined");

} /* End TFTP_Constructor() */


/******************************************************************************
** Function:  TFTP_ResetStatus
**
*/
void TFTP_ResetStatus()
{

   Tftp->GetFileCnt = 0;
   Tftp->PutFileCnt = 0;

   /* TODO - Decide if state machine should be reset */
   
} /* End TFTP_ResetStatus() */


/******************************************************************************
** Function: TFTP_SetDebugModeCmd
**
*/
boolean TFTP_SetDebugModeCmd(const CFE_SB_MsgPtr_t MsgPtr)
{
   const TFTP_SetDebugModeCmdParam *SetDebugModeCmd = (const TFTP_SetDebugModeCmdParam *) MsgPtr;
   boolean  RetStatus = TRUE;

   if (SetDebugModeCmd->Mode < TFTP_DEBUG_MAX) {
   
       Tftp->DebugMode = SetDebugModeCmd->Mode;
	   if (Tftp->DebugMode == TFTP_DEBUG_FILE) {
	       strncpy(Tftp->DebugFileName, SetDebugModeCmd->FileName, TFTP_FILE_NAME_LEN);

	       /* TODO - Open file & need a method to close it */
	   }
	   
   } /* End if valid mode */
   else {

	  RetStatus = FALSE;
      CFE_EVS_SendEvent(TFTP_INVLD_DBG_MODE_ERR_EID, CFE_EVS_ERROR,
	                     "Invalid debug mode %d. Mode must be 0..%d.", SetDebugModeCmd->Mode, (TFTP_DEBUG_MAX-1));
      strncpy(Tftp->DebugFileName, SetDebugModeCmd->FileName, TFTP_FILE_NAME_LEN);
	  Tftp->DebugFileName[TFTP_FILE_NAME_LEN-1] = '\0';
	  OS_printf("TFTP: Debug file name = %s\n", Tftp->DebugFileName);
	  
   }
   
   return RetStatus;

} /* End TFTP_SetDebugModeCmd() */


/******************************************************************************
** Function: TFTP_PutFileCmd
**
** Put a file from the caller to the system hosting TFTP app.
*/
boolean TFTP_PutFileCmd(const CFE_SB_MsgPtr_t MsgPtr)
{

   const TFTP_PutFileCmdParam *PutFileCmd = (const TFTP_PutFileCmdParam *) MsgPtr;
   boolean  RetStatus = TRUE;

   OS_printf("TFTP: TFTP_PutFileCmd() - Entry\n");
   InitSocket();
   
   strncpy(Tftp->SrcFileName, PutFileCmd->SrcFileName, TFTP_FILE_NAME_LEN);
   strncpy(Tftp->DestFileName, PutFileCmd->DestFileName, TFTP_FILE_NAME_LEN);

   /* TODO if ( (Tftp->FileDescr = open (PutFileCmd->DestFileName, O_WRONLY | O_CREAT, 0666)) == -1) { */
   if ( (Tftp->FileDescr = OS_creat(PutFileCmd->DestFileName, OS_WRITE_ONLY) ) < OS_FS_SUCCESS) {
 
      CFE_EVS_SendEvent(TFTP_PUT_OPEN_FILE_ERR_EID, CFE_EVS_ERROR, "Error opening file %s",PutFileCmd->DestFileName);
	  CompleteFileTransfer();
	  return FALSE;
   
   } /* End if error opening file */
   
   OS_printf("TFTP: TFTP_PutFileCmd() - After create file\n");
   
   if (EncodePkt(TFTP_OPCODE_RRQ, 0, NULL, 0) == -1) {
   
      CFE_EVS_SendEvent(TFTP_PUT_ENCODE_WRQ_ERR_EID, CFE_EVS_ERROR, "Write request packet encode failed");
      CompleteFileTransfer();
      return FALSE;
	   
   } /* End if packet encode error */
   
   OS_printf("TFTP: TFTP_PutFileCmd() - After encode read packet request\n");

   Tftp->Mode = TFTP_MODE_OCTET;
   Tftp->State = TFTP_STATE_CLOSED;
   Tftp->State = TFTP_STATE_WRQ_SENT;
   Tftp->BlockNum = 0;
   /* RetStatus = (TransferFile() == EXIT_SUCCESS); */
   CompleteFileTransfer();
   
   return RetStatus;

} /* End TFTP_PutFileCmd() */

/******************************************************************************
** Function: TFTP_GetFileCmd
**
** Get a file from the the system hosting TFTP app.
*/
boolean TFTP_GetFileCmd(const CFE_SB_MsgPtr_t MsgPtr)
{

   const TFTP_GetFileCmdParam *GetFileCmd = (const TFTP_GetFileCmdParam *) MsgPtr;
   boolean  RetStatus = TRUE;

OS_printf("TFTP: TFTP_GetFileCmd()\n");
  
   InitSocket();
   
   if ( (Tftp->FileDescr = open (GetFileCmd->SrcFileName,O_RDONLY,0666)) == -1) {
 
      CFE_EVS_SendEvent(TFTP_GET_OPEN_FILE_ERR_EID, CFE_EVS_ERROR, "Error opening file %s",GetFileCmd->SrcFileName);
	  CompleteFileTransfer();
	  return EXIT_FAILURE;
   
   } /* End if error opening file */
   
   
   if (EncodePkt(TFTP_OPCODE_WRQ, 0, NULL, 0) == -1) {
   
      CFE_EVS_SendEvent(TFTP_PUT_ENCODE_WRQ_ERR_EID, CFE_EVS_ERROR, "Write request packet encode failed");
      CompleteFileTransfer();
      return FALSE;
	   
   } /* End if packet encode error */

   Tftp->Mode = TFTP_MODE_OCTET;
   Tftp->State = TFTP_STATE_WRQ_SENT;
   Tftp->BlockNum = 1;
   RetStatus = (TransferFile() == EXIT_SUCCESS);
   CompleteFileTransfer();
   
   return RetStatus;

} /* End TFTP_GetFileCmd() */


/******************************************************************************
** Function: CreateSocket
**
*/

static int CreateSocket(int Port)
{
  
   static struct sockaddr_in   SocketAddr;
   int    SocketId;

   if ( (SocketId = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) >= 0)
   {

      SocketAddr.sin_family      = AF_INET;
      SocketAddr.sin_addr.s_addr = htonl(INADDR_ANY);
      SocketAddr.sin_port        = htons(Port);

      if ( (bind(SocketId, (struct sockaddr *) &(SocketAddr), sizeof(SocketAddr)) >= 0) )
      {

    	   /* TODO - Uplink->Connected = TRUE; */
         /* Set the socket to non-blocking. Not available in vxWorks, so conditionally compiled. */
         #ifdef _HAVE_FCNTL_
             fcntl(SocketId, F_SETFL, O_NONBLOCK);
         #endif

         FlushSocket(SocketId);
         
      }/* End if successful bind */
      else
      {
         CFE_EVS_SendEvent(TFTP_SOCKET_BIND_ERR_EID, CFE_EVS_ERROR, "Socket bind failed. Status = %d\n", errno);
      }

   } /* End if successful socket creation */
   else
   {
      CFE_EVS_SendEvent(TFTP_SOCKET_CREATE_ERR_EID, CFE_EVS_ERROR, "Socket creation failed. SocketId = %d, Status = %d\n", SocketId, errno);
   }
   
  return SocketId;
  
}/* End CreateSocket() */


/******************************************************************************
** Function: FlushSocket
**
*/
static void FlushSocket(int SocketId)
{
  struct sockaddr_in  s_addr;
  int                 addr_len;
  int                 i;
  int                 status;

  addr_len = sizeof(s_addr);
  memset ((char *) &s_addr, 0, sizeof(s_addr));

  /* TODO - change to while loop */ 
  for (i=0; i<=50; i++)
  {
    status = recvfrom(SocketId, (char *)Tftp->MsgBuf, sizeof (Tftp->MsgBuf) - 1,
                      MSG_DONTWAIT,(struct sockaddr *) &s_addr, (socklen_t *) &addr_len);

    if ( (status < 0) && (errno == EWOULDBLOCK) )
      break; /* no (more) messages */

  } /* end for */

} /* End FlushSocket() */  


/******************************************************************************
** Function: FlushSocket
**
*/
static void InitSocket(void)
{
    struct addrinfo hints, *ai_list, *ai;
    int n, fd = 0;

    Tftp->SocketId = -1;
    
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;

    n = getaddrinfo(Tftp->Host, Tftp->Port, &hints, &ai_list);
    if (n) {
        fprintf(stderr, "%s: getaddrinfo: %s\n",
        		Tftp->Host, gai_strerror(n));
        exit(EXIT_FAILURE);
    }

    for (ai = ai_list; ai; ai = ai->ai_next) {
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) {
	    switch (errno) {
	    case EAFNOSUPPORT:
	    case EPROTONOSUPPORT:
		continue;
		
	    default:
		fprintf(stderr, "%s: socket: %s\n",
				Tftp->Host, strerror(errno));
		continue;
	    }
        }
	memcpy(&Tftp->SocketAddr, ai->ai_addr, ai->ai_addrlen);
	Tftp->SocketAddrLen = ai->ai_addrlen;
	break;	/* still here? we were successful and we are done */
    }

    freeaddrinfo(ai_list);

    if (ai == NULL) {
        fprintf(stderr, "Failure to connect to %s port %s\n",
        		Tftp->Host, Tftp->Port);
        exit(EXIT_FAILURE);
    }

    Tftp->SocketId = fd;
    Tftp->State = TFTP_STATE_CLOSED;

} /* End InitSocket() */


/******************************************************************************
** Function: CompleteFileTransfer
**
** Clean up after a transfer even if it is aborted.
*/
static void CompleteFileTransfer(void)
{
    
   (void) close(Tftp->SocketId);
   /* TODO(void) close(Tftp->FileDescr); */
   OS_close(Tftp->FileDescr);

} /* End CompleteFileTransfer() */


/******************************************************************************
** Function: PrintDebugStr
**
** A helper function to print messages in debug mode. 
**    0 = off, 1 = stderr, 2 = User File
** This may be promoted to a generic application utility. If you want a carriage
** return then it must be added to the string to be output.
**
**
*/
static void PrintDebugStr(char *spec,...)
{
    va_list  args;
    FILE     *fd = stderr;

    if (Tftp->DebugMode > 0)
	{

       if (Tftp->DebugMode == 2)
	   {
	       fd = Tftp->DebugFile;
       }
	   
       va_start(args, spec);
       vfprintf(fd, spec, args);
       va_end(args);
	
    } /* End if debug enabled */

} /* End PrintDebugStr() */


/******************************************************************************
** Function: EncodePkt
**
** Create a TFTP message according to the state information maintained
** in the TFTP data structure and the parameters provided. Since all
** TFTP message are very similar, we use a single function to encode
** all message types.
*/

static size_t EncodePkt(const uint16 Opcode, uint16 BlockNum,
		                unsigned char *DataPtr, size_t DataLen)
{
    
   unsigned char *MsgPtr = Tftp->MsgBuf;
   size_t FileNameLen, ModeLen, ErrStrLen;

   *MsgPtr = ((Opcode >> 8) & 0xff); MsgPtr++;
   *MsgPtr = (Opcode & 0xff);        MsgPtr++;

   switch (Opcode) {
      case TFTP_OPCODE_RRQ:
      case TFTP_OPCODE_WRQ:

	     FileNameLen = strlen(Tftp->SrcFileName) + 1;
	     ModeLen     = strlen(Tftp->Mode) + 1;
         if ( (FileNameLen + ModeLen + 4) > TFTP_MAX_MSGSIZE) {
	        PrintDebugStr("Encoding error: Filename %s too long. Len = %d", Tftp->SrcFileName, ModeLen);
	        return -1;
	     }

	     memcpy(MsgPtr, Tftp->SrcFileName, FileNameLen);
	     MsgPtr += FileNameLen;
		 memcpy(MsgPtr, Tftp->Mode, ModeLen);
         MsgPtr += ModeLen;
         break;
	
      case TFTP_OPCODE_DATA:
	  
         *MsgPtr = ((BlockNum >> 8) & 0xff); MsgPtr++;
	     *MsgPtr = (BlockNum & 0xff);       MsgPtr++;

	     if ((DataLen + 4) > TFTP_MAX_MSGSIZE) {
	        PrintDebugStr("Encoding error: Data too big %d", DataLen);
	        return -1;
	     }
	     memcpy(MsgPtr, DataPtr, DataLen);
	     MsgPtr += DataLen;
	     break;
	
      case TFTP_OPCODE_ACK:
	
	     *MsgPtr = ((BlockNum >> 8) & 0xff); MsgPtr++;
	     *MsgPtr = (BlockNum & 0xff);        MsgPtr++;
	     break;
	
      case TFTP_OPCODE_ERROR:
	
	    /* 
		** BlockNum contains an error code and data is a NUL-terminated
	    ** string with an error message.
		*/
		
	    *MsgPtr = ((BlockNum >> 8) & 0xff); MsgPtr++;
	    *MsgPtr = (BlockNum & 0xff);        MsgPtr++;

	    ErrStrLen = strlen((char *) DataPtr) + 1;
	    if ((ErrStrLen + 4) > TFTP_MAX_MSGSIZE) {
	        PrintDebugStr("Encoding error: Error message %s too long. Len = %d", Tftp->SrcFileName, ErrStrLen);
	   	    return -1;
	    }
	
	    memcpy(MsgPtr, DataPtr, ErrStrLen);
	    MsgPtr += ErrStrLen;
	    break;
	
    } /* End Opcode switch */

    Tftp->MsgLen = (MsgPtr - Tftp->MsgBuf);
    
	return Tftp->MsgLen;
	
} /* End EncodePkt() */


/******************************************************************************
** Function: DecodeOpcode
**
** Utility functions to decode fields from a received TFTP message.
*/

static int DecodeOpcode(unsigned char *Buf, size_t BufLen, uint16_t *Opcode)
{

   if (BufLen < 2) {
      return 0xffff;
   }

   *Opcode = (Buf[0] << 8) + Buf[1];
    
   return 0;

} /* End DecodeOpcode() */

/******************************************************************************
** Function: DecodeBlockNum
**
** Utility functions to decode fields from a received TFTP message.
*/

static int DecodeBlockNum(unsigned char *Buf, size_t BufLen, uint16_t *BlockNum)
{

   if (BufLen < 4) {
      return 0xffff;
   }

   *BlockNum = (Buf[2] << 8) + Buf[3];
   return 0;
	
} /* End DecodeBlockNum() */


/******************************************************************************
** Function: DecodeData
**
** Utility functions to decode fields from a received TFTP message.
*/

static int DecodeData(unsigned char *Buf, size_t BufLen,
	                  unsigned char **Data, size_t *DataLen)
{

   if (BufLen < 5) {
      *Data = NULL;
      *DataLen = 0;
      return 0xffff;
   }

   *Data = Buf + 4;
   *DataLen = BufLen - 4;
   return 0;
	
} /* End DecodeData() */


/******************************************************************************
** Function: DecodeError
**
** Utility functions to decode fields from a received TFTP message.
*/

static int DecodeError(unsigned char *Buf, size_t BufLen,
	                   uint16_t *ErrCode, char **ErrMsg)
{

   int i;
    
   if (BufLen < 5) {
      *ErrMsg = NULL;
	  return 0xffff;
   }

   /* 
   ** Sanity check: the error message must be nul-terminated inside
   ** of the buffer Buf, otherwise the packet is invalid 
   */
    
   for (i = 4; i < BufLen; i++) {
      if (Buf[i] == 0) break;
   }
   if (i == BufLen) {
      PrintDebugStr("Error message is not a nul-terminated string");
      return -1;
   }

   *ErrCode = (Buf[2] << 8) + Buf[3];
   *ErrMsg = (char *) Buf + 4;
   return 0;
	
} /* End DecodeError() */



/******************************************************************************
** Function: TransferFile
**
** Implement the TFTP protocol to transfer a file, assumes the initial message
** (read or write request) has already been encoded into the send buffer and 
** the following TFTP_Class fields have been initialized:
**
**    
*/

static int TransferFile(void)
{

   unsigned char Buf[TFTP_MAX_MSGSIZE];
   size_t   BufLen;
   uint16_t OpCode, BlockNum, ErrCode;
   char     *ErrMsg;
   fd_set   FdSet;
   int      Retries;
   int      RetCode= EXIT_SUCCESS;
   struct   timeval Timeout, TimeNow;

   Retries = TFTP_DEF_RETRIES;
   timerclear(&Tftp->Timer);
   while (Tftp->State != TFTP_STATE_CLOSED) {

      if (gettimeofday(&TimeNow, NULL) == -1) {
         CFE_EVS_SendEvent(TFTP_TIME_OF_DAY_ERR_EID, CFE_EVS_ERROR, "Error getting time of day. Error = %s\n", strerror(errno));
	     CompleteFileTransfer();
	     return EXIT_FAILURE;
	  } /* End gettimeofday() */

      if ( !timerisset(&Tftp->Timer) || timercmp(&TimeNow, &Tftp->Timer, >)) {
	    if (-1 == sendto(Tftp->SocketId, Tftp->MsgBuf, Tftp->MsgLen, 0,
			     (const struct sockaddr *) &Tftp->SocketAddr, Tftp->SocketAddrLen)) {
		   
           CFE_EVS_SendEvent(TFTP_MSG_SEND_ERR_EID, CFE_EVS_ERROR, "Error sending message. Error = %s\n", strerror(errno));
		   CompleteFileTransfer();
		   return EXIT_FAILURE;
	    }
      } /* End if time to send a message */

	  if (Tftp->State == TFTP_STATE_LAST_ACK_SENT) {
	     Tftp->State = TFTP_STATE_CLOSED;
	     break;
	  }
	
	  FD_ZERO(&FdSet);
	  FD_SET(Tftp->SocketId, &FdSet);

      if ( !timerisset(&Tftp->Timer) ) {
	     /* Start a new timer with the default interval. */
	     Tftp->Backoff.tv_sec  = TFTP_DEF_TIMEOUT_SEC;
	     Tftp->Backoff.tv_usec = TFTP_DEF_TIMEOUT_USEC;
	     Timeout = Tftp->Backoff;
	     timeradd( &TimeNow, &Tftp->Backoff, &Tftp->Timer);
	  } else if (timercmp( &TimeNow, &Tftp->Timer, >)) {
	     /* We just retransmitted. Double the interval. */
	     timeradd(&Tftp->Backoff, &Tftp->Backoff, &Tftp->Backoff);
	     Timeout = Tftp->Backoff;
	     timeradd(&TimeNow, &Tftp->Backoff, &Tftp->Timer);
	  } else {
	     /* Wait too short. Calculate the remaining time to block. */
	     timersub(&Tftp->Timer, &TimeNow, &Timeout);
	  }

      if (select(1 + Tftp->SocketId, &FdSet, NULL, NULL, &Timeout) == -1) {
         CFE_EVS_SendEvent(TFTP_SOCKET_SELECT_ERR_EID, CFE_EVS_ERROR, "Error on socket select() call. Error = %s\n", strerror(errno));
         CompleteFileTransfer();
         return EXIT_FAILURE;
      }

      if ( !FD_ISSET(Tftp->SocketId, &FdSet)) {
	     Retries--;
	     if (!Retries) {
            CFE_EVS_SendEvent(TFTP_ABORT_TRANSFER_ERR_EID, CFE_EVS_ERROR, "Aborting transfer after %d retries\n", TFTP_DEF_RETRIES);
            CompleteFileTransfer();
            return EXIT_FAILURE;
         }
         continue;
      } /* End if !FDSET() */

      BufLen = recvfrom(Tftp->SocketId, Buf, sizeof(Buf), 0,
		                (struct sockaddr *) &Tftp->SocketAddr, &Tftp->SocketAddrLen);
      
	  if (BufLen == -1) {
         CFE_EVS_SendEvent(TFTP_SOCKET_RECV_ERR_EID, CFE_EVS_ERROR, "Error on socket recvfrom() call. Error = %s\n", strerror(errno));
         CompleteFileTransfer();
         return EXIT_FAILURE;
      }

	  if (DecodeOpcode(Buf, BufLen, &OpCode) != 0) {
	    PrintDebugStr("Failed to parse opcode in message");
	    continue;
      }

   switch (Tftp->State) {
      case TFTP_STATE_WRQ_SENT:
      case TFTP_STATE_DATA_SENT:
      case TFTP_STATE_LAST_DATA_SENT:
         switch (OpCode) {
            case TFTP_OPCODE_ACK:
               if (DecodeBlockNum(Buf, BufLen, &BlockNum) != 0) {
                  PrintDebugStr("failed to decode block number in ack packet");
                  continue;
			   }
               if (BlockNum != Tftp->BlockNum) {
                  PrintDebugStr("Unexpected block number in ack packet. Expect %d, Received %d",Tftp->BlockNum, BlockNum);
				  continue;
		       }
               if (Tftp->State == TFTP_STATE_LAST_DATA_SENT) {
                  Tftp->State = TFTP_STATE_CLOSED;
               } else {
                  
				  ssize_t Len;
                  
				  /* TODO
				  Len = read(Tftp->FileDescr, Buf, TFTP_BLOCKSIZE); 
				  if (Len == -1) {
				  */
				  Len = OS_read(Tftp->FileDescr, Buf, TFTP_BLOCKSIZE); 
                  if (Len == OS_FS_ERROR) {
                     CFE_EVS_SendEvent(TFTP_READ_FILE_ERR_EID, CFE_EVS_ERROR, "Error reading file for block %s\n", BlockNum);
                     CompleteFileTransfer();
                     return EXIT_FAILURE;
                  } /* End if read() error */
               
			      if (EncodePkt(TFTP_OPCODE_DATA, ++Tftp->BlockNum, Buf, Len) == -1) {
                     CFE_EVS_SendEvent(TFTP_BLOCK_ENCODE_ERR_EID, CFE_EVS_ERROR, "Error encoding block %d\n", BlockNum);
                     return EXIT_FAILURE;
                  }
		    
			      timerclear(&Tftp->Timer);
                  Retries = TFTP_DEF_RETRIES;
                  Tftp->State = (Len == TFTP_BLOCKSIZE) ? TFTP_STATE_DATA_SENT : TFTP_STATE_LAST_DATA_SENT;
               } /* End if not last data sent */
               break;
	
            case TFTP_OPCODE_ERROR:
               if (DecodeError(Buf, BufLen, &ErrCode, &ErrMsg) != 0) {
                  PrintDebugStr("Failed to decode error message");
                  continue;
               }
               CFE_EVS_SendEvent(TFTP_OPCODE_ERR_EID, CFE_EVS_ERROR, "TFTP error code %d, msg = %s\n", ErrCode, ErrMsg);
               RetCode = EXIT_FAILURE;
               Tftp->State = TFTP_STATE_CLOSED;
               break;
         
		    default:
               PrintDebugStr("Unexpected opcode %d ignored", OpCode); 
		       continue;
			   
	    } /* End Opcode switch */
		
	    break;
		
      case TFTP_STATE_RRQ_SENT:
	  case TFTP_STATE_ACK_SENT:
         switch (OpCode) {
            case TFTP_OPCODE_DATA:
			   if (DecodeBlockNum(Buf, BufLen, &BlockNum) != 0) {
				  PrintDebugStr("Failed to decode block number in data packet");
				  continue;
			   }
			   if (BlockNum == Tftp->BlockNum) {
				  unsigned char *Data;
				  size_t Len, DataLen;
				  if (DecodeData(Buf, BufLen, &Data, &DataLen) != 0) {
					 PrintDebugStr("Failed to decode data block number %s",BlockNum);
				  }
				  /*  = write(Tftp->FileDescr, Data, DataLen); */
				  Len = OS_write(Tftp->FileDescr,Data,DataLen);
				  if (Len == -1) {
					 CFE_EVS_SendEvent(TFTP_FILE_WRITE_ERR_EID, CFE_EVS_ERROR, 
									  "TFTP file write error on block %d, errno = %s\n", BlockNum, strerror(errno));
					 CompleteFileTransfer();
					 return EXIT_FAILURE;
				  }
				  if (EncodePkt(TFTP_OPCODE_ACK, Tftp->BlockNum, NULL, 0) == -1) {
					 CFE_EVS_SendEvent(TFTP_OPCODE_ERR_EID, CFE_EVS_ERROR, "Error encoding ack packet for block %d\n", BlockNum);
					 return EXIT_FAILURE;
				  }
				  
				  Tftp->BlockNum++;
				  timerclear(&Tftp->Timer);
				  Retries = TFTP_DEF_RETRIES;
				  Tftp->State = (DataLen == TFTP_BLOCKSIZE) ? TFTP_STATE_ACK_SENT : TFTP_STATE_LAST_ACK_SENT;
			   } /* End if expected block number */
			   break;

            case TFTP_OPCODE_ERROR:
		       if (DecodeError(Buf, BufLen, &ErrCode, &ErrMsg) != 0) {
                  PrintDebugStr("Failed to decode error message");
		          continue;
		       }
               CFE_EVS_SendEvent(TFTP_OPCODE_ERR_EID, CFE_EVS_ERROR, "TFTP error code %d, msg = %s\n", ErrCode, ErrMsg);
               RetCode = EXIT_FAILURE;
		       Tftp->State = TFTP_STATE_CLOSED;
               break;
            default:
               PrintDebugStr("Unexpected opcode %d ignored", OpCode); 
               continue;
			   
	     } /* End Opcode switch */
      } /* End State switch */
	  
    } /* End while (State != TFTP_STATE_CLOSED) loop */

   return RetCode;
	
} /* End TransferFile() */


/* end of file */
