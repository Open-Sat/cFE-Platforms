/*
** $Id: $
** 
** Purpose: Implement the TFTP protocol.
**
** Notes:
**   1. This code is based on the following file: http://cnds.eecs.jacobs-university.de/courses/np-2012/src/tftp/tftp.c
**      In it's header it states "A TFTP (RFC 1350) over IPv4/IPv6 client. This code is intended to
**      demonstrate (i) how to write encoding/decoding functions, (ii) how to implement a simple state
**      machine, and (iii) how to use a select() mainloop to implement timeouts and retransmissions.
**
** References:
**   1. Core Flight Executive Application Developers Guide.
**   2. OpenSat Object-based Programmer's Guide
**
** $Date: $
** $Revision: $
** $Log: $
**
*/

#ifndef _tftp_
#define _tftp_

/*
** Includes
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "app_config.h"
#include "common_types.h"
#include "network_includes.h"
#include "cfe.h"

#define TFTP_PORT     69
#define TFTP_BUF_LEN  512

/*
** See RFC 1350 section 5 and the appendix.
*/

#define TFTP_OPCODE_RRQ		1
#define TFTP_OPCODE_WRQ		2
#define TFTP_OPCODE_DATA	3
#define TFTP_OPCODE_ACK		4
#define TFTP_OPCODE_ERROR	5

#define TFTP_DEF_RETRIES	6
#define TFTP_DEF_TIMEOUT_SEC	0
#define TFTP_DEF_TIMEOUT_USEC	50000
#define TFTP_BLOCKSIZE		512
#define TFTP_MAX_MSGSIZE	(4 + TFTP_BLOCKSIZE)

#define TFTP_MODE_OCTET		"octet"
#define TFTP_MODE_NETASCII	"netascii"
#define TFTP_MODE_MAIL		"mail"

#define TFTP_ERR_NOT_DEFINED	0
#define TFTP_ERR_NOT_FOUND	    1
#define TFTP_ERR_ACCESS_DENIED	2
#define TFTP_ERR_DISK_FULL	    3
#define TFTP_ERR_UNKNOWN_TID	4
#define TFTP_ERR_ILLEGAL_OP	    5
#define TFTP_ERR_FILE_EXISTS	6
#define TFTP_ERR_NO_SUCH_USER	7

#define TFTP_STATE_CLOSED	      0
#define TFTP_STATE_RRQ_SENT	      1
#define TFTP_STATE_WRQ_SENT	      2
#define TFTP_STATE_DATA_SENT	  3
#define TFTP_STATE_LAST_DATA_SENT 4
#define TFTP_STATE_ACK_SENT	      5
#define TFTP_STATE_LAST_ACK_SENT  6

#define TFTP_HOST_NAME_LEN     32
#define TFTP_PORT_NAME_LEN     32
#define TFTP_FILE_NAME_LEN     64

#define TFTP_DEBUG_OFF     0
#define TFTP_DEBUG_STDERR  1
#define TFTP_DEBUG_FILE    2
#define TFTP_DEBUG_MAX     3

/*
** Event Message IDs
*/

#define TFTP_SOCKET_CREATE_ERR_EID   (TFTP_BASE_EID + 0)
#define TFTP_SOCKET_BIND_ERR_EID     (TFTP_BASE_EID + 1)
#define TFTP_TIME_OF_DAY_ERR_EID     (TFTP_BASE_EID + 2)
#define TFTP_MSG_SEND_ERR_EID        (TFTP_BASE_EID + 3)
#define TFTP_SOCKET_SELECT_ERR_EID   (TFTP_BASE_EID + 4)
#define TFTP_ABORT_TRANSFER_ERR_EID  (TFTP_BASE_EID + 5)
#define TFTP_SOCKET_RECV_ERR_EID     (TFTP_BASE_EID + 6)
#define TFTP_READ_FILE_ERR_EID       (TFTP_BASE_EID + 7)
#define TFTP_BLOCK_ENCODE_ERR_EID    (TFTP_BASE_EID + 8)
#define TFTP_OPCODE_ERR_EID          (TFTP_BASE_EID + 9)
#define TFTP_FILE_WRITE_ERR_EID      (TFTP_BASE_EID + 10)
#define TFTP_INVLD_DBG_MODE_ERR_EID  (TFTP_BASE_EID + 11)
#define TFTP_GET_OPEN_FILE_ERR_EID   (TFTP_BASE_EID + 12)
#define TFTP_GET_ENCODE_WRQ_ERR_EID  (TFTP_BASE_EID + 13)
#define TFTP_PUT_OPEN_FILE_ERR_EID   (TFTP_BASE_EID + 14)
#define TFTP_PUT_ENCODE_WRQ_ERR_EID  (TFTP_BASE_EID + 15)

#define TFTP_TOTAL_EID  15

/*
** Type Definitions
*/


/******************************************************************************
** TFTP Class
*/

typedef struct {

   int     DebugMode;
   FILE*   DebugFile;
   char    DebugFileName[TFTP_FILE_NAME_LEN];
   uint16  GetFileCnt;
   uint16  PutFileCnt;
   
   char    Host[TFTP_HOST_NAME_LEN];          /* Hostname of the tftp server */
   char    Port[TFTP_PORT_NAME_LEN];          /* Port number / service name  */
   char    SrcFileName[TFTP_FILE_NAME_LEN];   /* */
   char    DestFileName[TFTP_FILE_NAME_LEN];  /* */

   struct sockaddr_storage SocketAddr;		/* Address of the server */
   socklen_t               SocketAddrLen;   /* Length of the address */
   int           SocketId;		            /* Socket descriptor     */
   int32         FileDescr;		            /* File descriptor       */

   char            *Mode;      /* TFTP transfer mode              */
   int		       State;	   /* State of the TFTP state machine */
   uint16          BlockNum;   /* Current block number            */
   struct timeval  Backoff;
   struct timeval  Timer;
   unsigned char   MsgBuf[TFTP_MAX_MSGSIZE];	/* Send buffer     */
   size_t          MsgLen;			            /* Send buffer len */

} TFTP_Class;


/******************************************************************************
** Command Functions
*/

typedef struct
{

   uint8   CmdHeader[CFE_SB_CMD_HDR_SIZE];
   uint16  Mode;
   char    FileName[TFTP_FILE_NAME_LEN];
   
} OS_PACK TFTP_SetDebugModeCmdParam;
#define TFTP_SET_DEBUG_MODE_CMD_DATA_LEN  (sizeof(TFTP_SetDebugModeCmdParam) - CFE_SB_CMD_HDR_SIZE)

/* TODO - Decide whether to put these in get/put commands. Maybe separate config command.
   char    Host[TFTP_HOST_NAME_LEN];
   char    Port[TFTP_PORT_NAME_LEN];
*/

typedef struct
{

   uint8   CmdHeader[CFE_SB_CMD_HDR_SIZE];
   char    SrcFileName[TFTP_FILE_NAME_LEN];
   char    DestFileName[TFTP_FILE_NAME_LEN];

}  OS_PACK TFTP_PutFileCmdParam;
#define TFTP_PUT_FILE_CMD_DATA_LEN  (sizeof(TFTP_PutFileCmdParam) - CFE_SB_CMD_HDR_SIZE)

typedef struct
{

   uint8   CmdHeader[CFE_SB_CMD_HDR_SIZE];
   char    SrcFileName[TFTP_FILE_NAME_LEN];
   char    DestFileName[TFTP_FILE_NAME_LEN];

}  OS_PACK TFTP_GetFileCmdParam;
#define TFTP_GET_FILE_CMD_DATA_LEN  (sizeof(TFTP_GetFileCmdParam) - CFE_SB_CMD_HDR_SIZE)


/*
** Exported Functions
*/

/******************************************************************************
** Function: TFTP_Constructor
**
** Construct a TFTP object.
**
** Notes:
**   1. This must be called prior to any other function.
**
*/
void TFTP_Constructor(TFTP_Class*  TftpPtr);


/******************************************************************************
** Function:  TFTP_ResetStatus
**
*/
void TFTP_ResetStatus(void);


/******************************************************************************
** Function: TFTP_SetDebugModeCmd
**
*/
boolean TFTP_SetDebugModeCmd(const CFE_SB_MsgPtr_t MsgPtr);


/******************************************************************************
** Function: TFTP_PutFileCmd
**
** Put a file from the caller to the system hosting the TFTP app.
*/
boolean TFTP_PutFileCmd(const CFE_SB_MsgPtr_t MsgPtr);


/******************************************************************************
** Function: TFTP_GetFileCmd
**
** Get a file from the system hosting the TFTP app.
*/
boolean TFTP_GetFileCmd(const CFE_SB_MsgPtr_t MsgPtr);


#endif /* _tftp_ */
