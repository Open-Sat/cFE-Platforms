/*
** $Id: $
** 
** Purpose: Define the TFTP application. 
**
** Notes:
**   1.
**
** References:
**   1. NASA GSFC Code 582 C Coding Standards
**   2. CFS Object-based Application Developers Guide.
**
** $Date: $
** $Revision: $
** $Log: $
**
*/
#ifndef _tfapp_
#define _tfapp_

/*
** Includes
*/

#include "app_config.h"
#include "cmdmgr.h"
#include "tftp.h"

/*
** Macro Definitions
*/

#define TFAPP_INIT_APP_INFO_EID   (TFAPP_BASE_EID + 0)
#define TFAPP_NOOP_INFO_EID       (TFAPP_BASE_EID + 1)
#define TFAPP_EXIT_ERR_EID        (TFAPP_BASE_EID + 2)
#define TFAPP_INVALID_MID_ERR_EID (TFAPP_BASE_EID + 3)

#define TFAPP_TOTAL_EID  4


/*
** Type Definitions
*/

typedef struct
{

   CMDMGR_Class CmdMgr;
   TFTP_Class   Tftp;

   CFE_SB_PipeId_t CmdPipe;

} TFAPP_Class;

typedef struct
{

   uint8    Header[CFE_SB_TLM_HDR_SIZE];

   /*
   ** CMDMGR Data
   */
   uint16   ValidCmdCnt;
   uint16   InvalidCmdCnt;

   /*
   ** TFTP Data
   */

   uint16  DebugMode;

   uint16  GetFileCnt;
   uint16  PutFileCnt;

   uint8   SocketId;
   uint8   State;
   uint16  BlockNum;

   char    Host[TFTP_HOST_NAME_LEN];
   char    Port[TFTP_PORT_NAME_LEN];
   char    SrcFileName[TFTP_FILE_NAME_LEN];
   char    DestFileName[TFTP_FILE_NAME_LEN];


} OS_PACK TFAPP_HkPkt;

#define TFAPP_TLM_HK_LEN sizeof (TFAPP_HkPkt)


/*
** Exported Data
*/

extern TFAPP_Class  Tfapp;


/*
** Exported Functions
*/

/******************************************************************************
** Function: TFAPP_Main
**
*/
void TFAPP_Main(void);


/******************************************************************************
** Function: TFAPP_NoOpCmd
**
*/
boolean TFAPP_NoOpCmd(const CFE_SB_MsgPtr_t MsgPtr);


/******************************************************************************
** Function: TFAPP_ResetAppCmd
**
*/
boolean TFAPP_ResetAppCmd(const CFE_SB_MsgPtr_t MsgPtr);


#endif /* _tfapp_ */
