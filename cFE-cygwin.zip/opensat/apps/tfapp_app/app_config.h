/*
** $Id: $
** 
** Purpose: Define configurations for the Trivial FIle Transfer Protocol (TFTP) application
**
** Notes:
**   1. These macros can only be build with the application and can't
**      have a platform scope because the same file name is used for
**      all applications following the object-based application design.
**
** References:
**   1. CFS Object-based Application Developers Guide.
**
** $Date: $
** $Revision: $
** $Log: $
**
*/

#ifndef _app_config_
#define _app_config_

/*
** Includes
*/

#include "tfapp_mission_cfg.h"
#include "tfapp_platform_cfg.h"


/******************************************************************************
** TFTP Application Macros
*/

#define  TFAPP_MAJOR_VERSION      1
#define  TFAPP_MINOR_VERSION      0
#define  TFAPP_REVISION           0
#define  TFAPP_MISSION_REV        0


/******************************************************************************
** Command Macros
*/

#define TFAPP_CMD_RESET_FC            0
#define TFAPP_CMD_NOOP_FC             1

#define TFAPP_CMD_SET_DEBUG_MODE_FC   2
#define TFAPP_CMD_GET_FILE_FC         3
#define TFAPP_CMD_PUT_FILE_FC         4

#define TFAPP_CMD_TOTAL_FC            5


#define CMDMGR_CMD_FUNC_TOTAL   10
#define CMDMGR_PIPE_DEPTH       10
#define CMDMGR_PIPE_NAME        "TFAPP_CMD_PIPE"
#define CMDMGR_CMD_MSG_TOTAL    2


/******************************************************************************
** Event Macros
*/

#define TFAPP_BASE_EID    0  /* Used by tfapp.h  */
#define CMDMGR_BASE_EID  10  /* Used by cmdmgr.h */
#define TFTP_BASE_EID    20  /* Used by tftp.h   */


/******************************************************************************
** tftp.h Configurations
*/


#endif /* _app_config_ */
