/* 
** File:
**   $Id: $
**
** Purpose: Trivial File Transfer Protocol Application.
**
** Notes:
**   1. This is non-flight code so an attempt has been made to balance keeping
**      it simple while making it robust. Limiting the number of configuration
**      parameters and integration items (message IDs, perf IDs, etc) was
**      also taken into consideration.
**   2. Event message filters are not used since this is for test environments.
**      This may be reconsidered if event flooding ever becomes a problem.
**   3. Performance traces are not included.
**   4. Most functions are global to assist in unit testing
**
** References:
**   1. NASA GSFC Code 582 C Coding Standards
**   2. CFS Object-based Application Developers Guide.
**
** $Date: $
** $Revision: $
** $Log: $
**
*/

/*
** Includes
*/

#include <string.h>
#include "tfapp.h"


/*
** Local Function Prototypes
*/

static int32 InitApp(void);
static void ProcessCommands(void);

/*
** Global Data
*/

TFAPP_Class  Tfapp;

TFAPP_HkPkt  TfappHkPkt;

/******************************************************************************
** Function: TFAPP_Main
**
*/
void TFAPP_Main(void)
{

   int32  Status    = CFE_SEVERITY_ERROR;
   uint32 RunStatus = CFE_ES_APP_ERROR;


   Status = CFE_ES_RegisterApp();
   CFE_EVS_Register(NULL,0,0);

   /*
   ** Perform application specific initialization
   */
   if (Status == CFE_SUCCESS)
   {
       OS_printf("TFAPP: About to call init\n");
       Status = InitApp();
   }

   /*
   ** At this point many flight apps use CFE_ES_WaitForStartupSync() to
   ** synchronize their startup timing with other apps. This is not
   ** needed.
   */

   if (Status == CFE_SUCCESS) RunStatus = CFE_ES_APP_RUN;

   /*
   ** Main process loop
   */
   OS_printf("TFAPP: About to enter loop\n");
   while (CFE_ES_RunLoop(&RunStatus))
   {

      OS_TaskDelay(TFAPP_RUNLOOP_DELAY);

      ProcessCommands();

   } /* End CFE_ES_RunLoop */


   /* Write to system log in case events not working */

   CFE_ES_WriteToSysLog("TFAPP App terminating, err = 0x%08X\n", Status);

   CFE_EVS_SendEvent(TFAPP_EXIT_ERR_EID, CFE_EVS_CRITICAL, "TFAPP App: terminating, err = 0x%08X", Status);

   CFE_ES_ExitApp(RunStatus);  /* Let cFE kill the task (and any child tasks) */

} /* End of TFAPP_Main() */


/******************************************************************************
** Function: TFAPP_NoOpCmd
**
*/

boolean TFAPP_NoOpCmd(const CFE_SB_MsgPtr_t MsgPtr)
{

   CFE_EVS_SendEvent (TFAPP_NOOP_INFO_EID,
                      CFE_EVS_INFORMATION,
                      "No operation command received for TFAPP version %d.%d",
                      TFAPP_MAJOR_VERSION,TFAPP_MINOR_VERSION);

   return TRUE;


} /* End TFAPP_NoOpCmd() */


/******************************************************************************
** Function: TFAPP_ResetAppCmd
**
*/

boolean TFAPP_ResetAppCmd(const CFE_SB_MsgPtr_t MsgPtr)
{

   TFTP_ResetStatus();
   CMDMGR_ResetStatus();

   return TRUE;

} /* End TFAPP_ResetAppCmd() */


/******************************************************************************
** Function: TFAPP_SendHousekeepingPkt
**
*/
void TFAPP_SendHousekeepingPkt(void)
{

   /*
   ** TFTP Data
   */

   TfappHkPkt.ValidCmdCnt   = Tfapp.CmdMgr.ValidCmdCnt;
   TfappHkPkt.InvalidCmdCnt = Tfapp.CmdMgr.InvalidCmdCnt;

   /*
   ** TFTP Data
   ** - At a minimum all tftp variables effected by a reset must be included
   ** - Some of these may be more diagnostic but not enough to warrant a
   **   separate diagnostic. Also easier for the user not to have to command it.
   */

   TfappHkPkt.DebugMode  = Tfapp.Tftp.DebugMode;

   TfappHkPkt.GetFileCnt = Tfapp.Tftp.GetFileCnt;
   TfappHkPkt.PutFileCnt = Tfapp.Tftp.PutFileCnt;

   TfappHkPkt.SocketId   = (uint16)Tfapp.Tftp.SocketId;
   TfappHkPkt.State      = Tfapp.Tftp.State;
   TfappHkPkt.BlockNum   = Tfapp.Tftp.BlockNum;
  
  
   strncpy(TfappHkPkt.Host, Tfapp.Tftp.Host, TFTP_HOST_NAME_LEN);
   strncpy(TfappHkPkt.Port, Tfapp.Tftp.Port, TFTP_PORT_NAME_LEN);

   strncpy(TfappHkPkt.SrcFileName,  Tfapp.Tftp.SrcFileName,  TFTP_FILE_NAME_LEN);
   strncpy(TfappHkPkt.DestFileName, Tfapp.Tftp.DestFileName, TFTP_FILE_NAME_LEN);

   /* strncpy(LabTlmHkPkt.TlmDestIp, LabTlm.PktMgr.TlmDestIp, PKTMGR_IP_STR_LEN); */

   CFE_SB_TimeStampMsg((CFE_SB_Msg_t *) &TfappHkPkt);
   CFE_SB_SendMsg((CFE_SB_Msg_t *) &TfappHkPkt);

} /* End TFAPP_SendHousekeepingPkt() */


/******************************************************************************
** Function: InitApp
**
*/
static int32 InitApp(void)
{
    int32 Status = CFE_SUCCESS;

    /*
    ** Initialize 'entity' objects
    */

    TFTP_Constructor(&Tfapp.Tftp);

    /*
    ** Initialize application managers
    */

    CFE_SB_CreatePipe(&Tfapp.CmdPipe, CMDMGR_PIPE_DEPTH, CMDMGR_PIPE_NAME);
    CFE_SB_Subscribe(TFAPP_CMD_MID, Tfapp.CmdPipe);
    CFE_SB_Subscribe(TFAPP_SEND_HK_MID, Tfapp.CmdPipe);

    CMDMGR_Constructor(&Tfapp.CmdMgr);
    CMDMGR_RegisterFunc(TFAPP_CMD_RESET_FC,           TFAPP_ResetAppCmd,      0);
    CMDMGR_RegisterFunc(TFAPP_CMD_NOOP_FC,            TFAPP_NoOpCmd,          0);
    CMDMGR_RegisterFunc(TFAPP_CMD_SET_DEBUG_MODE_FC,  TFTP_SetDebugModeCmd,   TFTP_SET_DEBUG_MODE_CMD_DATA_LEN);
    CMDMGR_RegisterFunc(TFAPP_CMD_GET_FILE_FC,        TFTP_GetFileCmd,        TFTP_GET_FILE_CMD_DATA_LEN);
    CMDMGR_RegisterFunc(TFAPP_CMD_PUT_FILE_FC,        TFTP_PutFileCmd,        TFTP_PUT_FILE_CMD_DATA_LEN);

    CFE_SB_InitMsg(&TfappHkPkt, TFAPP_TLM_HK_MID, TFAPP_TLM_HK_LEN, TRUE);

    /*
    ** Application startup event message
    */
    Status = CFE_EVS_SendEvent(TFAPP_INIT_APP_INFO_EID,
                               CFE_EVS_INFORMATION,
                               "TFAPP Initialized. Version %d.%d.%d.%d",
                               TFAPP_MAJOR_VERSION,
                               TFAPP_MINOR_VERSION,
                               TFAPP_REVISION,
                               TFAPP_MISSION_REV);

    return(Status);

} /* End of InitApp() */


/******************************************************************************
** Function: ProcessCommands
**
*/
static void ProcessCommands(void)
{

   int32           Status;
   CFE_SB_Msg_t*   CmdMsgPtr;
   CFE_SB_MsgId_t  MsgId;

   Status = CFE_SB_RcvMsg(&CmdMsgPtr, Tfapp.CmdPipe, CFE_SB_POLL);

   if (Status == CFE_SUCCESS)
   {

      MsgId = CFE_SB_GetMsgId(CmdMsgPtr);
      OS_printf("TFAPP: Received msg 0x%X\n",MsgId);
      switch (MsgId)
      {
         case TFAPP_CMD_MID:
            CMDMGR_DispatchFunc(CmdMsgPtr);
            break;

         case TFAPP_SEND_HK_MID:
            TFAPP_SendHousekeepingPkt();
            break;

         default:
            CFE_EVS_SendEvent(TFAPP_INVALID_MID_ERR_EID, CFE_EVS_ERROR,
                              "Received invalid command packet,MID = 0x%4X",MsgId);

            break;

      } /* End Msgid switch */

   } /* End if SB received a packet */

} /* End ProcessCommands() */


/* end of file */
